#!/usr/bin/env bash
echo -n '{"text":"' >> build_output
echo -n "*CIRCLE_PROJECT* : ${CIRCLE_PROJECT_REPONAME}/${CIRCLE_BRANCH}/${CIRCLE_BUILD_NUM}\n" >> build_output
echo -n "*CIRCLE_USERNAME* : ${CIRCLE_PROJECT_USERNAME}/${CIRCLE_USERNAME}\n" >> build_output
echo -n "*CIRCLE_WORKFLOW_ID* : https://circleci.com/workflow-run/${CIRCLE_WORKFLOW_ID}\n" >> build_output
echo -n "_A build is ready for ${CIRCLE_PROJECT_REPONAME}/${CIRCLE_BRANCH} branch. Please click the link above to release it._" >> build_output
echo -n '"}' >> build_output
echo
cat build_output
curl -X POST -H 'Content-type: application/json' --data @build_output ${SLACK_WEBHOOK}
