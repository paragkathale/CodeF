
#!/usr/bin/env bash

function installSonar {
  echo '== Setup sonar scanner'
  
  # set version of sonar scanner to use :
  sonarversion=${SONAR_VERSION:-}
  if [ -z "${sonarversion:-}" ]; then
    sonarversion=3.3.0.1492
  fi
  echo "== Using sonarscanner $sonarversion"

  mkdir -p $HOME/sonarscanner
  pushd $HOME/sonarscanner > /dev/null
  if [ ! -d "sonar-scanner-$sonarversion" ]; then
    echo "== Downloading sonarscanner $sonarversion"
    curl -o sonar-scanner-cli-$sonarversion-linux.zip "https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-$sonarversion-linux.zip"
    unzip -q sonar-scanner-cli-$sonarversion-linux.zip
    rm sonar-scanner-cli-$sonarversion-linux.zip
    mv sonar-scanner-$sonarversion-linux sonar-scanner-$sonarversion
  fi
  export SONAR_SCANNER_HOME=$HOME/sonarscanner/sonar-scanner-$sonarversion
  export PATH=$SONAR_SCANNER_HOME/bin:$PATH
  popd > /dev/null
}

installSonar

if [[ ! -z $CIRCLE_PULL_REQUEST ]] ; then
    REPO_SLUG=$CIRCLE_PROJECT_USERNAME/$CIRCLE_PROJECT_REPONAME
    PR_NUMBER=${CIRCLE_PULL_REQUEST##*/}
    PR_BRANCHES=($(curl -H "Authorization: token $GITHUB_TOKEN" -sSL https://api.github.com/repos/$REPO_SLUG/pulls/$PR_NUMBER | jq -r -c ".base.ref, .head.ref"))
    PULL_REQUEST_BASEBRANCH=${PR_BRANCHES[0]}
    PULL_REQUEST_HEADBRANCH=${PR_BRANCHES[1]}

    # Workaround for https://community.sonarsource.com/t/code-is-empty-on-pull-request-reviews/822/9
    git fetch --all
    git branch -D $PULL_REQUEST_BASEBRANCH
    git rev-parse origin/$PULL_REQUEST_BASEBRANCH
fi

sonar-scanner \
    -Dsonar.projectKey=$SONAR_PROJECT_KEY \
    -Dsonar.projectName=$CIRCLE_PROJECT_REPONAME \
    -Dsonar.organization=$SONAR_ORG \
    -Dsonar.sources=src \
    -Dsonar.tests=test \
    -Dsonar.exclusions=node_modules/**,coverage/** \
    -Dsonar.host.url=https://sonarcloud.io \
    -Dsonar.login=$SONAR_TOKEN \
    -Dsonar.pullrequest.key=$PR_NUMBER \
    -Dsonar.pullrequest.branch=$PULL_REQUEST_HEADBRANCH \
    -Dsonar.pullrequest.base=$PULL_REQUEST_BASEBRANCH \
    -Dsonar.pullrequest.provider=GitHub \
    -Dsonar.pullrequest.github.repository=$REPO_SLUG \
    -Dsonar.typescript.lcov.reportPaths=coverage/lcov.info
