import uuid = require('uuid/v1');
import { config } from './common/configuration';
import { PubsubTestMode } from './common/pubsub-test-mode';
import { TestEventLogger, TestEventType } from './common/test-event-logger';
import { PublisherFactory, PublisherType } from './publishers/publisher-factory';

export enum PubsubTesterState {
    Pending,
    Success,
    Failure
}

export class PubsubTester {

    private readonly _testId: string;
    private _receivedMessageCount: number = 0;
    private _timeout?: NodeJS.Timeout;
    private _state: PubsubTesterState = PubsubTesterState.Pending;
    private readonly _publisherType: PublisherType;

    public get testId(): string {
        return this._testId;
    }

    public get state(): PubsubTesterState {
        return this._state;
    }

    public get done(): boolean {
        return this._receivedMessageCount >= this._targetCount;
    }

    constructor(private readonly _testMode: PubsubTestMode, private readonly _targetCount: number) {
        this._testId = uuid();
        this._publisherType = this.lookupPublisherType(this._testMode);
    }

    public async start() {
        this._timeout = setTimeout(this.testExpiredBeforeCompletion.bind(this), config.defaultTimeout);
        const publisher = PublisherFactory.makePublisher(this._publisherType, this._testId);
        await publisher.publish(this._targetCount);
    }

    // must be called for all received messages
    public receivedMessage(receivedTestId: string) {
        if (receivedTestId === this._testId) {
            this._receivedMessageCount++;
        }

        if (this.done && this._timeout) {
            clearTimeout(this._timeout);
            this._state = PubsubTesterState.Success;
            TestEventLogger.log(TestEventType.success, this._testMode,
                `successfully read ${this._receivedMessageCount} records`);
        }
    }

    private testExpiredBeforeCompletion() {
        this._state = PubsubTesterState.Failure;
        TestEventLogger.log(TestEventType.failure, this._testMode,
            `failed to read all messages. Read ${this._receivedMessageCount}/${this._targetCount}`);
    }

    private lookupPublisherType(testMode: PubsubTestMode): PublisherType {
        let publisherType: PublisherType;
        switch (testMode) {
            case PubsubTestMode.StandardJavaTest: {
                publisherType = PublisherType.ExternalPublisher;
                break;
            }
            case PubsubTestMode.StandardNodeTest: {
                publisherType = PublisherType.SelfPublisher;
                break;
            }
            default: {
                throw new Error(`cannot map test mode ${testMode} to PublisherType`);
            }
        }
        return publisherType;
    }
}
