import { jsonStringify, logger } from '@drumg/long-island-tea';
import { Request, Response } from 'express';
import { PubsubTestMode } from '../common/pubsub-test-mode';
import { PubsubTestManager } from '../pubsub-test-manager';

export class PubsubNodeTestController {

    public static get(req: Request, res: Response) {
        logger.info(`req.query = ${jsonStringify(req.query)}`);
        const messageCount: number = parseInt(req.query.messageCount);

        const responsePayload = {
            message: ''
        };

        let statusCode;
        const testMode = PubsubTestMode.StandardNodeTest;
        if (messageCount > 0) {
            const testId =
                PubsubTestManager.getInstance().initiateAddTest(testMode, messageCount);
            responsePayload.message = `Initiated test [${testMode}] ${testId} with ${messageCount} messages`;
            statusCode = 200;
        } else {
            responsePayload.message = 'messageCount must be > 0';
            statusCode = 404;
        }

        res.status(statusCode).send(responsePayload);
    }
}
