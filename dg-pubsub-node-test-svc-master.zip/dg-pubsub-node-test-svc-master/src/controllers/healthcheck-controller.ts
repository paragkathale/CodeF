import { Request, Response } from 'express';

export class HealthcheckController {

    public static get(_req: Request, res: Response) {
        const responsePayload = JSON.stringify({ status: 'ok', msg: 'I am alive'});
        res.status(200).send(responsePayload);
    }
}
