import {HttpUtils, logger} from '@drumg/long-island-tea';
import {IPublisher} from './i-publisher';

export class ExternalPublisher implements IPublisher {
    private static readonly PREFIX = '[SERVICE-BUS-TEST][JAVA-TEST]‌‌‌‌‌‌‌‌‌‌‌‌';
    private readonly httpUtils: HttpUtils;
    private numMessages: number = 0;
    private readonly testId: string;

    public constructor(testId: string, serviceUrl: string) {
        this.httpUtils = new HttpUtils(serviceUrl);
        this.testId = testId;
    }

    public async publish(numMessages: number) {
        this.numMessages = numMessages;

        logger.info(`${ExternalPublisher.PREFIX}[START]`);
        logger.info(`${ExternalPublisher.PREFIX} Requesting external service to publish ${numMessages} messages`);
        await this.call();
        // tslint:disable:max-line-length
        logger.info(`${ExternalPublisher.PREFIX} Finished requesting external service to publish ${numMessages} messages`);
    }

    private async call() {
        try {
            const result = await this.httpUtils.get(
                `publish?testId=${this.testId}&messageCount=${this.numMessages}`,
                `Requesting service to publish messages`
            );
            return JSON.parse(result);
        } catch (err) {
            logger.error(`Error requesting service, reason: ${err.message}`);
            throw err;
        }
    }
}
