import {BaseMessage, MessageQueueFactory} from '@drumg/cloud-services';
import {Publisher} from '@drumg/cloud-services';
import {logger} from '@drumg/long-island-tea';

class CustomMessage extends BaseMessage {
    public static create(body: string) {
        return new CustomMessage(body);
    }
    private constructor(body: string) {
        super('1.0.0', body);
    }
}

export class MessageQueuePublisher {
    private readonly topic: string;
    private readonly messageQueueFactory: MessageQueueFactory;
    private publisher?: Publisher;

    public constructor(topic: string) {
        this.messageQueueFactory = new MessageQueueFactory();
        this.topic = topic;
    }

    public async startPublisher() {
        if (!this.publisher) {
            logger.info(`Starting the publisher for ${this.topic}`);
            this.publisher = await this.messageQueueFactory.createPublisher(this.topic);
        }
    }

    public async stopPublisher() {
        if (this.publisher) {
            logger.info(`Stop the publisher`);
            await this.publisher.close();
            this.publisher = undefined;
        }
    }

    public async sendMessage(message: string) {
        if (this.publisher) {
            logger.info(`Posting a service bus message ${message}`);
            this.publisher.send(CustomMessage.create(message));
        }
    }
}
