import {logger} from '@drumg/long-island-tea';
import {TestMessage} from '../common/test-message';
import {IPublisher} from './i-publisher';
import {MessageQueuePublisher} from './message-queue-publisher';

export class SelfPublisher implements IPublisher {
    private static readonly PREFIX = '[SERVICE-BUS-TEST][NODE-TEST]‌‌‌‌‌‌‌‌‌‌‌‌';
    private readonly topic: string;
    private readonly testId: string;

    public constructor(testId: string, topic: string) {
        this.topic = topic;
        this.testId = testId;
    }

    public async publish(numMessages: number) {
        const publisher = new MessageQueuePublisher(this.topic);
        await publisher.startPublisher();
        logger.info(`${SelfPublisher.PREFIX}[START]`);
        const message = new TestMessage(this.testId);

        logger.info(`${SelfPublisher.PREFIX} Publishing ${numMessages} messages`);
        for (let i = 0; i < numMessages; ++i) {
            await publisher.sendMessage(message.createNext());
        }
        await publisher.stopPublisher();
        logger.info(`${SelfPublisher.PREFIX} Finishing publishing ${numMessages} messages`);
    }
}
