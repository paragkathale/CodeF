export interface IPublisher {
    publish(numMessages: number): void;
}
