import {config} from '../common/configuration';
import {ExternalPublisher} from './external-publisher';
import {IPublisher} from './i-publisher';
import {SelfPublisher} from './self-publisher';

export enum PublisherType {SelfPublisher, ExternalPublisher}

export class PublisherFactory {
    public static makePublisher(type: PublisherType, testId: string): IPublisher {
        return type === PublisherType.SelfPublisher ?
            new SelfPublisher(testId, config.testTopic) :
            new ExternalPublisher(testId, config.javaPubsubTestServiceUrl);
    }
}
