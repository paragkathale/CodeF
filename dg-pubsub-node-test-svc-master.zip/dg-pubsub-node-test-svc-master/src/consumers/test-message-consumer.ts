import { Message, MessageQueueFactory } from '@drumg/cloud-services';
import { logger } from '@drumg/long-island-tea';
import { config } from '../common/configuration';
import { TestMessage } from '../common/test-message';
import { PubsubTestManager } from '../pubsub-test-manager';
import { BaseConsumer } from './base-consumer';

export class TestMessageConsumer extends BaseConsumer {
    constructor() {
        super(new MessageQueueFactory());
    }

    protected getTopic(): string {
        return config.testTopic;
    }

    protected getSubscriptionName(): string {
        return config.testSubscription;
    }

    protected async consume(message: Message<any>): Promise<any> {
        try {
            const testMessage = JSON.parse(message.body) as TestMessage;
            const tester = PubsubTestManager.getInstance().getTester(testMessage.testId);
            tester.receivedMessage(tester.testId);
        } catch (error) {
            logger.error(`test message consumption failed: ${error}`);
        }
    }
}
