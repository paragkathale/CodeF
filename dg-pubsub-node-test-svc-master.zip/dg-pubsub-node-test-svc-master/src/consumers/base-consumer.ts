import {
    Message,
    MessageQueueFactory,
    RerouteToDeadLetterQueueError,
    UnhandledMessageError
} from '@drumg/cloud-services';

import { jsonStringify, logger } from '@drumg/long-island-tea';
import { config } from '../common/configuration';
import { ObjectUtils } from '../common/object-utils';

export abstract class BaseConsumer {

    private static createFactory(): MessageQueueFactory {
        return new MessageQueueFactory();
    }

    private _messageQueueFactory: MessageQueueFactory;

    protected constructor(messageQueueFactory: MessageQueueFactory = BaseConsumer.createFactory()) {
        this._messageQueueFactory = messageQueueFactory;
    }

    public async start() {
        return this.startInternal();
    }

    protected abstract async consume(message: Message<string>): Promise<any>;
    protected abstract getTopic(): string;
    protected abstract getSubscriptionName(): string;

    private async consumeWrapper(message: Message<any>) {
        logger.info(`${message.body}`);
        if (!message.body) {
            throw new RerouteToDeadLetterQueueError('no message body');
        }
        try {
            logger.debug(`[${config.name}] new message: ${jsonStringify(message.body)}`);
            await this.consume(message).catch((reason) => {
                logger.error(`error processing message: '${reason}'`);
                throw new UnhandledMessageError(reason);
            });
        } catch (err) {
            logger.error(`error processing message: '${err}'`);
            throw new UnhandledMessageError(err);
        }
    }

    private async startInternal() {
        logger.info(`[${ObjectUtils.className(this)}] subscribing to '${this.getTopic()}'`);

        await this._messageQueueFactory.createConsumer(
            this.getTopic(),
            this.getSubscriptionName(),
            this.consumeWrapper.bind(this)
        );
    }

}
