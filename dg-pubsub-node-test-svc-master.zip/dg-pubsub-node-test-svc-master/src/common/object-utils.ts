import { logger } from '@drumg/long-island-tea';

export class ObjectUtils {
    public static toJSON(obj: object, exclusionSet: Set<string> = new Set<string>()) {
        const thisObj = obj;
        const proto = Object.getPrototypeOf(thisObj);
        const jsonObj: any = Object.assign({}, thisObj);
        Object.entries(Object.getOwnPropertyDescriptors(proto))
          .filter(([_key, descriptor]) => {
              return typeof descriptor.get === 'function' && !exclusionSet.has(_key);
          })
          .map(([key, descriptor]) => {
            if (descriptor && key[0] !== '_') {
              try {
                const val = (thisObj as any)[key];
                jsonObj[key] = val;
              } catch (error) {
                logger.error(`Error calling getter ${key}`, error);
              }
            }
          });
        return JSON.stringify(jsonObj, undefined, 4);
    }

    public static className(obj: object): string {
        return obj.constructor.name;
    }

    public static objectsAreShallowEqualUnordered(obj1: object, obj2: object): boolean {
      if (Object.entries(obj1).length !== Object.entries(obj2).length) {
        return false;
      }

      const obj2Map = new Map(Object.entries(obj2));
      const isEqual = Object.entries(obj1).every((keyValPair) => {
        if (!obj2Map.has(keyValPair[0]) || (keyValPair[1] !== obj2Map.get(keyValPair[0]))) {
          return false;
        }
        return true;
      });

      return isEqual;
    }
}
