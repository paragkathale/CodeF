import { logger } from '@drumg/long-island-tea';
import program = require('commander');
import dotenv = require('dotenv');
import process = require('process');
import packageInfo = require('../../package.json');
import { ObjectUtils } from './object-utils';

export class Configuration {

    get name(): string {
        return packageInfo.name;
    }

    get javaPubsubTestServiceUrl(): string {
        return (program.javaPubsubTestServiceUrl || process.env.JAVA_PUBSUB_TEST_SVC_URL)!;
    }

    get serviceBusConnectionString(): string {
        return process.env.AZ_SB_CONNECTION_STRING!;
    }

    get port(): number {
        return program.port || process.env.PORT || 18903;
    }

    get testTopic(): string {
        return process.env.TEST_TOPIC || 'pubsub-test';
    }

    get testSubscription(): string {
        return 'test-sub';
    }

    get logLevel(): string {
        return logger.level;
    }

    get defaultTimeout(): number {  // in ms
        return 10000;
    }

    public static getInstance(): Configuration {
        if (!Configuration._instance) {
            Configuration._instance = new Configuration();
            Configuration._instance.load();
        }
        return Configuration._instance;
    }

    private static _instance: Configuration;

    private static parseCommandlineArguments() {
        program
        .option('-p, --port <n>', `Port which this service listens to`, parseInt)
        .option('-e, --env-file [path]', 'Environment file to use')
        .option('-S, --sensitive', 'enable logging of sensitive information')
        .parse(process.argv);
    }

    private constructor() {}

    public toJSON(): string {
        const excludeProperties = new Set<string>([
            'serviceBusConnectionString'
        ]);

        const exclude = program.sensitive ? new Set<string>() : excludeProperties;
        return ObjectUtils.toJSON(this, exclude);
    }

    private load() {
        Configuration.parseCommandlineArguments();
        const envFile = program.envFile || '.env';
        dotenv.load({path: envFile});
    }
}

export let config = Configuration.getInstance();
