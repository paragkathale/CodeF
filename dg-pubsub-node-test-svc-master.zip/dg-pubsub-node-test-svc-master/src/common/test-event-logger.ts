import { logger } from '@drumg/long-island-tea';
import { PubsubTestMode } from './pubsub-test-mode';

export enum TestEventType {
    start   = 'START',
    success = 'SUCCESS',
    failure = 'FAILURE',
    pending = 'PENDING'
}

export class TestEventLogger {

    public static readonly _prefix = '[SERVICE-BUS-TEST]';

    public static log(eventType: TestEventType, testMode: PubsubTestMode, message: string) {
        const testModeStr = TestEventLogger.lookupTestModeStr(testMode);
        logger.info(`${this._prefix}[${testModeStr}][${eventType}] ${message}`);
    }

    private static lookupTestModeStr(testMode: PubsubTestMode) {
        let testModeStr;
        switch (testMode) {
            case PubsubTestMode.StandardJavaTest: {
                testModeStr = 'JAVA-TEST';
                break;
            }
            case PubsubTestMode.StandardNodeTest: {
                testModeStr = 'NODE-TEST';
                break;
            }
            default: {
                testModeStr = 'UNKNOWN-TEST';
                break;
            }
        }
        return testModeStr;
    }
}
