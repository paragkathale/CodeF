import {config} from './configuration';

export class TestMessage {
    private static _source = config.name;
    private readonly _testId: string;
    private _sequenceNum: number = 0;

    public get testId(): string {
        return this._testId;
    }

    public get sequenceNum(): number {
        return this._sequenceNum;
    }

    public constructor(testId: string) {
        this._testId = testId;
    }

    public createNext(): string {
        const message = {
            testId: this.testId,
            sequenceNum: ++(this._sequenceNum),
            source: TestMessage._source,
            timestamp: Date.now()
        };

        return JSON.stringify(message);
    }
}
