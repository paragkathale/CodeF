export enum PubsubTestMode {
    StandardNodeTest,
    StandardJavaTest
}
