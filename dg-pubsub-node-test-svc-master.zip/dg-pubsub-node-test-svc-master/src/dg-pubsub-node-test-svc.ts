'use strict';
import { logger } from '@drumg/long-island-tea';
import http = require('http');
import path = require('path');
import process = require('process');
import app from './app';
import { config } from './common/configuration';
import { TestMessageConsumer } from './consumers/test-message-consumer';

const defaultPort = config.port;
const serviceName = path.basename(__filename).split('.').slice(0, -1).join();
process.title = serviceName;

let server: http.Server;

export { defaultPort, server, serviceName };

process.on('SIGTERM', () => {
    logger.info(`${serviceName} gracefully shut down`);
    if (server) { server.close(); }
    process.exit();
});

async function main() {
    server = app.listen(config.port, () => logger.info(`${serviceName} listening on port ${config.port}`));
    const consumer = new TestMessageConsumer();
    await consumer.start();
}

main().then();
