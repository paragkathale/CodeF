import express = require('express');
import * as controllers from './controllers';

const app = express();

app.get('/healthcheck', controllers.HealthcheckController.get);
app.get('/runJavaTest', controllers.PubsubJavaTestController.get);
app.get('/runNodeTest', controllers.PubsubNodeTestController.get);

app.use((_req, res) => {
    res.sendStatus(404);
});

export default app;
