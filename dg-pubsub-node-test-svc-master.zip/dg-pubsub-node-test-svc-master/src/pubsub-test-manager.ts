import { logger } from '@drumg/long-island-tea';
import { PubsubTestMode } from './common/pubsub-test-mode';
import { PubsubTester } from './pubsub-tester';

// TODO_LATER: make this support more than one test at a time
export class PubsubTestManager {

    public static getInstance(): PubsubTestManager {
        if (!this._instance) {
            this._instance = new PubsubTestManager();
        }
        return this._instance;
    }

    private static _instance?: PubsubTestManager;

    private _tester?: PubsubTester;

    private constructor() {}

    public addTester(tester: PubsubTester) {
        // TODO_LATER: currently only holds latest tester. Add support for more
        this._tester = tester;
    }

    public getTester(testId: string): PubsubTester {
        if (this._tester && this._tester.testId === testId) {
            return this._tester;
        }
        throw new Error(`testId ${testId} not found`);
    }

    public initiateAddTest(testMode: PubsubTestMode, messageCount: number): string {
        try {
            const tester = new PubsubTester(testMode, messageCount);
            this.addTester(tester);
            tester.start().catch((error) => {
                logger.error(`test ${tester.testId} failed: ${error}`);
            });
            return tester.testId;
        } catch (error) {
            logger.error(`failed to start test with type ${testMode}: ${error}`);
            throw error;
        }
    }

}
