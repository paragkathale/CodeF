<p align="center">
  <img src="https://www.drumg.com/wp-content/themes/drumg/dist/img/logo.png" alt="DrumG" width="500">
</p>

# DrumG Sample Node Service

This repo contains the source for DrumG's sample Node service template. 

# Pre-Requisites

This service contains best-practices and defaults that any DrumG Node service should have.  Refer to 
[Service Standards](https://drumg1.atlassian.net/wiki/spaces/ENG/pages/111280183/Service+Standards) for
the comprehensive list of standards, both in code implementation and in documentation.

This service implements:
- README documentation
- CHANGELOG documentation
- Proper files naming convention
- Proper directory structure
- Must-have npm script targets and default commands
- Must-have systemd service file and script
- Default healthcheck end-point
- Default process shutdown handling
- CircleCI configuration
- Use of common DrumG library package, e.g., logger
- Typescript linting
- SonarCloud integration
- Test coverage reporting

# Service Information

| Attribute | Info |
| --------- | ---- |
| Owner | DrumG Engineering Team (Must be a named individual for other services) |
| Co-Owner | DrumG Engineering Team (Must be a named individual for other services) |
| Service Port | 18900 |
| Network Zone | App network (choice of DMZ, User zone, App zone and DLT zone) |

# API Reference

## GET /healthcheck

Returns status 200 "OK" if the service is responsive.

### Example Response body
```json
{
    "status": "ok",
    "msg": "I am alive" 
}
```

# Development Usage

## Install

Obtain an API token from https://packagecloud.io for access to DrumG's private package repo.  Then run:

    export PKGCLOUD_NPM_TOKEN=<token-value>
    npm install @drumg/long-island-tea --save

### Commands

- `npm run build` to download pre-requisites like NPM packages, compile contracts and services files.
- `npm run start` to start service
- `npm run stop` to stop service
- `npm run clean` to clean runtime files and built package
- `npm run test` to execute unit tests
- `npm run check-license` to check dependency licenses
