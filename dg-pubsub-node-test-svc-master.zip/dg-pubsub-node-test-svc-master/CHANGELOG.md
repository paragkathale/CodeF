# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
### Changed
- Any unreleased changes.

## [0.0.4] - 2019-02-06
### Changed
- Split app and service entry and added test for service startup

## [0.0.3] - 2019-02-05
### Added
- Unit test on healthcheck end-point

## [0.0.2] - 2019-01-30
### Added
- Simple healthcheck end-point and graceful shutdown from SIGTERM

### Changed
- More meaningful README information for this service  

## [0.0.1] - 2019-01-29
### Added
- Initial sample Node service files following [DrumG service standards](https://drumg1.atlassian.net/wiki/spaces/ENG/pages/111280183/Service+Standards)
