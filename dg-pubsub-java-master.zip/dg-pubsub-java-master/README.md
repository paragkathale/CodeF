<p align="center">
    <img src="https://user-images.githubusercontent.com/8850110/55236247-72848380-5227-11e9-9f56-724960bb6fd7.png" alt="DrumG" width="400" />
    <br/>
</p>

<br/>

<h1>DrumG JVM Pub/Sub Library&nbsp;&nbsp;<a href="https://circleci.com/gh/DrumG/dg-pubsub-java/tree/master" target="_blank"><img src="https://circleci.com/gh/DrumG/dg-pubsub-java/tree/master.svg?style=shield&circle-token=4d564657a8e74109c0b8bcb559bd66d89c20ef89" alt="CircleCI Status Badge"/></a></h1>

This repo contains the source for DrumG's AMQP pub/sub library for JVM languages. This library can be used to
exchange messages over Azure Service Bus or a local message broker like ActiveMQ.

## Usage

### Generate a read token

Since the DrumG packagecloud Maven repository is private, you'll need to generate a read token in order to access it.

### Add the packagecloud repository to Gradle

```groovy
repositories {
    maven { url 'https://packagecloud.io/priv/${token}/drumg/core-java/maven2' }
}
```

### Add the dependency
```gradle
dependencies {
    compile 'com.drumg.utils:pubsub:3.0.2'
}
```


## Examples

### Initialize message queue factory

Initialize the message queue factory by specifying a connection string:
```java
// Java
MessageQueueFactory factory = new AmqpMessageQueueFactory(
    "Endpoint=amq://localhost;SharedAccessKeyName=admin;SharedAccessKey=admin"
);
```

```kotlin
// Kotlin
val factory = AmqpMessageQueueFactory(
    "Endpoint=amq://localhost;SharedAccessKeyName=admin;SharedAccessKey=admin"
)
```

The connection string needs to be in the following format:
```
Endpoint=<protocol>://<host>;SharedAccessKeyName=<username>;SharedAccessKey=<password>
```

In case of Azure Service Bus, the connection string can be copied from a _Shared access policy_'s properties and looks like this:
```
Endpoint=sb://dgfinplay.servicebus.windows.net/;SharedAccessKeyName=TestFullPolicy;SharedAccessKey=xxx
```

To connect to a local implementation, like ActiveMQ, the following connection string should work:
```
Endpoint=amq://localhost;SharedAccessKeyName=admin;SharedAccessKey=admin
```

### Send a message to a topic
First, define the class that will encapsulate the message:

```java
// Java
public class TestMessage extends BaseMessage {
    public TestMessage(String body) {
        super("1.0.0", body);
    }
}
```

```kotlin
// Kotlin
class TestMessage(body: String): BaseMessage("1.0.0", body)
```

Then create the publisher using the message queue factory and send the message:
```java
// Java
Publisher publisher = factory.createPublisher("amqp-test");

publisher.send(new TestMessage("hello from the JVM"));
```

```kotlin
// Kotlin
val publisher = factory.createPublisher("amqp-test")

publisher.send(TestMessage("hello from the JVM"))
```

### Release resources
```java
// Java
publisher.close();
factory.close();
```

```kotlin
// Kotlin
publisher.close()
factory.close()
```

## Development Usage

### Test

Run `gradle test`.
