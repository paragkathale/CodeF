package com.drumg.utils.pubsub;

import com.drumg.utils.pubsub.factory.ConnectionOptions;
import com.drumg.utils.pubsub.factory.MessageQueueFactory;
import com.drumg.utils.pubsub.factory.MessageQueueImplementation;
import com.drumg.utils.pubsub.factory.impl.AmqpMessageQueueFactory;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class AmqpMessageQueueFactoryTest {
    @Test
    public void connectionStringMissingProperty() {
        Exception ex = assertThrows(IllegalArgumentException.class, () -> {
            new AmqpMessageQueueFactory("SharedAccessKeyName=admin;SharedAccessKey=admin");
        });
        assertEquals("Missing properties from connection string", ex.getMessage());
    }

    @Test
    public void connectionStringInvalidEndpoint() {
        Exception ex = assertThrows(IllegalArgumentException.class, () -> {
            new AmqpMessageQueueFactory("Endpoint=localhost;SharedAccessKeyName=admin;SharedAccessKey=admin");
        });
        assertEquals("Invalid Endpoint in connection string", ex.getMessage());

    }

    @Test
    public void connectionStringUnknownMessageBusImplementation() {
        Exception ex = assertThrows(IllegalArgumentException.class, () -> {
            new AmqpMessageQueueFactory("Endpoint=unk://localhost;SharedAccessKeyName=admin;SharedAccessKey=admin");
        });
        assertEquals("Unknown message bus implementation", ex.getMessage());
    }

    @Test
    public void connectionStringValid() {
        MessageQueueFactory factory = new AmqpMessageQueueFactory("Endpoint=amq://localhost;SharedAccessKeyName=admin;SharedAccessKey=admin");
        ConnectionOptions connectionOptions = factory.getConnectionOptions();

        assertEquals("localhost", connectionOptions.getHost());
        assertEquals("admin", connectionOptions.getUsername());
        assertEquals("admin", connectionOptions.getPassword());
        assertEquals(MessageQueueImplementation.ActiveMQ, connectionOptions.getImplementation());
    }
}
