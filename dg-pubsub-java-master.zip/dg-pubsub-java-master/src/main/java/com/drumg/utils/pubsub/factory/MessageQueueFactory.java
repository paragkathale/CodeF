package com.drumg.utils.pubsub.factory;

import com.drumg.utils.pubsub.link.Publisher;

public interface MessageQueueFactory {
    ConnectionOptions getConnectionOptions();

    Publisher createPublisher(String rawTopic);

    void close();
}
