package com.drumg.utils.pubsub.factory.impl;

import com.drumg.utils.pubsub.factory.ConnectionOptions;
import com.drumg.utils.pubsub.factory.MessageQueueFactory;
import com.drumg.utils.pubsub.factory.MessageQueueImplementation;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public abstract class BaseMessageQueueFactory implements MessageQueueFactory {
    private static final Pattern endpointRegexp = Pattern.compile("(\\w+)://([^/]+)");

    protected enum ConnectionStringProperty {
        Hostname("Endpoint"),
        Username("SharedAccessKeyName"),
        Password("SharedAccessKey");

        private final String key;

        ConnectionStringProperty(String key) {
            this.key = key;
        }
    }

    protected static ConnectionOptions parseConnectionString(String connectionString) {
        Map<String, String> props = Arrays.stream(connectionString.split(";"))
                .filter(part -> part.indexOf('=') != -1)
                .map(part -> {
                    int idx = part.indexOf('=');
                    return Pair.of(part.substring(0, idx), part.substring(idx + 1));
                })
                .collect(Collectors.toMap(Pair::getKey, Pair::getValue));

        boolean hasMissingKeys = Arrays.stream(ConnectionStringProperty.values())
                .anyMatch(prop -> !props.containsKey(prop.key));

        if (hasMissingKeys) {
            throw new IllegalArgumentException("Missing properties from connection string");
        }

        Matcher matcher = endpointRegexp.matcher(props.get(ConnectionStringProperty.Hostname.key));
        if (!matcher.find()) {
            throw new IllegalArgumentException("Invalid Endpoint in connection string");
        }

        String protocol = matcher.group(1);
        String host = matcher.group(2);

        Optional<MessageQueueImplementation> implementation = Arrays.stream(MessageQueueImplementation.values())
                .filter(impl -> impl.getProtocol().equals(protocol))
                .findFirst();

        if (!implementation.isPresent()) {
            throw new IllegalArgumentException("Unknown message bus implementation");
        }

        ConnectionOptions connectionOptions = new ConnectionOptions(implementation.get(), host);

        switch (implementation.get()) {
            case AzureServiceBus:
                connectionOptions.setPort(5671);
                connectionOptions.setSsl(true);
                break;
            case ActiveMQ:
                connectionOptions.setPort(5672);
                break;
        }

        connectionOptions.setUsername(props.get(ConnectionStringProperty.Username.key));
        connectionOptions.setPassword(props.get(ConnectionStringProperty.Password.key));

        return connectionOptions;
    }

    protected static String getTopic(MessageQueueImplementation implementation, String topic) {
        switch (implementation) {
            case AzureServiceBus:
                return topic;
            case ActiveMQ:
            default:
                return String.format("topic://%s", topic);
        }
    }
}
