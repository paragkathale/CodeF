package com.drumg.utils.pubsub.link.impl;

import org.apache.qpid.proton.engine.Connection;
import org.apache.qpid.proton.engine.Session;

public abstract class BaseProtonLink implements ProtonLink {
    private final String topic;

    private Session session;
    private Connection connection;

    public BaseProtonLink(String topic) {
        this.topic = topic;
    }

    @Override
    public String getTopic() {
        return topic;
    }

    @Override
    public void close() {
        if (session != null) {
            session.close();
        }

        if (connection != null) {
            connection.close();
        }
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }
}
