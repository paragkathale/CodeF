package com.drumg.utils.pubsub.link.impl;

import com.drumg.utils.pubsub.factory.ConnectionOptions;
import com.drumg.utils.pubsub.message.BaseMessage;
import com.drumg.utils.pubsub.utils.UniqueId;
import org.apache.qpid.proton.amqp.Symbol;
import org.apache.qpid.proton.amqp.messaging.Accepted;
import org.apache.qpid.proton.amqp.messaging.Modified;
import org.apache.qpid.proton.amqp.messaging.Target;
import org.apache.qpid.proton.amqp.transport.DeliveryState;
import org.apache.qpid.proton.amqp.transport.ErrorCondition;
import org.apache.qpid.proton.amqp.transport.SenderSettleMode;
import org.apache.qpid.proton.codec.CompositeWritableBuffer;
import org.apache.qpid.proton.codec.DroppingWritableBuffer;
import org.apache.qpid.proton.codec.ReadableBuffer;
import org.apache.qpid.proton.codec.WritableBuffer;
import org.apache.qpid.proton.engine.*;
import org.apache.qpid.proton.message.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.text.MessageFormat;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public class ProtonSenderHandler extends ProtonLinkHandler {
    private final static int SEND_BUFFER_SIZE = 4 * 1024;
    private final static Symbol[] RECONNECT_CONDITIONS = new Symbol[] {
            /*
             * Service Bus sends this error condition after the publisher link is inactive for 10 minutes.
             *
             * Example: Error{
             *   condition=amqp:link:detach-forced,
             *   description='The link 'G47:130219859:dg-dc7cd301-dad1-40ca-9ca3-c079e91fcd32' is force detached by the
             *                broker due to errors occurred in publisher(link2136966).
             *                Detach origin: AmqpMessagePublisher.IdleTimerExpired: Idle timeout: 00:10:00.',
             *   info=null
             * }
             */
            Symbol.valueOf("amqp:link:detach-forced"),

            /*
             * Service Bus sends this error condition after the connection? is inactive for 2 minutes. While it states
             * it is a remote connection disconnect, the error is sent to the link and the peer does not close the
             * underlying session and connection.
             *
             * Example: Error{
             *   condition=amqp:connection:forced,
             *   description='The connection was inactive for more than the allowed 120000 milliseconds and is closed
             *                by container '7A2E0A0515A9427F82D1ACF7F25A024D_G12'.',
             *   info=null
             * }
             *
             * After 5 minutes, the remote broker closes the session and connection as no active links are present with
             * the appropriate error condition: Error{
             *   condition=amqp:connection:forced,
             *   description='The connection was inactive for more than the allowed 300000 milliseconds and is closed
             *                by container 'LinkTracker'. TrackingId:2aca6ad45bc849bd9d389d2708f09869_G12,
             *                SystemTracker:gateway7, Timestamp:2019-03-29T21:09:36',
             *   info=null
             * }
             */
            Symbol.valueOf("amqp:connection:forced")
    };

    private final static Logger logger = LoggerFactory.getLogger(ProtonSenderHandler.class);

    private Sender sender;
    private Thread senderThread;
    private AtomicBoolean isSending;
    private AtomicLong deliveryTag;
    private boolean hasReconnectScheduled;

    public ProtonSenderHandler(ConnectionOptions connectionOptions, ProtonSender protonSender) {
        super(connectionOptions, protonSender);

        deliveryTag = new AtomicLong(0);
        isSending = new AtomicBoolean(false);
        hasReconnectScheduled = false;
    }

    @Override
    public void onSessionRemoteOpen(Event event) {
        openSenderLink(event.getSession());
    }

    @Override
    public void onLinkInit(Event event) {
        Target target = new Target();
        target.setAddress(getProtonLink().getTopic());

        Link link = event.getLink();
        link.setTarget(target);
    }

    @Override
    public void onLinkRemoteOpen(Event event) {
        logger.info("Sender link for host={}, topic={} accepted by remote peer",
                event.getConnection().getHostname(), getProtonLink().getTopic());
    }

    @Override
    public void onLinkFlow(Event event) {
        isSending.set(true);

        senderThread = new Thread(() -> {
            ProtonSender protonSender = (ProtonSender) getProtonLink();

            while (isSending.get()) {
                if (sender.getCredit() > 0) {
                    try {
                        ProtonDelivery protonDelivery = protonSender.getPendingQueue().take();
                        BaseMessage message = protonDelivery.getMessage();
                        Message encodedMessage = message.encode();

                        ByteBuffer buffer = ByteBuffer.allocate(SEND_BUFFER_SIZE);
                        DroppingWritableBuffer overflow = new DroppingWritableBuffer();

                        int length = encodedMessage.encode(new CompositeWritableBuffer(
                                WritableBuffer.ByteBufferWrapper.wrap(buffer),
                                overflow
                        ));

                        if (overflow.position() > 0) {
                            buffer = ByteBuffer.allocate(SEND_BUFFER_SIZE + overflow.position());
                            encodedMessage.encode(WritableBuffer.ByteBufferWrapper.wrap(buffer));
                        }

                        buffer.position(0);
                        buffer.limit(length);

                        byte[] tag = String.valueOf(deliveryTag.getAndIncrement()).getBytes();
                        Delivery delivery = sender.delivery(tag);

                        logger.info("Sending message schema={}, version={}, body=\"{}\" with tag={}",
                                message.getHeader().getSchema(), message.getHeader().getVersion(), message.getBody(),
                                deliveryTag);

                        sender.sendNoCopy(ReadableBuffer.ByteBufferReader.wrap(buffer));

                        delivery.setContext(protonDelivery);
                        protonDelivery.setDelivery(delivery);

                        sender.advance();
                    } catch (InterruptedException ex) {
                        logger.info("Sender thread interrupted");
                    }
                }
            }
        });
        senderThread.setName(MessageFormat.format("{0}-sender-{1}", getProtonLink().getTopic(), senderThread.getId()));
        senderThread.start();
    }

    @Override
    public void onDelivery(Event event) {
        Delivery delivery = event.getDelivery();

        if (!delivery.isSettled() && delivery.remotelySettled()) {
            ProtonSender protonSender = (ProtonSender) getProtonLink();
            ProtonDelivery protonDelivery = (ProtonDelivery) delivery.getContext();
            BaseMessage message = protonDelivery.getMessage();

            DeliveryState state = delivery.getRemoteState();

            logger.info("Message schema={}, version={}, body=\"{}\" delivered with remote state={}",
                    message.getHeader().getSchema(), message.getHeader().getVersion(), message.getBody(), state);

            try {
                switch (delivery.getRemoteState().getType()) {
                    case Accepted:
                        delivery.disposition(new Accepted());
                        break;

                    case Rejected:
                        message.incrementDeliveryCount();
                        protonDelivery.setDelivery(null);
                        protonSender.getPendingQueue().put(protonDelivery);
                        break;

                    case Released:
                        protonDelivery.setDelivery(null);
                        protonSender.getPendingQueue().put(protonDelivery);
                        break;

                    case Modified:
                        Modified modifiedState = (Modified) state;
                        if (modifiedState.getDeliveryFailed()) {
                            message.incrementDeliveryCount();
                        }
                        break;
                }
            } catch (InterruptedException ex) {
                logger.error("Failed to resubmit message to pending queue", ex);
            }

            delivery.settle();
        } else {
            logger.error("Got invalid remote settle state={} or local settle state={} on delivery",
                    delivery.remotelySettled(), delivery.isSettled());
        }
    }

    @Override
    public void onLinkRemoteClose(Event event) {
        ErrorCondition error = event.getLink().getRemoteCondition();

        logger.info("Sender link for host={}, topic={} closed by remote peer with error={}",
                getProtonLink().getTopic(), event.getConnection().getHostname(), error);

        if (error.getCondition() == null && event.getLink().getRemoteState() == EndpointState.CLOSED) {
            hasReconnectScheduled = true;
        } else {
            for (Symbol condition : RECONNECT_CONDITIONS) {
                if (condition.equals(error.getCondition())) {
                    hasReconnectScheduled = true;
                    break;
                }
            }
        }

        super.onLinkRemoteClose(event);
    }

    @Override
    public void onLinkLocalClose(Event event) {
        ErrorCondition error = event.getLink().getCondition();

        logger.debug("Sender link for host={}, topic={} closed with error={}",
                getProtonLink().getTopic(), event.getConnection().getHostname(), error);

        if (senderThread != null) {
            isSending.set(false);
            senderThread.interrupt();
        }

        super.onLinkLocalClose(event);
    }

    @Override
    public void onLinkFinal(Event event) {
        if (hasReconnectScheduled) {
            hasReconnectScheduled = false;

            logger.info("Reconnecting sender link for host={}, topic={}",
                    event.getConnection().getHostname(), getProtonLink().getTopic());

            openSenderLink(event.getSession());
        }
    }

    private void openSenderLink(Session session) {
        sender = session.sender(UniqueId.generate());
        sender.setSenderSettleMode(SenderSettleMode.UNSETTLED);
        sender.open();

        ((ProtonSender) getProtonLink()).setSender(sender);
    }
}
