package com.drumg.utils.pubsub.link.impl;

import com.drumg.utils.pubsub.factory.ConnectionOptions;
import org.apache.qpid.proton.engine.BaseHandler;
import org.apache.qpid.proton.engine.Event;

public class ProtonReactorHandler extends BaseHandler {
    private final ProtonLinkHandler handler;
    private final ConnectionOptions connectionOptions;

    public ProtonReactorHandler(ProtonLinkHandler handler) {
        this.handler = handler;
        this.connectionOptions = handler.getConnectionOptions();
    }

    @Override
    public void onReactorInit(Event event) {
        event.getReactor().connectionToHost(connectionOptions.getHost(), connectionOptions.getPort(), handler);
    }
}
