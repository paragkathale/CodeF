package com.drumg.utils.pubsub.factory;

public class ConnectionOptions {
    private final MessageQueueImplementation implementation;
    private final String host;
    private int port;
    private String username;
    private String password;
    private boolean isSsl;

    public ConnectionOptions(MessageQueueImplementation implementation, String host) {
        this.implementation = implementation;
        this.host = host;
        this.port = 5672;
        this.isSsl = false;
    }

    public MessageQueueImplementation getImplementation() {
        return implementation;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isSsl() {
        return isSsl;
    }

    public void setSsl(boolean ssl) {
        isSsl = ssl;
    }
}
