package com.drumg.utils.pubsub.link;

import com.drumg.utils.pubsub.message.BaseMessage;

public interface Publisher {
    Delivery send(BaseMessage message);

    boolean isOpen();

    void close();
}
