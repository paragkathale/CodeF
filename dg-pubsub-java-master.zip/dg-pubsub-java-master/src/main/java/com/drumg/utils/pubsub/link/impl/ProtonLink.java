package com.drumg.utils.pubsub.link.impl;

interface ProtonLink {
    String getTopic();

    void close();
}
