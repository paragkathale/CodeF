package com.drumg.utils.pubsub.message;

import org.apache.qpid.proton.Proton;
import org.apache.qpid.proton.amqp.Binary;
import org.apache.qpid.proton.amqp.messaging.Data;
import org.apache.qpid.proton.message.Message;

import java.nio.charset.StandardCharsets;

public abstract class BaseMessage {
    private final MessageHeader header;
    private final String body;
    private int deliveryCount;

    public BaseMessage(String version, String body) {
        this.header = new MessageHeader(version, getClass().getSimpleName());
        this.body = body;
        this.deliveryCount = 0;
    }

    public BaseMessage(String version, String body, String schema) {
        this.header = new MessageHeader(version, schema);
        this.body = body;
        this.deliveryCount = 0;
    }

    public MessageHeader getHeader() {
        return header;
    }

    public String getBody() {
        return body;
    }

    public Message encode() {
        Message msg = Proton.message();

        msg.setContentType("application/octet-stream");
        msg.setApplicationProperties(header.encode());
        msg.setDeliveryCount(deliveryCount);
        msg.setBody(new Data(new Binary(body.getBytes(StandardCharsets.UTF_8))));

        if (header.getCorrelationId() != null) {
            msg.setCorrelationId(header.getCorrelationId());
        }

        return msg;
    }

    public void incrementDeliveryCount() {
        deliveryCount++;
    }
}
