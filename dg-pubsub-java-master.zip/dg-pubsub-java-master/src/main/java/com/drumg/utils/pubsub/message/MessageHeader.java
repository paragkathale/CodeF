package com.drumg.utils.pubsub.message;

import org.apache.qpid.proton.amqp.messaging.ApplicationProperties;

import java.util.HashMap;
import java.util.Map;

public class MessageHeader {
    private final String version;
    private final String schema;
    private String context;
    private String correlationId;

    public MessageHeader(String version, String schema) {
        this.version = version;
        this.schema = schema;
    }

    public String getVersion() {
        return version;
    }

    public String getSchema() {
        return schema;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    ApplicationProperties encode() {
        Map<String, Object> props = new HashMap<>();

        props.put("version", version);
        props.put("schema", schema);

        if (context != null) {
            props.put("context", context);
        }

        return new ApplicationProperties(props);
    }
}
