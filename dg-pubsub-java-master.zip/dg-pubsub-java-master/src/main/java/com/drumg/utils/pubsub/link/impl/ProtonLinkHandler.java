package com.drumg.utils.pubsub.link.impl;

import com.drumg.utils.pubsub.factory.ConnectionOptions;
import com.drumg.utils.pubsub.utils.UniqueId;
import org.apache.qpid.proton.Proton;
import org.apache.qpid.proton.engine.*;
import org.apache.qpid.proton.reactor.FlowController;
import org.apache.qpid.proton.reactor.Handshaker;
import org.apache.qpid.proton.reactor.Reactor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class ProtonLinkHandler extends BaseHandler {
    private static final Logger logger = LoggerFactory.getLogger(ProtonLinkHandler.class);

    private final ConnectionOptions connectionOptions;
    private final BaseProtonLink protonLink;

    public ProtonLinkHandler(ConnectionOptions connectionOptions, BaseProtonLink protonLink) {
        this.connectionOptions = connectionOptions;
        this.protonLink = protonLink;

        add(new Handshaker());
        add(new FlowController());
    }

    @Override
    public void onUnhandled(Event event) {
        logger.debug(event.toString());
    }

    @Override
    public void onConnectionInit(Event event) {
        Connection connection = event.getConnection();
        connection.setContainer(UniqueId.generate());
        connection.setHostname(connectionOptions.getHost());

        Session session = connection.session();

        connection.open();
        session.open();

        logger.debug("Connection for host={} initiated with context={}",
                connection.getHostname(), connection.getContext());

        protonLink.setSession(session);
        protonLink.setConnection(connection);
    }

    @Override
    public void onConnectionLocalOpen(Event event) {
        logger.debug("Connection for host={} opened locally", event.getConnection().getHostname());
    }

    @Override
    public void onConnectionBound(Event event) {
        Connection connection = event.getConnection();
        Transport transport = connection.getTransport();

        if (transport != null) {
            logger.debug("Connection for host={} is bound, initiating SASL authentication", connection.getHostname());

            transport.setEmitFlowEventOnSend(false);

            Sasl sasl = transport.sasl();
            sasl.setMechanisms("PLAIN");
            sasl.plain(connectionOptions.getUsername(), connectionOptions.getPassword());
            sasl.client();

            if (connectionOptions.isSsl()) {
                SslDomain domain = Proton.sslDomain();
                domain.init(SslDomain.Mode.CLIENT);
                domain.setPeerAuthentication(SslDomain.VerifyMode.ANONYMOUS_PEER);

                transport.ssl(domain);
            }
        }
    }

    @Override
    public void onConnectionRemoteOpen(Event event) {
        logger.info("Connection for host={} accepted by remote peer", event.getConnection().getHostname());
    }

    @Override
    public void onConnectionRemoteClose(Event event) {
        Connection connection = event.getConnection();

        logger.info("Connection for host={} closed by remote peer with error={}",
                connection.getHostname(), connection.getRemoteCondition());

        if (connection.getLocalState() == EndpointState.CLOSED) {
            connection.free();
        }
    }

    @Override
    public void onConnectionLocalClose(Event event) {
        Connection connection = event.getConnection();

        logger.debug("Connection for host={} closed with error={}",
                connection.getHostname(), connection.getRemoteCondition());

        if (connection.getRemoteState() == EndpointState.CLOSED) {
            if (connection.getTransport() != null) {
                connection.getTransport().unbind();
            }

            connection.free();
        }
    }

    @Override
    public void onLinkRemoteClose(Event event) {
        Link link = event.getLink();

        if (link.getLocalState() == EndpointState.CLOSED) {
            link.free();
        }
    }


    @Override
    public void onLinkLocalClose(Event event) {
        Link link = event.getLink();

        if (link.getRemoteState() == EndpointState.CLOSED) {
            link.free();
        }
    }

    @Override
    public void onConnectionFinal(Event event) {
        Reactor reactor = event.getReactor();
        reactor.stop();
        reactor.free();
    }

    @Override
    public void onTransportError(Event event) {
        logger.error("Transport closed with error={}", event.getTransport().getCondition());
    }

    protected ProtonLink getProtonLink() {
        return protonLink;
    }

    public ConnectionOptions getConnectionOptions() {
        return connectionOptions;
    }
}
