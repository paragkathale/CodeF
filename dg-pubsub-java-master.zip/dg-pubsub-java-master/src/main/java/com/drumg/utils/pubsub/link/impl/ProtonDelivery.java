package com.drumg.utils.pubsub.link.impl;

import com.drumg.utils.pubsub.message.BaseMessage;
import org.apache.qpid.proton.engine.Delivery;

public class ProtonDelivery implements com.drumg.utils.pubsub.link.Delivery<Delivery> {
    private final BaseMessage message;
    private Delivery delivery;

    public ProtonDelivery(BaseMessage message) {
        this.message = message;
    }

    @Override
    public BaseMessage getMessage() {
        return message;
    }

    public void setDelivery(Delivery delivery) {
        this.delivery = delivery;
    }

    @Override
    public Delivery getDelivery() {
        return delivery;
    }
}
