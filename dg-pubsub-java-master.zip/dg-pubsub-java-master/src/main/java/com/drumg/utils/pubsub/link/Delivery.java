package com.drumg.utils.pubsub.link;

import com.drumg.utils.pubsub.message.BaseMessage;

public interface Delivery<T> {
    BaseMessage getMessage();

    T getDelivery();
}
