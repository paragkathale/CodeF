package com.drumg.utils.pubsub.factory;

public enum MessageQueueImplementation {
    AzureServiceBus("sb"),
    ActiveMQ("amq");

    private final String protocol;

    MessageQueueImplementation(String protocol) {
        this.protocol = protocol;
    }

    public String getProtocol() {
        return protocol;
    }
}
