package com.drumg.utils.pubsub.factory.impl;

import com.drumg.utils.pubsub.factory.ConnectionOptions;
import com.drumg.utils.pubsub.link.Publisher;
import com.drumg.utils.pubsub.link.impl.ProtonReactorHandler;
import com.drumg.utils.pubsub.link.impl.ProtonSender;
import com.drumg.utils.pubsub.link.impl.ProtonSenderHandler;
import org.apache.qpid.proton.Proton;
import org.apache.qpid.proton.reactor.Reactor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.MessageFormat;

public class AmqpMessageQueueFactory extends BaseMessageQueueFactory {
    private final static Logger logger = LoggerFactory.getLogger(AmqpMessageQueueFactory.class);

    private final ConnectionOptions connectionOptions;

    public AmqpMessageQueueFactory(String connectionString) {
        this.connectionOptions = parseConnectionString(connectionString);
    }

    @Override
    public ConnectionOptions getConnectionOptions() {
        return connectionOptions;
    }

    @Override
    public Publisher createPublisher(String rawTopic) {
        String topic = getTopic(connectionOptions.getImplementation(), rawTopic);

        ProtonSender sender = new ProtonSender(topic);
        Thread thread = new Thread(() -> {
            try {
                Reactor reactor = Proton.reactor(
                        new ProtonReactorHandler(new ProtonSenderHandler(connectionOptions, sender))
                );
                reactor.run();
            } catch (IOException ex) {
                logger.error("Failed to create Proton reactor", ex);
            }
        });
        thread.setName(MessageFormat.format("{0}-reactor-{1}", topic, thread.getId()));
        thread.start();

        return sender;
    }

    @Override
    public void close() {
    }
}
