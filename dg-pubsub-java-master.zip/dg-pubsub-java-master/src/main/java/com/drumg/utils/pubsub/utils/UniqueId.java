package com.drumg.utils.pubsub.utils;

import java.text.MessageFormat;
import java.util.UUID;

public class UniqueId {
    public static String generate() {
        return MessageFormat.format("dg-{0}", UUID.randomUUID().toString());
    }
}
