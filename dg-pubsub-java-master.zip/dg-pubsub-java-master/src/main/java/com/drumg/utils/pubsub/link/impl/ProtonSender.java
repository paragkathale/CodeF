package com.drumg.utils.pubsub.link.impl;

import com.drumg.utils.pubsub.link.Publisher;
import com.drumg.utils.pubsub.message.BaseMessage;
import org.apache.qpid.proton.engine.EndpointState;
import org.apache.qpid.proton.engine.Sender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ProtonSender extends BaseProtonLink implements Publisher {
    private static final Logger logger = LoggerFactory.getLogger(ProtonSender.class);

    private Sender sender;
    private final BlockingQueue<ProtonDelivery> pendingQueue = new LinkedBlockingQueue<>();

    public ProtonSender(String topic) {
        super(topic);
    }

    @Override
    public ProtonDelivery send(BaseMessage message) {
        ProtonDelivery delivery = new ProtonDelivery(message);

        try {
            logger.info("Queuing message schema={}, version={}, body=\"{}\"",
                    message.getHeader().getSchema(), message.getHeader().getVersion(), message.getBody());

            pendingQueue.put(delivery);
        } catch (InterruptedException ex) {
            logger.error("Failed to put message to pending queue", ex);
        }

        return delivery;
    }

    @Override
    public boolean isOpen() {
        return sender != null && sender.getRemoteState() == EndpointState.ACTIVE;
    }

    @Override
    public void close() {
        sender.close();
        super.close();
    }

    BlockingQueue<ProtonDelivery> getPendingQueue() {
        return pendingQueue;
    }

    public void setSender(Sender sender) {
        this.sender = sender;
    }
}
