'use strict';

import chai = require('chai');
import { expect } from 'chai';
import chaiHttp = require('chai-http');
import dotenv = require('dotenv');
import nock = require('nock');
import process = require('process');
import { Server } from '../src/server';

chai.use(chaiHttp);
dotenv.load({path: __dirname + '/../.env'});

describe ('Dicitonary SVC Tests', () => {
    before(() => {
        Server.start(0); // arbitrary port number
    });

    beforeEach(() => {
        nock(process.env.DLT_SVC || '')
            .get('/me')
            .reply(200, { me: { name: 'org_name'} });
    });

    it('/api/v1/fund should return 200 Happy Path', (done) => {
        chai.request(Server.instance)
            .get('/api/v1/fund?accountNumber=P39009')
            .end((_err, res) => {
                expect(res.status).to.equal(200);
                done();
            });
    });

    it('/api/v1/all should return 200 Happy Path', (done) => {
        chai.request(Server.instance)
            .get('/api/v1/fund')
            .end((_err, res) => {
                expect(res.status).to.equal(200);
                done();
            });
    });

    it('/api/v1/fund endpoint should return 200 Happy Path. No Data Passed', (done) => {
        chai.request(Server.instance)
            .get('/api/v1/fund?')
            .end((_err, res) => {
                expect(res.status).to.equal(200);
                done();
            });
    });

    it('/api/v1/me should return cell identity', (done) => {
        chai.request(Server.instance)
            .get('/api/v1/me')
            .end((_err, res) => {
                expect(res.status).to.equal(200);
                done();
            });
    });

    it('/healthcheck returns status 200', (done) => {
        chai.request(Server.instance)
            .get('/healthcheck')
            .end((_err, res) => {
                expect(res.status).to.equal(200);
                expect(JSON.parse(res.text)).to.deep.equal({ status: 'ok', msg: 'I am alive'});
                done();
            });
    });
});
