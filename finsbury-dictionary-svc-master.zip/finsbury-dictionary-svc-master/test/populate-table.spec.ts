'use strict';

import { AzureStringUtils, AzureTableUtils } from '@drumg/cloud-services';
import azure = require('azure-storage');
import { expect } from 'chai';
import dotenv = require('dotenv');
import { populateFundTable } from '../src/service/populate-fund-table';

const tableName: string = 'ParticipationMap';
const rootDir: string = __dirname + '/../';
const JPMParticipants: any = {
    Administrator: 'Corda_FA',
    Broker: 'Corda_CU',
    Manager: 'Corda_IM',
    AccountNumber: 'JPM'
};

dotenv.load({path: rootDir + '.env'});

describe('Test Populate Table', () => {

    let tableService: AzureTableUtils;

    before(async () => {
        tableService = new AzureTableUtils(tableName, process.env.AZURE_TABLE_CONNECTION_STRING);
        await populateFundTable();
    });

    it('Test Should Populate Table with correct values', async () => {
        const accountNumber = 'JPM';
        const query = new azure.TableQuery()
            .select('AccountNumber, Manager, Administrator, Broker')
            .where(`AccountNumber == ?string?`, accountNumber);
        const result = await tableService.queryAll(query);
        const prettyifyResult = AzureStringUtils.prettifyAzureQuery(result);
        const resultRow = prettyifyResult[0];

        Object.keys(JPMParticipants).forEach((prop) => {
            expect(JPMParticipants[prop]).to.equal(resultRow[prop]);
        });
    });

});
