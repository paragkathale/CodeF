[![CircleCI](https://circleci.com/gh/DrumG/finsbury-dictionary-svc/tree/master.svg?style=shield&circle-token=f7512b7ab4ec3f7bcb344e2278b0a33488f1d9de)](https://circleci.com/gh/DrumG/finsbury-dictionary-svc/tree/master)

<p align="center">
  <img src="https://www.drumg.com/wp-content/themes/drumg/dist/img/logo.png" alt="DrumG" width="500">
</p>

# Finsbury Dictionary Service

Service responsible for returning a nodes valid participant information. To run ```npm install && npm start```. Server running on ``localhost:1115/api/dictionary/``. To query pass ``party`` and ``account``.

# Development Usage

## Starting the web server

Add envionrment variables to `.env` file under project root directory, then run the following commands:

    npm install
    npm run build
    npm start

### Populating the Participants Table

Running ```npm start``` or ``` npm run populate-fund-table``` will also populate the Participants Table automatically before the dictionary endpoint is created.

### Sample participants.csv file:

```
PartitionKey,AccountNumber,Administrator,Broker,Manager
001,JPM,Corda_FA,Corda_CU,Corda_IM
001,JPMC,Corda_FA,Corda_CU,Corda_IM
001,JPMPB,Corda_FA,Corda_PB,Corda_IM
001,GSC,Corda_FA,Corda_PB,Corda_IM
001,CUST1,Corda_FA,Corda_CU,Corda_IM
001,CUST2,Corda_FA,Corda_PB,Corda_IM
001,PB,Corda_FA,Corda_PB,Corda_I
```

## Environment Variables
- AZURE_TABLE_CONNECTION_STRING: Connection string to the azure table for fund lookup
- DLT_SVC: DLT service endpoint url

# API Reference

## GET /api/v1/me

Returns the cell's identity.

### Example Response

GET http://localhost:1112/api/v1/me

status: 200

content-type: text/plain

body:
```
LongtailBank
```

## GET /api/v1/fund

Returns details about the fund account.

## Request parameters
- accountNumber
- fundCode

### Example Requests & Responses

#### With parameters returns single response

GET http://localhost:1112/api/v1/fund?accountNumber=P39009&fundCode=FUNDABC

status: 200

content-type: application/json

body:
```json
[
    {
        "Administrator": "FA_B",
        "Broker": "Broker_A",
        "Manager": "Manager_C",
        "AccountNumber": "GSC"
    }
]
```
#### Without parameters returns all funds associated with that cell

GET http://localhost:1112/api/v1/fund
status: 200

content-type: application/json

body:
```json
[
    {
        "Administrator": "FA_B",
        "Broker": "Broker_A",
        "Manager": "Manager_C",
        "AccountNumber": "GSC"
    },
     {
        "Administrator": "FA_B",
        "Broker": "Broker_B",
        "Manager": "Manager_D",
        "AccountNumber": "JPM"
    }
]
```
