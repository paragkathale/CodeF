import { HttpUtils, jsonStringify, logger } from '@drumg/long-island-tea';
import { Router } from 'express';

const CLASS = '[MeController]- ';
const router: Router = Router();

router.get('/', async (_req: any, res: any) => {
    logger.info(`${CLASS} Get called for Me controller. Attempting to access DTL "me" endpoint`);
    try {
        const host: string = process.env.DLT_SVC as string;
        const http = new HttpUtils(host);
        const me = await http.get(`me`, 'Requesting Cell Identity');
        const meJson = JSON.parse(me);

        res.send(meJson.me);
        logger.info(`${CLASS} ${jsonStringify(me)} return successfully`);
    } catch (err) {
        logger.error(`${CLASS} ${err}`);
        res.status(500).send(err.message);
    }
});

export const MeController: Router = router;
