import { Router } from 'express';

const router: Router = Router();

router.get('/', async (_req: any, res: any) => {
    res.status(200).send(JSON.stringify({ status: 'ok', msg: 'I am alive'}));
});

export const HealthcheckeController: Router = router;
