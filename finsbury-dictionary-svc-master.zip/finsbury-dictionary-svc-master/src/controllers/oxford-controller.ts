import { logger } from '@drumg/long-island-tea';
import { Router } from 'express';
import QueryService from '../service/query-service';

const CLASS = '[OxfordController]- ';
const router: Router = Router();

router.get('/', async (req: any, res: any) => {
    const accountNumber = req.query.accountNumber;
    const fundCode = req.query.fundCode;
    const searchValue = accountNumber || fundCode;
    const searchTerm = accountNumber ? 'AccountNumber' : 'Fundcode';

    logger.info(`${CLASS} GET initialized with parameters accountNumber: ${accountNumber} ` +
                `fundCode: ${fundCode} searchValue: ${searchValue} searchTerm: ${searchTerm}`);
    try {
      const AccountMap = await QueryService.discoverParticipants(searchTerm, searchValue);
      logger.info(`${CLASS} accountNumber for ${accountNumber}: ${JSON.stringify(AccountMap[0])}`);

      res.status(200).json(AccountMap);
    } catch (err) {
      logger.error(`${CLASS} ${err}`);
      res.status(500).send(err.message);
    }
});

export const OxfordController: Router = router;
