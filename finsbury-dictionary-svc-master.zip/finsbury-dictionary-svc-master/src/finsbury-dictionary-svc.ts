import { logger } from '@drumg/long-island-tea';
import program = require('commander');
import * as dotenv from 'dotenv';
import path = require('path');
import { Server } from './server';

const serviceName = path.basename(__filename).split('.').slice(0, -1).join();
process.title = serviceName;

process.on('SIGTERM', () => {
    logger.info(`${serviceName} gracefully shut down`);
    if (Server.instance) { Server.instance.close(); }
    process.exit();
});

const CLASS = `[${serviceName}]-`;

program
    .option('-e, --env-file [path]', 'Environment file to use')
    .parse(process.argv);

dotenv.load({path: program.envFile || '.env'});
logger.debug(CLASS + ' .env loaded successfully');

const port: number = parseInt(process.env.PORT || '1112');

logger.debug(`${CLASS} port: ${port}`);

Server.start(port);
