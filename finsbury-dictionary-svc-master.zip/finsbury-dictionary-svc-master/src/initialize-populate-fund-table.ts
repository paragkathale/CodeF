import { populateFundTable } from './service/populate-fund-table';

populateFundTable();
