import { AzureTableUtils } from '@drumg/cloud-services';

export class AzureParticipationTable {
    public static getInstance(): AzureTableUtils {
        if (!this._instance) {
            this._instance = new AzureTableUtils(this.TABLE_NAME, process.env.AZURE_TABLE_CONNECTION_STRING);
        }
        return this._instance;
    }

    private static _instance: AzureTableUtils;
    private static TABLE_NAME: string = 'ParticipationMap';
}
