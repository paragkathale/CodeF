import { AzureTableUtils } from '@drumg/cloud-services';
import { jsonStringify, logger } from '@drumg/long-island-tea';
import csvToJson = require('csvtojson');
import dotenv = require('dotenv');
import uuid = require('uuid/v4');

const KLASS = '[Populate-Fund-Table]';
const tableName = 'ParticipationMap';
const rootDir = __dirname + '/../../';
const fileLocation = `${rootDir}/config/participation-map.csv`;

dotenv.load({path: `.env`});

export const populateFundTable = async () => {
    logger.info(`${KLASS} initializing population for ${tableName} Table`);
    try {
        const azureTable: AzureTableUtils = new AzureTableUtils(tableName, process.env.AZURE_TABLE_CONNECTION_STRING);
        await azureTable.ensureTable();
        await azureTable.clear();
        const csvJson = await csvToJson().fromFile(fileLocation);

        logger.info(`${KLASS} data: ${jsonStringify(csvJson)} table: ${tableName}`);
        csvJson.forEach( async (data: any) => await insertToTable(azureTable, data));
    } catch (err) {
        logger.error(`${KLASS} ${err}`);
        throw err;
    }
};

async function insertToTable(azureTable: AzureTableUtils,  data: TableRow) {
    try {
        data.RowKey = uuid();
        logger.info(`${KLASS} attempting to add row with data ${jsonStringify(data)}`);
        await azureTable.addRow(data);
        logger.info(`${KLASS} added to table successfully with AccountNumber ${data.AccountNumber}`);
    } catch (err) {
        logger.error(`${KLASS} ${err}`);
        throw err;
    }
}

interface TableRow {
    RowKey: string;
    AccountNumber: string;
}
