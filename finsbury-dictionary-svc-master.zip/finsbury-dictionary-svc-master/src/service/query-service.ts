
import { AzureStringUtils } from '@drumg/cloud-services';
import { logger } from '@drumg/long-island-tea';
import * as azure from 'azure-storage';
import { AzureParticipationTable } from '../azure-table';

const CLASS = '[QueryService]-';

export default class QueryService {

    public static async discoverParticipants(searchTerm?: string, searchValue?: string) {

        const query = new azure.TableQuery().select('Manager, Administrator, Broker, AccountNumber');
        if (searchTerm && searchValue) {
            query.where(`${searchTerm} == ?string?`, searchValue);
        }
        const result = await AzureParticipationTable.getInstance().queryAll(query);
        const prettyResult = AzureStringUtils.prettifyAzureQuery(result);

        logger.info(`${CLASS} prettyResult: ${JSON.stringify(prettyResult)}`);

        return prettyResult;
    }
}
