import { logger } from '@drumg/long-island-tea';
import bodyParser = require('body-parser');
import cors = require('cors');
import express = require('express');
import http = require('http');
import { HealthcheckeController, MeController, OxfordController } from './controllers';

const CLASS = '[Server]-';

const app = express();
logger.debug(`${CLASS} initializing server...`);

app.use(cors());
app.use(bodyParser.json());

app.use((err: any, _req: any, res: any, next: any) => {
    logger.error(err.message);
    res.status(500).send(err.message);
    next();
});

app.use('/api/v1/fund', OxfordController);
app.use('/api/v1/me', MeController);
app.use('/healthcheck', HealthcheckeController);

export class Server {
    public static instance: http.Server;

    public static start(port: number): void {
        this.instance = app.listen(port, () => {
            logger.info('http server listening on ' + port);
        });
    }
}
