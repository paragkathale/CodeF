#!/bin/bash

ME=$(basename $0)
SVC=${1:-}

[ q$SVC = q ] && echo "usage: $ME svcname" && exit 1

OS=$(uname)
case $OS in
    Linux) # use -x for exact match and allow for trailing space only
    CMD="pkill -xf ^${SVC}\s*$"
    ;;
    Darwin) # Mac - don't use exact match and allow for additional trailing args
    CMD="pkill -f ^${SVC}\s*"
    ;;
    *)
    echo "$ME: [ERROR] unsupported OS $OS"
    exit 1
    ;;
esac

set -x
exec $CMD
