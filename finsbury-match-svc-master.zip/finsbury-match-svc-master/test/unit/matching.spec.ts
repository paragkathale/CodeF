import { expect } from 'chai';
import uuid = require('uuid/v4');
import { MatchingFlow } from '../../src/matching-flow';
import { TradeMatching } from '../../src/trade-matching';
import { ITradesPublisher } from '../../src/trades-publisher';
import { ITradesQuery } from '../../src/trades-query';

enum TradeType {
    New,
    Cancel
}

enum RoleType {
    InvestmentManager,
    Custodian,
    PrimeBroker
}

const CORDA_IM  = 'Corda_IM';
const CORDA_CU  = 'Corda_CU';
const CORDA_CU2 = 'Corda_CU2';
// const CORDA_PB  = 'Corda_PB';

function makeTradeRecord(manager: string, fundCode: string, transId: string = '123',
                         tradeType: TradeType = TradeType.New, role: RoleType = RoleType.Custodian,
                         provider = CORDA_IM, broker = CORDA_IM) {
    const status = tradeType === TradeType.New ? 'NEW' : 'CANCEL';

    return {
        transactionId: transId,
        role: RoleType[role].toString(),
        status,
        broker,
        provider,
        dgId: uuid(),
        fund: {
            manager: `${manager}`,
            identifiers: {
                accountNumber: 'JPM',
                adminAccount: 'FA'
            }
        },
        tradeDetails: {
            transaction: {
                type: status,
                identifiers: {
                    fundCode: `${fundCode}`,
                    lotID: '491315808'
                }
            },
            investment: {
                type: 'Equity',
                identifiers: {
                    CUSIP: 'PACB',
                    ISIN: 'US10922N1037',
                    SEDOL: 'BF429K9',
                    SecurityName: 'My own stock'
                }
            },
            details: {
                type: 'BUYL',
                tradeDate: '2018-11-16 12:00 AM',
                settleDate: '2018-11-20 12:00 AM',
                tradeCurrency: 'USD',
                settleCurrency: 'USD',
                quantity: '37700',
                price: '8.88',
                commissions: '377',
                fees: {
                    SEC: '0',
                    other: '0'
                },
                netTradeAmount: '285389',
                grossTradeAmount: '0',
                clearingBroker: {
                    code: 'JPMC'
                },
                executingBroker: {
                    code: 'DB'
                },
            },
            status: {
                lastUpdate: '2018-11-19 16:38:09.427',
                shortCode: 'ACCT'
            }
        }
    };
}

describe('Trade matching', () => {
    it('should match trades', async () => {
        const TRADE_A = makeTradeRecord('BankA', 'Code123', '1');
        const TRADE_B = makeTradeRecord('BankA', 'Code123', '1');
        const TRADE_C = makeTradeRecord('BankA', 'Code123', '1');

        const numMatches = TradeMatching.run([TRADE_A], [TRADE_B, TRADE_C]);
        expect(numMatches).to.equal(2);
    });

    it('should match multiple trades', async () => {
        const TRADE_A = makeTradeRecord('BankA', 'Code123', '1');
        const TRADE_B = makeTradeRecord('BankB', 'Code456', '2');
        const TRADE_C = makeTradeRecord('BankC', 'Code789', '3');

        const TRADE_D = makeTradeRecord('BankC', 'Code789', '3');
        const TRADE_E = makeTradeRecord('BankB', 'Code456', '2');
        const TRADE_F = makeTradeRecord('BankA', 'Code123', '1');

        const numMatches = TradeMatching.run([TRADE_A, TRADE_B, TRADE_C], [TRADE_D, TRADE_E, TRADE_F]);
        expect(numMatches).to.equal(3);
    });

    it('should break trades', async () => {
        const TRADE_A = makeTradeRecord('BankA', 'Code123', '1');
        const TRADE_B = makeTradeRecord('BankB', 'Code123', '2');
        const TRADE_C = makeTradeRecord('BankA', 'Code555', '3');

        const numMatches = TradeMatching.run([TRADE_A], [TRADE_B, TRADE_C]);
        expect(numMatches).to.equal(0);
    });

    it('should support tx-update message v1.1.0', async () => {
        const TRADE_A = makeTradeRecord('BankA', 'Code123', '1');
        const TRADE_B = makeTradeRecord('BankB', 'Code123', '2');

        let numMatches = TradeMatching.runOnSingle(TRADE_A, [TRADE_A]);
        expect(numMatches).to.equal(1);
        numMatches = TradeMatching.runOnSingle(TRADE_B, [TRADE_A]);
        expect(numMatches).to.equal(0);
    });

    it('should skip matching for cancelled trades', async () => {
        const TRADE_A = makeTradeRecord('BankA', 'Code123', '1', TradeType.New);
        const dltQuery = new TradesQueryMock([TRADE_A]);

        let matching = new MatchingFlow(dltQuery);
        let numMatches = await matching.findMatchFor(TRADE_A);
        expect(numMatches).to.equal(1, 'Test new IM and CU trades can be matched');

        const TRADE_B = makeTradeRecord('BankA', 'Code123', '2', TradeType.Cancel);
        matching = new MatchingFlow(dltQuery);
        numMatches = await matching.findMatchFor(TRADE_B);
        expect(numMatches).to.equal(0, 'Test cancel CU trade does not match');

        matching = new MatchingFlow(new TradesQueryMock([TRADE_B]));
        numMatches = await matching.findMatchFor(TRADE_A);
        expect(numMatches).to.equal(0, 'Test cancel IM trade does not match');
    });

    class TradesQueryMock implements ITradesQuery {
        private readonly response: object[];

        constructor(response: object[]) {
            this.response = response;
        }

        public get(): any {
            return this.response;
        }
    }

    it('should skip matching for IM wake-up trades', async () => {
        const TRADE_A = makeTradeRecord('M', 'F', '1', TradeType.New, RoleType.InvestmentManager);
        const dltQuery = new TradesQueryMock([TRADE_A]);
        const matching = new MatchingFlow(dltQuery);
        const numMatches = await matching.findMatchFor(TRADE_A);

        expect(numMatches).to.equal(0, 'IM trades should not trigger matching');
    });

    it('should skip matching on PB trades', async () => {
        const TRADE_IM = makeTradeRecord('M', 'F', '1', TradeType.New, RoleType.InvestmentManager);
        const TRADE_PB = makeTradeRecord('M', 'F', '1', TradeType.New, RoleType.PrimeBroker);

        const dltQuery = new TradesQueryMock([TRADE_IM]);
        const dltPublisher = new TradesPublisherMock(1);
        const matching = new MatchingFlow(dltQuery, dltPublisher);
        const numMatches = await matching.findMatchFor(TRADE_PB);

        expect(numMatches).to.equal(0, 'PB trades should not trigger matching');
    });

    class TradesPublisherMock implements ITradesPublisher {
        private readonly expectedPairsCount: number;
        private readonly onPairingCompleteCb?: any;

        constructor(expectedPairsCount: number, onPairingComplete?: any) {
            this.expectedPairsCount = expectedPairsCount;
            this.onPairingCompleteCb = onPairingComplete;
        }

        public async pair(tradePairs: object[]) {
            expect(tradePairs.length).equal(this.expectedPairsCount);

            if (this.onPairingCompleteCb) {
                this.onPairingCompleteCb(tradePairs);
            }
        }
    }

    it('should publish trade pairs', async () => {
        const TRADE_CU = makeTradeRecord('M', 'F', '1', TradeType.New, RoleType.Custodian);
        const TRADE_IM = makeTradeRecord('M', 'F', '1', TradeType.New, RoleType.InvestmentManager);
        const dltQuery = new TradesQueryMock([TRADE_IM]);
        const dltPublisher = new TradesPublisherMock(1);
        const matching = new MatchingFlow(dltQuery, dltPublisher);
        const numMatches = await matching.findMatchFor(TRADE_CU);
        expect(numMatches).to.equal(1, 'Trades are queried, paired and published');
    });

    it('should match in complex scenarios', async () => {
        const CU_TRADE_1 = makeTradeRecord('M', 'A', '4019', TradeType.New, RoleType.Custodian);
        const CU_TRADE_2 = makeTradeRecord('M', 'B', '4020', TradeType.New, RoleType.Custodian);
        const CU_TRADE_3 = makeTradeRecord('M', 'C', '4022', TradeType.New, RoleType.Custodian);

        const IM_TRADE_1 = makeTradeRecord('M', 'B', '4020', TradeType.New, RoleType.InvestmentManager);
        const IM_TRADE_2 = makeTradeRecord('M', 'N/A', '4021', TradeType.New, RoleType.InvestmentManager);
        const IM_TRADE_3 = makeTradeRecord('M', 'A', '4019', TradeType.Cancel, RoleType.InvestmentManager);

        const dltQuery = new TradesQueryMock([IM_TRADE_1, IM_TRADE_2, IM_TRADE_3]);
        const matching = new MatchingFlow(dltQuery);

        let numMatches = await matching.findMatchFor(CU_TRADE_1);
        expect(numMatches).to.equal(0);

        numMatches = await matching.findMatchFor(CU_TRADE_2);
        expect(numMatches).to.equal(1);

        numMatches = await matching.findMatchFor(CU_TRADE_3);
        expect(numMatches).to.equal(0);
    });

    it('should add providers when pairing', async () => {
        const providerCU = 'CU';
        const providerIM = 'IM';
        const IM_TRADE_1 = makeTradeRecord('M', 'A', '4019', TradeType.New, RoleType.InvestmentManager,
            providerIM, providerCU);
        const CU_TRADE_1 = makeTradeRecord('M', 'A', '4019', TradeType.New, RoleType.Custodian,
            providerCU, providerCU);

        const dltQuery = new TradesQueryMock([IM_TRADE_1]);

        const dltPublisher = new TradesPublisherMock(1, (pairs: any[]) => {
            const pair = pairs[0].pair;
            expect(pair.first.provider).to.equal(providerIM);
            expect(pair.second.provider).to.equal(providerCU);
        });
        const matching = new MatchingFlow(dltQuery, dltPublisher);

        const numMatches = await matching.findMatchFor(CU_TRADE_1);
        expect(numMatches).to.equal(1);
    });

    it('should add transaction ID when pairing', async () => {
        const id = 'id';
        const fundManager = 'FM';
        const fundCode = 'FC';
        const expectedPairsCount = 1;
        const imTrade = makeTradeRecord(fundManager, fundCode, id, TradeType.New, RoleType.InvestmentManager,
            CORDA_IM, CORDA_CU);
        const cuTrade = makeTradeRecord(fundManager, fundCode, id, TradeType.New, RoleType.Custodian, CORDA_CU,
            CORDA_CU);

        const queryMock = new TradesQueryMock([imTrade]);
        const publisherMock = new TradesPublisherMock(expectedPairsCount, (pairs: any[]) => {
            expect(pairs[0].transactionId).to.equal(id);
        });
        const matching = new MatchingFlow(queryMock, publisherMock);

        const numMatches = await matching.findMatchFor(cuTrade);
        expect(numMatches).to.equal(expectedPairsCount);
    });

    it('should pair trades from multiple custodians', async () => {
        const fundManager = 'FM';
        const fundCode = 'FC';
        const transId = '1';
        const expectedPairsCount = 1;

        const imTrade1 = makeTradeRecord(fundManager, fundCode, transId, TradeType.New, RoleType.InvestmentManager,
            CORDA_IM, CORDA_CU);
        const cuTrade1 = makeTradeRecord(fundManager, fundCode, transId, TradeType.New, RoleType.Custodian,
            CORDA_CU, CORDA_CU);
        const imTrade2 = makeTradeRecord(fundManager, fundCode, transId, TradeType.New, RoleType.InvestmentManager,
            CORDA_IM, CORDA_CU2);
        const cuTrade2 = makeTradeRecord(fundManager, fundCode, transId, TradeType.New, RoleType.Custodian,
            CORDA_CU2, CORDA_CU2);

        // Match up with trade from Corda_CU
        let queryMock = new TradesQueryMock([imTrade2, imTrade1]);
        let publisherMock = new TradesPublisherMock(expectedPairsCount, (pairs: any[]) => {
            expect(pairs[0].transactionId).to.equal(transId);
            expect(pairs[0].broker).to.equal(CORDA_CU);
        });
        let matching = new MatchingFlow(queryMock, publisherMock);
        let numMatches = await matching.findMatchFor(cuTrade1);
        expect(numMatches).to.equal(expectedPairsCount);

        // Match up with trade from Corda_CU2
        queryMock = new TradesQueryMock([imTrade1, imTrade2]);
        publisherMock = new TradesPublisherMock(expectedPairsCount, (pairs: any[]) => {
            expect(pairs[0].transactionId).to.equal(transId);
            expect(pairs[0].broker).to.equal(CORDA_CU2);
        });
        matching = new MatchingFlow(queryMock, publisherMock);
        numMatches = await matching.findMatchFor(cuTrade2);
        expect(numMatches).to.equal(expectedPairsCount);
    });
});
