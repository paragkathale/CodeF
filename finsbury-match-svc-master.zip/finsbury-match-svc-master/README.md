<p align="center">
  <img src="https://user-images.githubusercontent.com/8850110/55236247-72848380-5227-11e9-9f56-724960bb6fd7.png" alt="DrumG" width="400" />
</p>

# Finsbury Matching Service

This repo contains the source for Finsbury matching service.
This page contains instructions to set up local development environment.

Table of Contents
=================

  * [Overview](#overview)
  * [Pre-Requisites](#pre-requisites)
  * [Development Usage](#development-usage)
  
## Overview
Match-svc ONLY runs in investment manager's cell/node (IM). It operates under the assumption that there is only single instance running within a network at the same time.

It's worth to mention that match-svc does not list any RESTful API endpoints itself.


## Pre-Requisites
This service depends on the following resources 
* Azure ServiceBus. Specifically, it relies on in-app zone service bus. 

* DLT service endpoints. Refer to the github [repo](https://github.com/DrumG/finsbury-dlt-svc/blob/master/README.md).
The DLT service endpoints are called at: http://localhost:10050/<endpoint-path>


# Development Usage

## Running the service

### Via the command line

Build the service:

    npm run build

Run the service:

    npm run start

#### Example a message body
```json
{
    "tradeRecords": [
        {
            "fund": {
                "accountNumber": "P 39009",
                "manager": "Corda_IM",
                "administrator": "Corda_FA"
            },
            "provider": "Corda_IM",
            "role": "InvestmentManager",
            "investmentId": "US0236081024",
            "transactionId": "2145936887",
            "tradeDetails": "{\"type\":\"BUY\",\"tradeDate\":\"20181106\",\"settleDate\":\"20181108\",\"tradeCurrency\":\"USD\",\"settleCurrency\":\"USD\",\"fxRate\":\"1.0\",\"quantity\":\"27544\",\"price\":\"64.86340964\",\"commissions\":\"35.8072\",\"fees\":[{\"type\":\"SEC\",\"value\":\"0.0\"},{\"type\":\"other\",\"value\":\"0.0\"}],\"netTradeAmount\":\"1786633.56\",\"grossTradeAmount\":\"1786597.76\",\"clearingBroker\":{\"identifiers\":[{\"type\":\"code\",\"value\":\"GS\"},{\"type\":\"custom\",\"name\":\"ExecutingBrokerLongName\",\"value\":\"Goldman Sachs\"}]},\"executingBroker\":{\"identifiers\":[{\"type\":\"code\",\"value\":\"JPM\"}]}}",
            "source": "{\"provider\":\"Corda_IM\",\"received\":\"2018-12-31T17:35:00Z\",\"transport\":\"SFTP\",\"protocol\":\"CSV\",\"storage\":{\"provider\":\"Azure\",\"url\":\"https://aqr.drumg.blob.core.windows.net/finsbury/20181231-DEFGLUX-JPM.csv\",\"hash\":\"0x268936593782349AB3\"}}",
            "broker": "Corda_CU",
            "status": "CANCELLED",
            "dgId": "853e99dd-c380-4e91-8ccd-680bb64ed0db"
        }
    ]
}
```
