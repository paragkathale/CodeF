import {Message} from '@drumg/cloud-services';
import { logger } from '@drumg/long-island-tea';
import program = require('commander');
import * as dotenv from 'dotenv';
import http = require('http');
import path = require('path');
import process = require('process');
import app from './app';
import { MatchingFlow } from './matching-flow';
import { MessageQueueAutomation } from './message-queue-automation';
import { TradesPublisher } from './trades-publisher';
import { TradesQuery } from './trades-query';

const defaultPort = 18891;
const serviceName = path.basename(__filename).split('.').slice(0, -1).join();
let server: http.Server;

export { defaultPort, server, serviceName };

process.on('SIGTERM', async () => {
    logger.info(`${serviceName} gracefully shut down`);
    if (server) {
        await busAutomation.stopConsumer();
        server.close();
    }
    process.exit();
});

let busAutomation: MessageQueueAutomation;
let matchingFlow: MatchingFlow;

const handleMessage = async (json: any, version: string) => {
    logger.info(`Matching engine received ${JSON.stringify(json)}`);

    let countMatches = 0;

    if (version === '1.1.0') {
        countMatches = await matchingFlow.findMatchFor(json);
    } else {
        throw new Error(`Unsupported message version ${version}`);
    }

    logger.info(`Total ${countMatches} matched`);
};

const onMessage = async (message: Message<any>) => {
    try {
        const json = JSON.parse(message.body);
        await handleMessage(json, message.header.version);
    } catch (e) {
        logger.info(e.toString());
    }
};

const subscribeToTopic = async () => {
    await busAutomation.startConsumer(onMessage);
};

async function main() {
    program
        .option('-e, --env-file [path]', 'Environment file to use')
        .parse(process.argv);

    process.title = serviceName;

    const envFile = program.envFile || '.env';
    dotenv.load({path: envFile});
    logger.level = process.env.LOG_LEVEL || logger.level;

    logger.info(`${serviceName} loaded env file ${envFile} successfully`);

    const svcPort: number = parseInt(process.env.PORT || defaultPort.toString());

    const dltsvcUrl = process.env.DLT_SVC!;
    matchingFlow = new MatchingFlow(new TradesQuery(dltsvcUrl), new TradesPublisher(dltsvcUrl));

    // TODO: fix the subscription name to 'finsbury-match-svc'
    const topic = process.env.TX_UPDATE_TOPIC || 'tx-update';
    const subscription = process.env.TX_UPDATE_SUBSCRIPTION || serviceName;
    busAutomation = new MessageQueueAutomation(topic, subscription);
    await subscribeToTopic();

    server = app.listen(svcPort, () => logger.info(`${serviceName} listening on port ${svcPort}`));
}

main().then();
