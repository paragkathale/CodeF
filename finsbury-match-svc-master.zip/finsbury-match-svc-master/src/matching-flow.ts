import { logger } from '@drumg/long-island-tea';
import { TradeMatching } from './trade-matching';
import { ITradesPublisher } from './trades-publisher';
import { ITradesQuery } from './trades-query';

export class MatchingFlow {
    private readonly query: ITradesQuery;
    private readonly publisher?: ITradesPublisher;
    private pairs: object[] = [];

    constructor(tradesQuery: ITradesQuery, tradesPublisher?: ITradesPublisher) {
        this.query = tradesQuery;
        this.publisher = tradesPublisher;
    }

    public async findMatchFor(trade: any) {
        if (trade.role === 'PrimeBroker') {
            logger.info(`Matching for ${trade.provider} trade is not supported`);
            return 0;
        }

        const transId = trade.transactionId;
        if (!TradeMatching.isAcceptableTrade(trade) || trade.role !== 'Custodian') {
            logger.info(`${trade.provider}'s trade ${transId} is not acceptable`);
            return 0;
        }
        const imTrades = await this.query.get({
            role: 'InvestmentManager',
            provider: trade.fund.manager,
            transactionId: transId
        });
        logger.info(`Query returned ${imTrades.length} IM trades`);

        this.pairs = [];
        const countMatches = TradeMatching.run(imTrades, [trade], this.onMatch.bind(this));

        if (this.publisher && this.pairs.length) {
            await this.publisher.pair(this.pairs);
        }
        return countMatches;
    }

    private onMatch(tradeIM: any, tradeCU: any) {
        const message = `IM orderID ${tradeIM.transactionId} is matched with CU orderID ${tradeCU.transactionId}`;
        logger.info(message);

        const match: any = {
            pair: {
                first: {
                    dgId: tradeIM.dgId,
                    details: tradeIM.tradeDetails,
                    provider: tradeIM.provider
                },
                second: {
                    dgId: tradeCU.dgId,
                    details: tradeCU.tradeDetails,
                    provider: tradeCU.provider
                }
            },
            broker: tradeIM.broker,
            status: 'PAIRED',
            transactionId: tradeIM.transactionId
        };

        match.fund = tradeIM.fund;

        this.pairs.push(match);
    }
}
