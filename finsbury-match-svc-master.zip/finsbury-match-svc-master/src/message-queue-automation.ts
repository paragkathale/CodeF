import { BaseMessage, Consumer, Message, MessageQueueFactory, Publisher } from '@drumg/cloud-services';
import { logger } from '@drumg/long-island-tea';

class CustomMessage extends BaseMessage {
    public static create(body: string) {
        return new CustomMessage(body);
    }
    private constructor(body: string) {
        super('1.0.0', body);
    }
}

export class MessageQueueAutomation {
    private readonly topic: string;
    private readonly subscription: string;
    private readonly messageQueueFactory: MessageQueueFactory;
    private consumer?: Consumer;
    private publisher?: Publisher;

    constructor(topic: string, subscription: string) {
        this.messageQueueFactory = new MessageQueueFactory();
        this.topic = topic;
        this.subscription = subscription;
    }

    public async startConsumer(callback: (message: Message) => Promise<void>) {
        logger.info(`Starting to consume messages from topic=${this.topic} via subscription=${this.subscription}`);
        this.consumer = await this.messageQueueFactory.createConsumer(this.topic, this.subscription, callback);
    }

    public async stopConsumer() {
        if (this.consumer) {
            await this.consumer.close();
            this.consumer = undefined;
        }
    }

    public async startPublisher() {
        logger.info(`Starting the publisher for ${this.topic}`);
        this.publisher = await this.messageQueueFactory.createPublisher(this.topic);
    }

    public async stopPublisher() {
        if (this.publisher) {
            logger.info(`Stop the publisher`);
            await this.publisher.close();
            this.publisher = undefined;
        }
    }

    public async sendMessage(message: string) {
        if (this.publisher) {
            logger.info(`Posting a service bus message ${message}`);
            this.publisher.send(CustomMessage.create(message));
        }
    }
}
