import { logger, request } from '@drumg/long-island-tea';

export interface ITradesPublisher {
    pair(tradePairs: object[]): Promise<void>;
}

export class TradesPublisher implements ITradesPublisher {
    private readonly dltSvcUrl: string;

    constructor(dltSvcUrl: string) {
        this.dltSvcUrl = dltSvcUrl;
    }

    public async pair(tradePairs: object[]) {
        const pairs = {
            tradePairs
        };

        try {
            await request.post(`${this.dltSvcUrl}/tradePairs`, { body: pairs }, 'Posting trade pairs');
        } catch (err) {
            logger.error(`Error posting trade pair, reason: ${err.message}`);
        }
    }
}
