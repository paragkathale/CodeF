import { logger, request } from '@drumg/long-island-tea';

export interface ITradesQuery {
    get(qs: { role: string, provider?: string, transactionId?: string }): Promise<object[]>;
}

export class TradesQuery implements ITradesQuery {
    private readonly dltSvcUrl: string;

    constructor(dltSvcUrl: string) {
        this.dltSvcUrl = dltSvcUrl;
    }

    public async get(qs: { role: string, provider?: string, transactionId?: string }): Promise<object[]> {
        try {
            const records = await request.get(
                `${this.dltSvcUrl}/tradeRecords`,
                { qs },
                `Retrieving trades with role ${qs.role}`
            );

            return records.tradeRecords;
        } catch (err) {
            logger.error(`Error fetching trades, reason: ${err.message}`);
            throw err;
        }
    }
}
