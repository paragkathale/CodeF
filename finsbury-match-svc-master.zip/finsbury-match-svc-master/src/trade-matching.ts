import { jsonStringify, logger } from '@drumg/long-island-tea';

export class TradeMatching {
    public static run(unmatchedIM: object[], unmatchedCU: object[], callback: any = null): number {
        let countMatches = 0;
        let tradeIM: any;
        let tradeCU: any;

        if (unmatchedCU.length === 0 || unmatchedIM.length === 0) {
            logger.info(`No matching was performed. unmatchedCUs: ${unmatchedCU.length}, ` +
                    `unmatchedIMs: ${unmatchedIM.length}`);
            return countMatches;
        }

        for (tradeCU of unmatchedCU) {
            let isMatched = false;
            for (tradeIM of unmatchedIM) {
                try {
                    if (!TradeMatching.isAcceptableTrade(tradeIM)) {
                        logger.info(`IM order ID ${tradeIM.transactionId} is not acceptable`);
                        continue;
                    }

                    isMatched = TradeMatching.areMatched(tradeIM, tradeCU);
                    if (isMatched) {
                        countMatches++;
                        if (callback) {
                            callback(tradeIM, tradeCU);
                        }
                        break;
                    }
                } catch (err) {
                    logger.error(`Error performing match one trade ${err}, trade: ${jsonStringify(unmatchedIM)}`);
                }
            }
        }

        return countMatches;
    }

    public static runOnSingle(tradeIM: object, tradeCU: object[]): number {
        return TradeMatching.run([tradeIM], tradeCU);
    }

    public static isAcceptableTrade(trade: any) {
        return trade.status === 'NEW';
    }

    private static extractDetails(tradeDetails: any) {
        return typeof tradeDetails === 'string' ? JSON.parse(tradeDetails) : tradeDetails;
    }

    private static areMatched(tradeIM: any, tradeCU: any): boolean {
        const detailsIM = TradeMatching.extractDetails(tradeIM.tradeDetails);
        const detailsCU = TradeMatching.extractDetails(tradeCU.tradeDetails);
        const fundCodeIM = detailsIM.transaction.identifiers.fundCode;
        const fundCodeCU = detailsCU.transaction.identifiers.fundCode;
        const fundManagerIM = tradeIM.fund.manager;
        const fundManagerCU = tradeCU.fund.manager;
        const idIM = tradeIM.transactionId;
        const idCU = tradeCU.transactionId;

        logger.info(`Comparing IM trade: ${idIM}, ${fundCodeIM}, ${fundManagerIM}, broker: ${tradeIM.broker} with ` +
                              `CU trade: ${idCU}, ${fundCodeCU}, ${fundManagerCU}, provider: ${tradeCU.provider}`);

        return idIM === idCU && fundCodeIM && fundCodeCU &&
               tradeIM.broker === tradeCU.provider &&
               fundCodeIM === fundCodeCU && fundManagerIM === fundManagerCU;
    }
}
