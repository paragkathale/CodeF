import { logger } from '@drumg/long-island-tea';
import { Request, Response, Router } from 'express';
import { TradeEventService } from '../services/trade-event-service';
import { config } from '../config';

const router: Router = Router();
const tradeEventService: TradeEventService = new TradeEventService(config.dltServiceBaseUrl);

router.get('/', async (req: Request, res: Response) => {
    const { transactionId } = req.query;
    try {
        const tradeEvents = await tradeEventService.getTradeEvents(transactionId);
        res.send(tradeEvents);
    } catch (err) {
        logger.error(`tradeEvent request failed with error ${err.message}`, err);
        res.send({ error: err.message }).status(500);
    }
});

export const TradeEventController: Router = router;
