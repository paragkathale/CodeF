import get from 'get-value';
import { TradeEvent } from './types/trade-event';
import { TradeRecord } from './types/trade-record';
import { TradeDataType } from './types/trade-data-type';

export function mapTradeRecordToTradeEvent(tradeRecord: TradeRecord): TradeEvent {
    const details = JSON.parse(tradeRecord.tradeDetails);
    return {
        state: tradeRecord.status,
        custodianStatus: get(details, 'status.latest.custodianStatus.value'),
        custodianNarrative: get(details, 'status.latest.custodianNarrative.value'),
        eventTime: get(details, 'status.lastUpdate'),
        updatedAt: tradeRecord.dgCreatedTimestamp,
        source: tradeRecord.provider,
        transType: get(details, 'transaction.type'),
        stateRef: tradeRecord.stateRef,
        dgId: tradeRecord.dgId,
        dataType: TradeDataType.TRADE_RECORD,
        data: tradeRecord
    };
}
