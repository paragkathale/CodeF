import get from 'get-value';
import { isAfter } from 'date-fns';
import { TradeEvent } from './types/trade-event';
import { TradePair } from './types/trade-pair';
import { TradeDataType } from './types/trade-data-type';

export function mapTradePairToTradeEvent(tradePair: TradePair): TradeEvent {
    const pair = {
        first: {
            details: JSON.parse(tradePair.pair.first.details),
            provider: tradePair.pair.first.provider
        },
        second: {
            details: JSON.parse(tradePair.pair.second.details),
            provider: tradePair.pair.second.provider
        }
    };

    const newer = isAfter(get(pair.first.details, 'status.lastUpdate'), get(pair.second.details, 'status.lastUpdate')) ?
            pair.first : pair.second;

    return {
        state: tradePair.status,
        custodianStatus: get(newer, 'details.status.latest.custodianStatus.value'),
        custodianNarrative: get(newer, 'details.status.latest.custodianNarrative.value'),
        eventTime: get(newer, 'details.status.lastUpdate'),
        updatedAt: tradePair.dgCreatedTimestamp,
        source: newer.provider,
        transType: get(newer, 'details.transaction.type'),
        stateRef: tradePair.stateRef,
        dgId: tradePair.dgId,
        dataType: TradeDataType.TRADE_PAIR,
        data: tradePair
    };
}
