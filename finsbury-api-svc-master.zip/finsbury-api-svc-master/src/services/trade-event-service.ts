import { logger, request } from '@drumg/long-island-tea';
import { compareDesc } from 'date-fns';
import { mapTradeRecordToTradeEvent } from './trade-record-mapper';
import { mapTradePairToTradeEvent } from './trade-pair-mapper';
import { TradeEvent } from './types/trade-event';
import { TradeRecord } from './types/trade-record';
import { TradePair } from './types/trade-pair';

export class TradeEventService {
    private readonly dltServiceBaseUrl: string;

    constructor(dltServiceBaseUrl: string) {
        this.dltServiceBaseUrl = dltServiceBaseUrl;
    }

    public async getTradeEvents(transactionId: string): Promise<TradeEvent[]> {
        const [tradeRecordEvents, tradePairEvents] = await Promise.all([
            this.getTradeEventsFromRecords(transactionId),
            this.getTradeEventsFromPairs(transactionId),
        ]);

        return tradeRecordEvents
                .concat(tradePairEvents)
                .sort((a, b) => compareDesc(a.updatedAt, b.updatedAt));
    }

    private async getTradeEventsFromRecords(transactionId: string): Promise<TradeEvent[]> {
        const tradeRecords = await this.queryHistoricalTradeRecords(transactionId);

        return tradeRecords.map(mapTradeRecordToTradeEvent);
    }

    private async getTradeEventsFromPairs(transactionId: string): Promise<TradeEvent[]> {
        const tradePairs = await this.queryHistoricalTradePairs(transactionId);

        return tradePairs.map(mapTradePairToTradeEvent);
    }

    private async queryHistoricalTradeRecords(transactionId: string): Promise<TradeRecord[]> {
        try {
            const uri = `${this.dltServiceBaseUrl}/tradeRecords`;
            const qs = { transactionId, includeHistory: true };
            const requestOpts = { method: 'GET', qs };
            const comment = 'Query historical trade records by transactionId';

            const { tradeRecords } = await request(uri, requestOpts, comment);
            return tradeRecords;
        } catch (err) {
            logger.error(`trade record query failed with error ${err.message}`);
            throw err;
        }
    }

    private async queryHistoricalTradePairs(transactionId: string): Promise<TradePair[]> {
        try {
            const uri = `${this.dltServiceBaseUrl}/tradePairs`;
            const qs = { transactionId, includeHistory: true };
            const requestOpts = { method: 'GET', qs };
            const comment = 'Query historical trade pairs by transactionId';

            const { tradePairs } = await request(uri, requestOpts, comment);
            return tradePairs;
        } catch (err) {
            logger.error(`trade pair query failed with error ${err.message}`);
            throw err;
        }
    }
}
