export interface Fund {
    accountNumber: string;
    manager: string;
    administrator: string;
}
