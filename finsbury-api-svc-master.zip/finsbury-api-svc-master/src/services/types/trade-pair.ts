import { Fund } from './fund';

export interface TradePair {
    fund: Fund;
    broker: string;
    transactionId: string;
    pair: {
        first: Trade;
        second: Trade;
    };
    status: string;
    stateRef: string;
    dgCreatedTimestamp: string;
    dgConsumedTimestamp: string | null;
    dgId: string;
}

interface Trade {
    details: string;
    provider: string;
    dgId: string;
}
