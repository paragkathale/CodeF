import { Fund } from './fund';

export interface TradeRecord {
    fund: Fund;
    provider: string;
    role: string;
    investmentId: string;
    transactionId: string;
    tradeDetails: string;
    broker: string;
    source: string;
    status: string;
    stateRef: string;
    dgCreatedTimestamp: string;
    dgConsumedTimestamp: string | null;
    dgId: string;
}
