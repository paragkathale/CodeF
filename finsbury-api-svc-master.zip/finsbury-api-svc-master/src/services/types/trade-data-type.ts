export enum TradeDataType {
    TRADE_PAIR = 'tradePair',
    TRADE_RECORD = 'tradeRecord'
}
