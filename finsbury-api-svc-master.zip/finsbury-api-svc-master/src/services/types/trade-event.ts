import { TradeDataType } from './trade-data-type';
import { TradePair } from './trade-pair';
import { TradeRecord } from './trade-record';

export interface TradeEvent {
    state: string;
    custodianStatus: string;
    custodianNarrative: string;
    eventTime: string;
    updatedAt: string;
    source: string;
    transType: string;
    stateRef: string;
    dgId: string;
    dataType: TradeDataType;
    data: TradeRecord | TradePair;
}
