import dotenv = require('dotenv');
import program = require('commander');
import { logger } from '@drumg/long-island-tea';

const defaultPort = 18900;
const envFile = program.envFile || '.env';

dotenv.load({ path: envFile });

program
    .option('-e, --env-file [path]', 'Environment file to use')
    .parse(process.argv);

export const config = Object.freeze({
    dltServiceBaseUrl: process.env.DLT_SVC_BASE_URL!,
    port: parseInt(process.env.PORT || program.port || defaultPort)
});

logger.info(`Loaded configuration: ${JSON.stringify(config, null, 2)}`);
