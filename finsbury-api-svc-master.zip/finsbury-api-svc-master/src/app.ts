import express = require('express');
import { TradeEventController } from './controllers/trade-event-controller';

const app = express();

app.get('/healthcheck', (_req, res) => {
    res.status(200).send(JSON.stringify({ status: 'ok', msg: 'I am alive'}));
});

app.use('/tradeEvents', TradeEventController);

app.use((_req, res) => {
    res.sendStatus(404);
});

export default app;
