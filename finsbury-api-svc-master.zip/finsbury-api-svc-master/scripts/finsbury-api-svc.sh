#!/bin/bash

APP_NAME=finsbury-api-svc

SERVICE_DIR_PREFIX=/opt/drumg
LOG_DIR=${SERVICE_DIR_PREFIX}/logs
SERVICE_DIR=${SERVICE_DIR_PREFIX}/${APP_NAME}
APP_DIR=${SERVICE_DIR}/app

die() { echo "$*" 1>&2 ; exit 1; }

stop() {
    echo "$APP_NAME stopping ..."
    cd ${APP_DIR}
    npm stop
    echo "$APP_NAME stopped ..."
}

start() {
    echo "Starting $APP_NAME ..."
    cd ${APP_DIR}
    nohup sh -c "JSON_LOG_FILE=$LOG_DIR/$APP_NAME.json npm start 2>&1 >>${LOG_DIR}/${APP_NAME}.log &"
    echo "$APP_NAME started ..."
}

# Check interactive
PARENT_COMMAND=$(ps -o comm= $PPID)
if [ "$PARENT_COMMAND" = "bash" ]; then
    echo "You appear to be running this instead of 'sudo systemctl (start|stop) ${APP_NAME}.service'"
    read -rsp $'Are you sure? Press any key to continue, or Ctrl-C to exit...\n' -n1 key
fi

cd ${SERVICE_DIR} || die "Service is not present in expected location ${SERVICE_DIR}"

case $1 in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        stop && sleep 5 && start
        ;;
esac

exit 0
