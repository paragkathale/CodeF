import assert = require('assert');
import { expect } from 'chai';
import { AddressInfo } from 'net';
import packageJson from '../../package.json';
import { config } from '../../src/config';
import { server, serviceName } from '../../src/finsbury-api-svc';

describe('Service startup', () => {
  let addr: AddressInfo;

  before(() => {
    assert(server !== undefined, 'server is undefined');
    addr = server.address() as AddressInfo;
    assert(addr !== undefined, 'server.address() is undefined');
  });

  after(() => {
    server.close();
  });

  it(`listens on port ${config.port}`, () => {
    expect(addr.port).to.equal(config.port);
  });

  it(`process title is ${serviceName}`, () => {
    expect(process.title).to.equal(serviceName);
  });

});

describe('Service configuration', () => {
  const privateLicense = 'UNLICENSED'; // see https://docs.npmjs.com/files/package.json#license
  it(`uses the private license ${privateLicense}`, () => {
    expect(packageJson.license).to.equal(privateLicense);
  });
});
