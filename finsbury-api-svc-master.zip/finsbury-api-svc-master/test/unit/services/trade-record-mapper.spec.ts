import { mapTradeRecordToTradeEvent } from '../../../src/services/trade-record-mapper';
import testTradeRecords from './testTradeRecords.json';
import { expect } from 'chai';

describe('Trade record to trade event mapper', () => {
    it('should return correctly mapped trade event', () => {
        const testTradeRecord = testTradeRecords.tradeRecords[0];
        const tradeEvent = mapTradeRecordToTradeEvent(testTradeRecord);

        expect(tradeEvent).to.deep.equal({
            state: 'CANCELLED',
            custodianStatus: 'Unaffirmed',
            custodianNarrative: 'Counterpart\'s DK transaction',
            eventTime: '2019-03-19T09:51:05.793Z',
            updatedAt: '2019-03-22T12:51:06.981Z',
            source: 'Corda_CU',
            transType: 'N',
            stateRef: '74306BD03A7F3C1EEA692A0E18A7347793110942CB4A3A488817EFEC3CD941CF[0]',
            dgId: '95c6ea51-dcca-4dab-8c43-15df39579afc',
            dataType: 'tradeRecord',
            data: testTradeRecord
        });
    });
});
