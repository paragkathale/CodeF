import { mapTradePairToTradeEvent } from '../../../src/services/trade-pair-mapper';
import testTradePairs from './testTradePairs.json';
import { expect } from 'chai';

describe('Trade pair to trade event mapper', () => {
    it('should return correctly mapped trade event', () => {
        const testTradePair = testTradePairs.tradePairs[0];
        const tradeEvent = mapTradePairToTradeEvent(testTradePair);

        expect(tradeEvent).to.deep.equal({
            state: 'PAIRED',
            custodianStatus: 'Affirmed',
            custodianNarrative: undefined,
            eventTime: '2019-03-14T21:11:05.993Z',
            updatedAt: '2019-03-22T12:51:06.981Z',
            source: 'Corda_CU',
            transType: 'N',
            stateRef: 'FC910D271F26732D79F9E0286B2F0F7F52124BFD0D27E7249EEEE8731554F692[0]',
            dgId: '56427c6e-1f8f-43ee-b27f-85191c099047',
            dataType: 'tradePair',
            data: testTradePair
        });
    });
});
