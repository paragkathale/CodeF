import { expect } from 'chai';
import nock from 'nock';
import { TradeEventService } from '../../../src/services/trade-event-service';
import testTradeRecords from './testTradeRecords.json';
import testTradePairs from './testTradePairs.json';

describe('tradeEventService', () => {
    const tradeEventService = new TradeEventService('http://example.com');

    describe('getTradeEvents', () => {
        const txId = 'e6576a34-8f31-4471-b24f-5dbf36cc316c';

        beforeEach(() => {
            nock('http://example.com')
                .get('/tradeRecords')
                .query({ transactionId: txId, includeHistory: true })
                .reply(200, testTradeRecords);

            nock('http://example.com')
                .get('/tradePairs')
                .query({ transactionId: txId, includeHistory: true })
                .reply(200, testTradePairs);
        });

        it('should return correctly formed trade events received from trade records endpoint', async () => {
            const resp = await tradeEventService.getTradeEvents(txId);
            expect(resp.length).equal(2);
            expect(resp[0].dgId).equal(testTradeRecords.tradeRecords[0].dgId);
            expect(resp[1].dgId).equal(testTradePairs.tradePairs[0].dgId);
        });
    });
});
