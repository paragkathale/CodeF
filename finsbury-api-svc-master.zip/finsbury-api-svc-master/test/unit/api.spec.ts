import assert = require('assert');
import { expect } from 'chai';
import http = require('http');
import { AddressInfo } from 'net';
import request = require('request');
import app from '../../src/app';

describe('Test API Endpoints', () => {
    let server: http.Server;
    let urlRoot: string;

    before(() => {
      server = app.listen(0); // use any available port
      assert(server !== undefined, 'server is undefined');
      const addr = server.address() as AddressInfo;
      assert(addr !== undefined, 'server.address() is undefined');
      urlRoot = `http://localhost:${addr.port}`;
    });

    after(() => {
      server.close();
    });

    it('GET /healthcheck returns status 200 with json', (done) => {
        const url = `${urlRoot}/healthcheck`;
        request(url, (_error, response, body) => {
          expect(response.statusCode).to.equal(200);
          expect(JSON.parse(body)).to.deep.equal({ status: 'ok', msg: 'I am alive'});
          done();
      });
    });

    const invalidRoute = 'InvalidRouteForUnitTesting';
    it(`GET /${invalidRoute} returns 404`, (done) => {
      const url = `${urlRoot}/${invalidRoute}`;
      request(url, (_error, response, _body) => {
        expect(response.statusCode).to.equal(404);
        done();
      });
    });
});
