<p align="center">
  <img src="https://www.drumg.com/wp-content/themes/drumg/dist/img/logo.png" alt="DrumG" width="500">
</p>

# Finsbury API Service

This repo contains the source for DrumG's Finsbury API Service.

# Service Information

| Attribute | Info |
| --------- | ---- |
| Service Port | 18902 |
| Network Zone | App zone |

# API Reference

## GET /healthcheck

Returns status 200 "OK" if the service is responsive.

### Example Response body
```json
{
    "status": "ok",
    "msg": "I am alive"
}
```

## GET /tradeEvents?transactionId=123456

Returns history of all trade events including unpaired and paired records

### Example Response body
```json
[
    {
        "state": "CANCELLED",
        "custodianStatus": "Unaffirmed",
        "custodianNarrative": "Counterpart's DK transaction",
        "eventTime": "2019-03-19T09:51:05.793Z",
        "updatedAt": "2019-03-22T12:51:06.981Z",
        "source": "Corda_CU",
        "transType": "N",
        "stateRef": "74306BD03A7F3C1EEA692A0E18A7347793110942CB4A3A488817EFEC3CD941CF[0]",
        "dgId": "95c6ea51-dcca-4dab-8c43-15df39579afc",
        "dataType": "tradeRecord",
        "data": {
            "fund": {
                "accountNumber": "JPM",
                "manager": "Corda_IM",
                "administrator": "Corda_FA"
            },
            "provider": "Corda_CU",
            "role": "Custodian",
            "investmentId": "ISIN",
            "transactionId": "e6576a34-8f31-4471-b24f-5dbf36cc316c",
            "tradeDetails": "{\"fund\":{\"manager\":\"AQR\",\"identifiers\":{\"adminCode\":\"FUNDABC\",\"accountNumber\":\"JPM\"},\"account\":{\"fundCode\":\"JPM\",\"brokerCode\":\"JPM\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"fundVersion\":\"491315808\",\"fundCode\":\"e6576a34-8f31-4471-b24f-5dbf36cc316c\",\"TransID\":\"e6576a34-8f31-4471-b24f-5dbf36cc316c\"}},\"investment\":{\"type\":\"Equity\",\"universal\":{\"ISIN\":\"US10922N1037\",\"ticker\":\"BHF\",\"SEDOL\":\"BF429K9\",\"CUSIP\":\"10922N103\"},\"identifiers\":{\"fundName\":\"Brighthouse Financial Ord Shs\"}},\"details\":{\"type\":\"BUYL\",\"tradeDate\":\"20170807\",\"settleDate\":\"20170807\",\"tradeCurrency\":\"USD\",\"settleCurrency\":\"USD\",\"quantity\":\"10\",\"price\":\"0.0001\",\"commissions\":\"0\",\"fees\":{\"SEC\":\"0\",\"other\":\"0\"},\"netTradeAmount\":\"0.001\",\"grossTradeAmount\":\"0\",\"executingBroker\":{\"fundCode\":\"CSFB\"},\"clearingBroker\":{\"fundCode\":\"JPMC\"},\"additional\":{}},\"status\":{\"lastUpdate\":\"2019-03-19T09:51:05.793Z\",\"latest\":{\"custodianStatus\":{\"value\":\"Unaffirmed\",\"updated\":\"2019-03-19T09:51:05.793Z\"},\"custodianNarrative\":{\"value\":\"Counterpart's DK transaction\",\"updated\":\"2019-03-19T09:51:05.793Z\"}}},\"source\":{\"documentName\":\"2019-03-19T09:51:05.411164_2_cu_upload_new_trade\",\"received\":\"2019-03-19T09:51:05.793Z\",\"transport\":\"FTP\",\"protocol\":\"XSLX\"}}",
            "broker": "Corda_CU",
            "source": "{\"documentName\":\"2019-03-19T09:51:05.411164_2_cu_upload_new_trade\",\"received\":\"2019-03-19T09:51:05.793Z\",\"transport\":\"FTP\",\"protocol\":\"XSLX\"}",
            "status": "CANCELLED",
            "stateRef": "74306BD03A7F3C1EEA692A0E18A7347793110942CB4A3A488817EFEC3CD941CF[0]",
            "dgCreatedTimestamp": "2019-03-22T12:51:06.981Z",
            "dgConsumedTimestamp": "2019-03-22T12:51:54.293Z",
            "dgId": "95c6ea51-dcca-4dab-8c43-15df39579afc"
        }
    }
]
```

# Development Usage

## Install

Obtain an API token from https://packagecloud.io for access to DrumG's private package repo.  Then run:

    export PKGCLOUD_NPM_TOKEN=<token-value>
    npm install @drumg/long-island-tea --save

### Commands

- `npm run build` to download pre-requisites like NPM packages, compile contracts and services files.
- `npm run start` to start service
- `npm run stop` to stop service
- `npm run clean` to clean runtime files and built package
- `npm run test` to execute unit tests
- `npm run check-license` to check dependency licenses
# finsbury-api-svc
