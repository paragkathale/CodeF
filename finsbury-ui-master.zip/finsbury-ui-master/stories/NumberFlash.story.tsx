import { storiesOf } from '@storybook/react';
import * as React from 'react';

import NumberFlash from '../src/components/NumberFlash';

const stories = storiesOf('NumberFlash', module);

class Wrapper extends React.Component {
  state = {
    number: 9999,
  }

  render() {
    const { number } = this.state;

    const add = (state: { number: number }) => ({ number: state.number + 1 });
    const subtract = (state: { number: number }) => ({ number: state.number - 1 });

    return (
      <div>
        <button type="button" onClick={() => this.setState(add)}>add</button>
        <button type="button" onClick={() => this.setState(subtract)}>subtract</button>
        <hr />
        <br />
        <br />
        <br />
        <NumberFlash number={number} />
      </div>
    );
  }
}

stories.add('NumberFlash', () => (
  <Wrapper />
));
