import * as React from 'react';
import { storiesOf } from '@storybook/react';
import TradeRecordList from '../src/components/TradeRecordList';
import paginate from '../src/HOC/paginate';

// @ts-ignore
import exampleApiResponse from '../data/generated/mock-api-response-1551373147895.json';

const parsedTrades = exampleApiResponse.tradeRecords.slice(0, 100).reduce((acc, next, index) => {
  const item = { ...next };

  item.tradeDetails = JSON.parse(item.tradeDetails);
  item.id = `${item.id}-${index}`;

  return acc.concat(item);
}, []);

const stories = storiesOf('Paginate HOC', module);

const PaginatedTradeRecordList = paginate(TradeRecordList);

stories.add(
  'default',
  () => (
    <PaginatedTradeRecordList
      data={parsedTrades}
      pageSize={20}
      propName="trades"
      type="tradeRecord"
    />
  ),
);
