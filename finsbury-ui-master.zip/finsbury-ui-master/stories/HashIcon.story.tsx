import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { withKnobs, text, number } from '@storybook/addon-knobs';

import HashIcon from '../src/components/HashIcon';

const stories = storiesOf('HashIcon', module);

stories.addDecorator(withKnobs);

stories.add('default', () => {
  const hash = text('Hash', 'hashstring');
  const size = number('Size', 100);

  return (
    <div style={{ padding: 80 }}>
      <HashIcon hash={hash} size={size} />
    </div>
  );
});
