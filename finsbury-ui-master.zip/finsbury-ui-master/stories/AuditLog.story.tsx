import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { withKnobs, number } from '@storybook/addon-knobs';

import AuditLog from '../src/components/AuditLog';
import { TradeEvent } from '../src/types';

const stories = storiesOf('AuditLog', module);

stories.addDecorator(withKnobs);

stories.add('default', () => {
  const testEvent: TradeEvent = {
    state: 'test state',
    custodianStatus: 'test status',
    eventTime: 'test timestamp',
    source: 'test source',
    custodianNarrative: 'test detail',
    dgId: 'adfadsfasdfasdf',
    transType: 'test trans type',
    dataType: 'tradeRecord',
    data: 'test trade data',
  };

  const data: TradeEvent[] = [];

  for (let i = 0; i <= 5; i += 1) {
    data[i] = testEvent;
  }

  const records = number('Record count', 0);
  const entries = data.slice(0, records);

  return (
    <div style={{ padding: 80 }}>
      <AuditLog entries={entries} />
    </div>
  );
});
