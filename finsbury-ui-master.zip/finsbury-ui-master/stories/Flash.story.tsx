import { storiesOf } from '@storybook/react';
import * as React from 'react';

import Flash from '../src/components/Flash';

const stories = storiesOf('Flash', module);

class Wrapper extends React.Component {
  state = {
    number: 1,
  }

  render() {
    const { number } = this.state;

    const add = (state: { number: number }) => ({ number: state.number + 1 });
    const subtract = (state: { number: number }) => ({ number: state.number - 1 });

    return (
      <div>
        <button type="button" onClick={() => this.setState(add)}>add</button>
        <button type="button" onClick={() => this.setState(subtract)}>subtract</button>
        <hr />
        <br />
        <br />
        <br />
        <Flash number={number} />
      </div>
    );
  }
}

stories.add('Flash', () => (
  <Wrapper />
));
