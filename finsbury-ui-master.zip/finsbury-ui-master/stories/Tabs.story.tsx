import { storiesOf } from '@storybook/react';
import * as React from 'react';

import Tabs from '../src/components/Tabs';

const stories = storiesOf('Tabs', module);

stories.add('Tabs', () => (
  <div style={{ margin: 100 }}>
    <Tabs
      content={[
        { title: 'tab one', content: (<p>tab one content</p>) },
        { title: 'tab two', content: (<p>tab two content</p>) },
        { title: 'tab three', content: (<p>tab three content</p>) },
      ]}
    />
  </div>
));
