import { storiesOf } from '@storybook/react';
import * as React from 'react';

import DropdownMenu from '../src/components/DropdownMenu';

const stories = storiesOf('DropdownMenu', module);

const options = [
  {
    onClick: () => alert('Option 1 clicked'),
    render: 'Option 1',
    key: 'option1',
  },
  {
    onClick: () => alert('Option 2 clicked'),
    render: 'Option 2',
    key: 'option2',
  },
];

stories.add('DropdownMenu', () => (
  <DropdownMenu
    title="Dropdown Menu Title"
    options={options}
  />
));
