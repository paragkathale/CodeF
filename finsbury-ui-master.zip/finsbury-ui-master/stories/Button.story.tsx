import * as React from 'react';
import { storiesOf } from '@storybook/react';
import Button from '../src/components/Button';

const stories = storiesOf('Button', module);

stories.add(
  'default',
  () => (
    <div style={{ padding: 80 }}>
      <Button onClick={() => alert('clicked')}>
        Click me
      </Button>
    </div>
  ),
);

stories.add(
  'loading',
  () => (
    <div style={{ padding: 80 }}>
      <Button loading onClick={() => alert('clicked')}>
        Click me
      </Button>
    </div>
  ),
);
