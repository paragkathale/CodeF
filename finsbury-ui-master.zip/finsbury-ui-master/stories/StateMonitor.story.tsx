import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { withKnobs, select } from '@storybook/addon-knobs';

import StateMonitor from '../src/components/StateMonitor';

const stories = storiesOf('StateMonitor', module);

stories.addDecorator(withKnobs);

stories.add('default', () => {
  const state = select('State', {
    'No data': null,
    'Investment Manager': 'im',
    Custodian: 'cust',
    Broker: 'broker',
    Admin: 'admin',
  }, null);

  return (
    <div style={{ padding: 80 }}>
      <StateMonitor state={state} />
    </div>
  );
});
