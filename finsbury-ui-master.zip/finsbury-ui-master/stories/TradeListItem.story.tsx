import * as React from 'react';
import { storiesOf } from '@storybook/react';

import TradeListItem from '../src/components/TradeListItem';
// @ts-ignore
import tradePair from '../data/sample-parsed-trade-pair.json';

const stories = storiesOf('TradeListItem', module);

stories.add('with investment manager only', () => (
  <TradeListItem
    imData={tradePair.pair.first.details}
  />
));

stories.add('with investment manager and custodian', () => (
  <TradeListItem
    imData={tradePair.pair.first.details}
    custData={tradePair.pair.second.details}
  />
));

stories.add('with investment manager and custodian and broken fields', () => {
  // 'break' some fields.
  const cust = JSON.parse(JSON.stringify(tradePair.pair.second.details));
  const im = JSON.parse(JSON.stringify(tradePair.pair.first.details));

  im.details.quantity = '37710';
  cust.details.price = '8.89';

  return (
    <TradeListItem
      imData={im}
      custData={cust}
    />
  );
});
