import * as React from 'react';
import { storiesOf } from '@storybook/react';

const stories = storiesOf('Test', module);

const Test = () => (
  <div>Testing</div>
);

stories.add(
  'Test Component',
  () => <Test />,
);
