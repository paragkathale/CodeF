const { exec } = require('child_process');
const path = require('path');
const rimraf = require('rimraf');

const config = require('../webpack.config.prod.js');

// List of build targets.
const builds = [
  {
    apiUrl: 'https://dev-fin00-api00.drumg.io',
    outputPath: 'dist-a',
    oktaBaseUrl: 'https://dev-489565.okta.com',
    oktaClientId: '0oackkp9o4Pddjw33356',
    orgName: 'Investment Manager',
  },
  {
    apiUrl: 'https://dev-fin00-b-api00.drumg.io',
    outputPath: 'dist-b',
    oktaBaseUrl: 'https://dev-489565.okta.com',
    oktaClientId: '0oam7o8xzj3jqd9jr356',
    orgName: 'Custodian',
  },
  {
    apiUrl: 'https://dev-fin00-c-api00.drumg.io',
    outputPath: 'dist-c',
    oktaBaseUrl: 'https://dev-489565.okta.com',
    oktaClientId: '0oam7u5x9uFcSQvTw356',
    orgName: 'Prime Broker',
  },
  {
    apiUrl: 'https://dev-fin00-d-api00.drumg.io',
    outputPath: 'dist-d',
    oktaBaseUrl: 'https://dev-489565.okta.com',
    oktaClientId: '0oam7x3wlNm7Bqd9i356',
    orgName: 'Fund Admin',
  },
];

process.env.NODE_ENV = 'production';

// Create each build artifact. Clean old artifacts, and then build with webpack.
builds.forEach((build) => {
  // Delete old builds.
  rimraf(path.resolve(__dirname, '..', build.outputPath), (err) => {
    if (err) {
      throw new Error(err);
    }

    config.output.path = path.resolve(__dirname, '..', build.outputPath);

    // eslint-disable-next-line no-console
    console.log(`---> Building to ${build.outputPath}`);

    const envVars = {
      API_URL: build.apiUrl,
      NODE_ENV: 'production',
      OKTA_BASE_URL: build.oktaBaseUrl,
      OKTA_CLIENT_ID: build.oktaClientId,
      ORG_NAME: build.orgName,
    };

    // expand envVars to "key1='val1' key2='val2'..." so that it can set the environment variables on the build command after
    const stringVars = Object.entries(envVars).reduce((acc, next) => (`${acc} ${next.join('=').replace(/(\w+)=(.*)/, "$1='$2'")}`), '');

    // Run this shell command to overwrite the webpack config per build.
    console.log(`stringVars: ${stringVars}`);
    exec(`${stringVars} ./node_modules/.bin/webpack --config webpack.config.prod.js --output-path ${build.outputPath}`, (error, stdout, stderr) => {
      if (error) {
        // eslint-disable-next-line no-console
        console.error(`exec error: ${error}`);
        return;
      }

      // eslint-disable-next-line no-console
      console.log(`stdout: ${stdout}`);
      // eslint-disable-next-line no-console
      console.log(`stderr: ${stderr}`);
    });
  });
});
