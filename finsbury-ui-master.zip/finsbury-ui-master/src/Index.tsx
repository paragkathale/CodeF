import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Security, SecureRoute, ImplicitCallback } from '@okta/okta-react';

import './assets/favicon.png';
import './styles/style.scss';
import App from './components/App';
import Login from './components/Login';
import NotFound from './components/NotFound';

import ApiWorker from './api/apiWorker';

const w = new ApiWorker();

const onAuthRequired = ({ history }: any) => history.push('/login');

const {
  OKTA_BASE_URL,
  OKTA_CLIENT_ID,
} = process.env;

ReactDOM.render(
  <Router>
    <Security
      issuer={`${OKTA_BASE_URL}/oauth2/default`}
      client_id={OKTA_CLIENT_ID}
      redirect_uri={`${window.location.origin}/implicit/callback`}
      onAuthRequired={onAuthRequired}
    >
      <Switch>
        <SecureRoute path="/" exact render={() => <App apiWebworker={w} />} />
        <Route path="/login" render={() => <Login baseUrl={OKTA_BASE_URL} />} />
        <Route path="/implicit/callback" component={ImplicitCallback} />
        <Route component={NotFound} />
      </Switch>
    </Security>
  </Router>,
  document.getElementById('root'),
);
