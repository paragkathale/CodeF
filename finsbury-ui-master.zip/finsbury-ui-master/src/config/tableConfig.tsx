import {
  safeFormatCurrency,
  safeFormatDate,
  safeFormatNumber,
  safeFormatTimestamp,
} from '../utils/formatters';
import { TableConfig } from '../types';

export const tableConfig: TableConfig = {
  name: 'trade-entry',
  columnConfig: [
    {
      displayName: 'Fund',
      propertyName: 'fund',
    },
    {
      displayName: 'Trade Date',
      propertyName: 'tradeDate',
      renderer: safeFormatDate,
    },
    {
      displayName: 'ISIN',
      propertyName: 'isin',
    },
    {
      displayName: 'Security',
      propertyName: 'security',
    },
    {
      displayName: 'Direction',
      propertyName: 'direction',
    },
    {
      displayName: 'Quantity',
      propertyName: 'quantity',
      renderer: safeFormatNumber,
    },
    {
      displayName: 'Price',
      propertyName: 'price',
      renderer: safeFormatCurrency,
    },
  ],
};

export const matchTableConfig: TableConfig = {
  name: 'match-analysis',
  columnConfig: [
    {
      displayName: 'Transaction State:',
      propertyName: 'blank',
    },
    {
      displayName: 'Status',
      propertyName: 'status',
    },
    {
      displayName: 'IM Source Timestamp',
      propertyName: 'imSourceTimestamp',
      renderer: safeFormatTimestamp,
    },
    {
      displayName: 'Custody Name',
      propertyName: 'custodyName',
    },
    {
      displayName: 'Custody Source Timestamp',
      propertyName: 'custodySourceTimestamp',
      renderer: safeFormatTimestamp,
    },
  ],
};

export const matchSubTableConfig: TableConfig = {
  name: 'match-analysis-trades',
  columnConfig: [
    {
      displayName: 'Name',
      propertyName: 'imName',
      renderer: (val, row) => (row.id === 'im' ? val : row.custName),
    },
    {
      displayName: 'Security',
      propertyName: 'security',
    },
    {
      displayName: 'ISIN',
      propertyName: 'isin',
    },
    {
      displayName: 'Net Trade Amt',
      propertyName: 'netTradeAmount',
      renderer: safeFormatCurrency,
    },
    {
      displayName: 'Price',
      propertyName: 'price',
      renderer: safeFormatCurrency,
    },
    {
      displayName: 'Quantity',
      propertyName: 'quantity',
      renderer: safeFormatNumber,
    },
  ],
};

export const affirmationConfig: TableConfig = {
  name: 'affirmation',
  columnConfig: [
    {
      displayName: 'Affirmation Status:',
      propertyName: 'blank',
    },
    {
      displayName: 'Status',
      propertyName: 'affirmationStatus',
    },
    {
      displayName: 'Timestamp',
      propertyName: 'affirmationTimestamp',
      renderer: safeFormatTimestamp,
    },
    {
      displayName: 'Source',
      propertyName: 'affirmationSource',
    },
  ],
};

export const settlementConfig: TableConfig = {
  name: 'settlement',
  columnConfig: [
    {
      displayName: 'Settlement Status:',
      propertyName: 'custName',
    },
    {
      displayName: 'Status',
      propertyName: 'settlementStatus',
    },
    {
      displayName: 'Timestamp',
      propertyName: 'settlementTimestamp',
      renderer: safeFormatTimestamp,
    },
    {
      displayName: 'Additional Details',
      propertyName: 'additionalDetails',
    },
  ],
};
