/**
 * Detect if an input is numeric.
 *
 * @param {number | string}
 *
 * @returns {boolean}
 */
export default (num: number | string) => (
  !Number.isNaN(parseFloat(num as string)) || Number.isFinite(num as number)
);
