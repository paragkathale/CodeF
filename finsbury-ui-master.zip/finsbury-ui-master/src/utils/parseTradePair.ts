import { TradePair, ParsedTradePair } from '../types';

/**
 * Transform a TradePair into a ParsedTradePair.
 *
 * @param {TradePair}
 *
 * @returns {ParsedTradePair}
 */
export default (record: TradePair): ParsedTradePair => ({
  ...record,
  pair: {
    ...record.pair,
    first: {
      ...record.pair.first,
      details: JSON.parse(record.pair.first.details),
    },
    second: {
      ...record.pair.second,
      details: JSON.parse(record.pair.second.details),
    },
  },
});
