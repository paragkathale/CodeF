import { TradeRecord, ParsedTradeRecord } from '../types';

/**
 * Transform a TradeRecord into a ParsedTradeRecord.
 *
 * @param {TradeRecord}
 *
 * @returns {ParsedTradeRecord}
 */
export default (record: TradeRecord): ParsedTradeRecord => ({
  ...record,
  tradeDetails: JSON.parse(record.tradeDetails),
});
