/**
 * Safely get a value from a deeply nested object.
 *
 * @param {string[]} path - Object path.
 * @param {any} src - Source object.
 *
 * @returns {any|null}
 */
export default (path: string[], src: any) => (
  path.reduce((acc, next) => (
    acc && acc[next] ? acc[next] : null
  ), src)
);
