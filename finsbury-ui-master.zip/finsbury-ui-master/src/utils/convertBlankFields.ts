/**
 * Convert falsy field values in an object to `fallback`.
 *
 * @param {any}
 * @param {string}
 *
 * @returns {any}
 */
export default (record: any, fallback = 'Pending'): any => (
  Object.keys(record).reduce((acc, next) => (
    ({ ...acc, [next]: (record[next] || fallback) })
  ), {})
);
