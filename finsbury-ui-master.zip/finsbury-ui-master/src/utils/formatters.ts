import { format, parse, isValid } from 'date-fns';

import isNumeric from './isNumeric';

export const safeFormatDate = (val: any) => (
  isValid(parse(val)) ? format(val, 'YYYY-MM-DD') : val
);

export const safeFormatTimestamp = (val: any) => (
  isValid(parse(val)) ? format(val, 'HH:mm:ss YYYY-MM-DD') : val
);

export const currency = (val: number) => (
  new Intl.NumberFormat('en', { style: 'currency', currency: 'USD' }).format(val)
);

export const safeFormatCurrency = (val: any) => (
  isNumeric(val) ? currency(val as number) : val
);

export const number = (val: number) => (
  new Intl.NumberFormat('en').format(val)
);

export const safeFormatNumber = (val: any) => (
  isNumeric(val) ? number(val as number) : val
);
