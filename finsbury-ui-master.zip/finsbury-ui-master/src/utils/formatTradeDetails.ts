import { TradeDetails, FormattedTradeDetails } from '../types';
import safeGet from './safeGet';

/**
 * Format a TradeDetails object for use in a UI.
 *
 * @param {TradeDetails | undefined} record.
 *
 * @returns {FormattedTradeRecord}
 */
export default (record: TradeDetails | undefined): FormattedTradeDetails => {
  const getFromRecord = (path: string[]) => safeGet(path, record);

  return {
    // Outer trade details.
    fund: getFromRecord(['fund', 'identifiers', 'adminCode']),
    tradeDate: getFromRecord(['details', 'tradeDate']),
    isin: getFromRecord(['investment', 'universal', 'ISIN']),
    price: getFromRecord(['details', 'price']),
    security: getFromRecord(['investment', 'universal', 'ticker']),
    direction: getFromRecord(['details', 'type']),
    quantity: getFromRecord(['details', 'quantity']),

    // Match analysis table.
    blank: ' ',
    status: 'Pending', // source.provider
    sourceTimestamp: getFromRecord(['source', 'received']),
    custodyName: getFromRecord(['details', 'clearingBroker', 'fundCode']),

    // Pair details table
    imName: getFromRecord(['fund', 'manager']),
    custName: getFromRecord(['details', 'clearingBroker', 'fundCode']),
    // blank
    // security
    netTradeAmount: getFromRecord(['details', 'netTradeAmount']),
    // price
    // quantity

    // Affirmation table
    affirmationStatus: 'Pending',
    affirmationTimestamp: 'Pending',
    affirmationSource: 'Pending',

    // Settlement table
    settlementStatus: getFromRecord(['status', 'latest', 'custodianStatus', 'value']), // status.TransactionStatusDescription
    settlementTimestamp: getFromRecord(['status', 'latest', 'custodianStatus', 'updated']), // status.lastUpdate
    settlementSource: 'Pending',
    additionalDetails: getFromRecord(['status', 'latest', 'custodianNarrative', 'value']),
  };
};
