// import { TradeState, StateDiffMessage } from '../types';

type ActionType = 'tradePairs' | 'tradeRecords';

interface StateDiff {
  new: {
    byId: { [key: string]: any },
    ids: Set<string>,
  },
  remove: Set<string>,
  update: {
    byId: { [key: string]: any },
    ids: Set<string>,
  },
}

interface Action {
  type: ActionType,
  diff: StateDiff,
}

interface State {
  tradeRecords: {
    byId: { [key: string]: any },
    ids: Set<string>,
  },
  tradePairs :{
    byId: { [key: string]: any },
    ids: Set<string>,
  },
}

export default (state: Readonly<State>, action: Action): State | null => {
  const nextState = { ...state };
  const { type, diff } = action;

  if (diff.new && diff.new.ids.size) {
    nextState[type].ids = new Set([...diff.new.ids, ...state[type].ids]);
    nextState[type].byId = { ...state[type].byId, ...diff.new.byId };
  }

  if (diff.remove && diff.remove.size) {
    [...diff.remove].forEach((id) => {
      nextState[type].ids.delete(id);

      delete nextState[type].byId[id];
    });
  }

  if (diff.update && diff.update.ids.size) {
    [...diff.update.ids].forEach((id) => {
      nextState[type].byId[id] = diff.update.byId[id];
    });
  }

  return nextState;
};
