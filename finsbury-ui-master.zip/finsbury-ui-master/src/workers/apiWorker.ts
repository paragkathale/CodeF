/* eslint-env worker */
/* eslint-disable eslint-comments/disable-enable-pair */
/* eslint-disable no-restricted-globals */

import ApiPoller from '../api/apiPoller';
import {
  ApiResponse,
  TradePairsApiResponse,
  TradePair,
  TradeRecord,
} from '../types';

type ApiHandler<T> = (data: T) => void;
const API_INTERVAL = 5000;

interface StateDiffMessage<T> {
  new: NormalizedState<T>;
  remove: Set<string>;
  update: NormalizedState<T>;
}

interface NormalizedState<T> {
  ids: Set<string>
  byId: { [key: string]: T },
}

interface Store {
  tradeRecords: NormalizedState<TradeRecord>;
  tradePairs: NormalizedState<TradePair>;
}

const { API_URL } = process.env;

if (API_URL === undefined) {
  throw new Error('API_URL env is undefined.');
}

// Our store object.
const store: Store = {
  // Trade record state object.
  tradeRecords: {
    ids: new Set(),
    byId: {},
  },
  // Trade pair state object.
  tradePairs: {
    ids: new Set(),
    byId: {},
  },
};

/**
 * Build up a NormalizedState object based on an array of `records`.
 *
 * @param {T[]} records
 *
 * @returns {NormalizedState<T>}
 */
// eslint-disable-next-line arrow-parens
const normalize = <T>(records: T[]): NormalizedState<T> => {
  const newState: NormalizedState<T> = {
    ids: new Set(),
    byId: {},
  };

  records.forEach((record: T) => {
    // @ts-ignore
    const { dgId: id } = record;

    // Throwing an error here because for some reason TS can't figure out
    // that the dgId property exists on `record`.
    if (!id) {
      throw new Error('Could not find dgId on object');
    }

    newState.ids.add(id);
    newState.byId[id] = record;
  });

  return newState;
};

/**
 * Calculate a difference of two sets.
 *
 * @param {Set<T>} a
 * @param {Set<T>} b
 *
 * @returns {Set<T>}
 */
const difference = <T>(a: Set<T>, b: Set<T>): Set<T> => (
  new Set([...a].filter(x => !b.has(x)))
);

/**
 * Calculate the difference between `current` and `next` state.
 *
 * @param {NormalizedState<T>} current - Current state.
 * @param {NormalizedState<T>} next - Next state.
 *
 * @returns {StateDiffMessage<T>}
 */
// eslint-disable-next-line arrow-parens
const resolveDiff = <T>(
  current: NormalizedState<T>,
  next: NormalizedState<T>,
  comparator: (a: T, b: T) => boolean,
): StateDiffMessage<T> => {
  const { ids: currentIds, byId: currentById } = current;
  const { ids: nextIds, byId: nextById } = next;

  const addedIds = difference(nextIds, currentIds);
  const added = {
    byId: [...addedIds].reduce((acc, n) => ({ ...acc, [n]: nextById[n] }), {}),
    ids: new Set(addedIds),
  };

  const removedIds = difference(currentIds, nextIds);

  // Compare objects in the state to see if they're different.
  const updated = [...nextIds].reduce((acc, nextId) => {
    const nextObj = nextById[nextId];
    const currentObj = currentById[nextId];

    if (!currentObj) {
      return acc;
    }

    if (!comparator(currentObj, nextObj)) {
      return {
        ...acc,
        ids: new Set([...acc.ids, nextId]),
        byId: { ...acc.byId, [nextId]: nextObj },
      };
    }

    return acc;
  }, {
    ids: new Set(),
    byId: {},
  });

  return {
    new: added,
    remove: removedIds,
    update: updated,
  };
};

/**
 * Generate an API handler function.
 *
 * @param {'tradeRecords' | 'tradePairs'} type
 *
 * @returns {ApiHandler}
 */
const getApiHandler = <A, T>(type: 'tradeRecords' | 'tradePairs', comparator: (a: T, b: T) => boolean): ApiHandler<A> => (data: A): void => {
  // Reverse the order of the data from the API so the newest records are on top.
  // TODO (brianmcallister) - Sort by last updated?
  // @ts-ignore no index signature?
  const newState = normalize<T>(data[type].reverse());
  // @ts-ignore no idea
  const diff = resolveDiff<T>(store[type], newState, comparator);

  // @ts-ignore no idea
  store[type] = newState;

  // @ts-ignore because compiler does not recognize this is a webworker
  self.postMessage({
    type,
    diff,
  });
};

const tradeRecordCompare = (a: TradeRecord, b: TradeRecord) => (
  a.tradeDetails === b.tradeDetails
  && a.status === b.status
);
const tradePairCompare = (a: TradePair, b: TradePair) => (
  a.pair.first.details === b.pair.first.details
  && a.pair.second.details === b.pair.second.details
  && a.status === b.status
);

// Set up the API pollers.
const handleTradeRecordData = getApiHandler<ApiResponse, TradeRecord>('tradeRecords', tradeRecordCompare);
const handleTradePairData = getApiHandler<TradePairsApiResponse, TradePair>('tradePairs', tradePairCompare);

const tradeRecordsPoller = new ApiPoller(`${API_URL}/tradeRecords`, API_INTERVAL);
tradeRecordsPoller.onData(handleTradeRecordData);

const tradePairsPoller = new ApiPoller(`${API_URL}/tradePairs`, API_INTERVAL);
tradePairsPoller.onData(handleTradePairData);

// Wait for messages.
self.onmessage = (event) => {
  const { data } = event;
  const { message, type } = data;

  // Only respond to messages of this type (not sure why we're picking up messages
  // from the React dev tools in development mode.
  if (type !== 'api') {
    return;
  }

  switch (message) {
    case 'start':
      tradeRecordsPoller.start();
      tradePairsPoller.start();
      break;
    case 'stop':
      tradeRecordsPoller.stop();
      tradePairsPoller.stop();
      break;
    default:
      break;
  }
};
