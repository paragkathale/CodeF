import * as context from 'window-or-global';
import { QueryablePromise } from '../types';

const { BEARER_TOKEN } = process.env;

type Callback = (data: any) => void;

export default class ApiPoller {
  interval: number;

  intervalId: number | undefined;

  listeners: Set<Callback>;

  previousRequest: QueryablePromise | undefined;

  url: string;

  options: { headers: { Authorization: string } };

  constructor(url: string, interval: number) {
    this.interval = interval;
    this.listeners = new Set();
    this.url = url;
    this.options = {
      headers: {
        Authorization: `Bearer ${BEARER_TOKEN}`,
      },
    };
  }

  private makeRequest = () => {
    if (this.previousRequest && !this.previousRequest.done) {
      return;
    }

    this.previousRequest = <QueryablePromise>fetch(this.url, this.options)
      .then(res => res.json())
      .then((json) => {
        if (this.previousRequest) this.previousRequest.done = true;
        this.listeners.forEach(listener => listener(json));
        return json;
      })
      // eslint-disable-next-line no-console
      .catch(err => console.error(err));
  }

  onData = (callback: Callback) => {
    this.listeners.add(callback);
  }

  start = () => {
    this.makeRequest();
    this.intervalId = context.setInterval(this.makeRequest, this.interval);
  }

  stop = () => {
    if (this.intervalId) {
      context.clearInterval(this.intervalId);
    }
  }
}
