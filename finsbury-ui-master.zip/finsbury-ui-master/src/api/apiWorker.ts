type Callback = (data: any) => void;

// Find the worker file URL from the build stats, which are inserted into
// the main template via Webpack. This logic lives in this function, because
// the mechanism by which we find the correct worker file might change in the
// future.
//
// Ideally we could map from the entry point defined in the webpack config to
// the emitted file, as opposed to looking through an array of all emitted files
// and filtering to get what 'might' be the correc file.
const getWorkerFileUrl = () => {
  const result = document.querySelector('#stats');

  if (!result) {
    throw new Error('Cannot find stats element');
  }

  const item = JSON.parse(result.textContent || '')
    .filter((i: string) => i.includes('worker') && !i.includes('map'))[0];

  return `/${item}`;
};

export default class ApiWorker {
  worker: Worker;

  listeners: Set<Callback>;

  constructor() {
    const file = getWorkerFileUrl();

    this.worker = new Worker(file);
    this.listeners = new Set();

    this.worker.onmessage = (event) => {
      const { data } = event;

      this.listeners.forEach(listener => listener(data));
    };
  }

  onMessage = (callback: Callback) => {
    this.listeners.add(callback);
  }

  send = (message: any) => this.worker.postMessage({ type: 'api', message });
}
