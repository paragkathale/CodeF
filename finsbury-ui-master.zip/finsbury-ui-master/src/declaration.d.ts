// Type declarations

// Image modules
declare module '*.png'
declare module '*.jpg'
declare module '*.gif'
declare module '*.svg'

// Global env variables
declare const API_URL: string;
declare const OKTA_BASE_URL: string;
declare const OKTA_CLIENT_ID: string;
declare const NODE_ENV: string;
declare const ORG_NAME: string;

declare module 'highlight.js/lib/highlight' {
  const hljs: any;

  // eslint-disable-next-line import/export
  export default hljs;
}

declare module 'highlight.js/lib/languages/json' {
  const json: any;

  // eslint-disable-next-line import/export
  export default json;
}

declare module '@okta/okta-react';
declare module '@okta/okta-auth-js';
