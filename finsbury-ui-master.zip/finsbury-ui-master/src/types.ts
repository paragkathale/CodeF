/**
 * Table Config
 */
export interface TableConfig {
  name: string,
  columnConfig: TableColumnConfig[];
}

export interface TableColumnConfig {
  displayName: string;
  propertyName: string;
  renderer?: (val: any, row: FormattedTradeDetails) => string | null | JSX.Element;
}

/**
 * Api Response
 */
export interface ApiResponse {
  [tradeRecords: string]: TradeRecord[];
}

export interface TradePairsApiResponse {
  tradePairs: TradePair[];
}

export interface BaseTradeRecord {
  fund: Fund;
  investmentId: string;
  transactionId: string;
  broker: string;
  source: string;
  status: string;
  dgId: string;
  stateRef: string;
}

export interface TradeRecord extends BaseTradeRecord {
  tradeDetails: string;
}

export interface ParsedTradeRecord extends BaseTradeRecord {
  tradeDetails: TradeDetails;
}


export interface ParsedApiResponse {
  tradeRecords: ParsedTradeRecord[];
}

export interface Fund {
  accountNumber: string;
  manager: string;
  administrator: string;
}

export interface TradeDetails {
  fund: {
    dgid: string;
    identifiers: {
      adminCode: string,
      adminAccount: string;
      adminAccountName: string;
      brokerAccountName: string;
      brokerCashAccount: string;
      primary: string;
      clearerAccountName: string;
      custodyAccount: string;
    }
  }
  transaction: {
    type: string;
    brokerAccount: string;
    identifiers: {
      TransID: string,
      lot: string;
      primary: string;
      admin: string;
      adminVersion: string;
      broker: string;
    }
  }
  investment: {
    type: string;
    identifiers: {
      ISIN: string;
      Ticker: string;
      SEDOL: string;
      CUSIP: string;
      BBTICKER: string;
      RIC: string;
      fundCode: string;
      fundDescription: string;
      adminCode: string;
      adminDescription: string;
      brokerCode: string;
      brokerDescription: string;
    },
    universal: {
      ISIN: string,
      ticker: string,
    }
  }
  details: {
    type: string;
    tradeDate: string;
    settleDate: string;
    tradeCurrency: string;
    settleCurrency: string;
    fxRate: string;
    quantity: string;
    price: string;
    commissions: string;
    fees: {
      SEC: string;
      other: string;
    }
    netTradeAmount: string;
    grossTradeAmount: string;
    executingBroker: {
      identifiers: {
        fundCode: string;
        fundDescription: string;
        adminCode: string;
        brokerCode: string;
        brokerDescription: string;
      }
    }
    clearingBroker: {
      identifiers: {
        fundCode: string;
        brokerCode: string;
        brokerDescription: string;
      }
    }
  }
  status: {
    latest: {
      custodianStatus: {
        value: string;
        updated: string;
      }
      custodianNarrative: {
        value: string;
        updated: string;
      }
    }
    messages: {
      'Transaction Status Description': string;
      'Additional Information': string;
    }[]
    lastUpdate: string;
  }
  source: {
    provider: string;
    received: string;
    transport: string;
    protocol: string;
    storage: {
      provider: string;
      url: string;
      hash: string;
    }
  }
}

export interface FormattedTradeDetails {
  id?: string,
  fund: string,
  tradeDate: string,
  isin: string,
  security: string,
  direction: string,
  quantity: string,
  price: string,
  blank: string,
  status: string,
  custodyName: string,
  sourceTimestamp: string,
  imName: string,
  custName: string,
  netTradeAmount: string,
  affirmationStatus: string,
  affirmationTimestamp: string,
  affirmationSource: string,
  settlementStatus: string,
  settlementTimestamp: string,
  settlementSource: string,
  additionalDetails: string,
}

export interface ParsedTradePair {
  dgId: string,
  status: string,
  stateRef: string,
  pair: {
    first: {
      details: TradeDetails,
      dgId: string,
    },
    second: {
      details: TradeDetails,
      dgId: string,
    }
  },
}

export interface TradePair {
  dgId: string,
  status: string,
  stateRef: string,
  pair: {
    first: {
      details: string,
      dgId: string,
    },
    second: {
      details: string,
      dgId: string,
    }
  },
}

export interface TradeEvent {
  state: string,
  custodianStatus: string;
  custodianNarrative: string;
  eventTime: string;
  source: string;
  transType: string;
  dgId: string;
  dataType: 'tradeRecord' | 'tradePair';
  data: TradeRecord | TradePair;
}

export interface QueryablePromise extends Promise<any> {
  done: boolean;
}

export interface TradeRecordMap {
  [key: string]: TradeRecord;
}

export interface TradePairMap {
  [key: string]: TradePair;
}

export interface TradeRecordState {
  ids: Set<string>;
  byId: TradeRecordMap;
}

export interface TradePairState {
  ids: Set<string>;
  byId: TradePairMap;
}

export interface StateDiffMessage {
  new: TradeRecordState;
  remove: Set<string>;
  update: TradeRecordState;
}
