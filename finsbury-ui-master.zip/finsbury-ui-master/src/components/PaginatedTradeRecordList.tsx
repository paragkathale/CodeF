import paginate from '../HOC/paginate';
import TradeRecordList from './TradeRecordList';

export default paginate(TradeRecordList);
