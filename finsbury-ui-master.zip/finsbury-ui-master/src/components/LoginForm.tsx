import * as React from 'react';
import classnames from 'classnames';
import OktaAuth from '@okta/okta-auth-js';
import { withAuth } from '@okta/okta-react';

import Input from './Input';
import Button from './Button';

interface Props {
  auth: any;
  baseUrl: string;
}

interface State {
  failed: boolean;
  loading: boolean;
  sessionToken: string | null;
  username: string;
  password: string;
}

class LoginForm extends React.Component<Props, State> {
  static baseClass = 'login-form';

  constructor(props: Props) {
    super(props);
    this.state = {
      failed: false,
      loading: false,
      sessionToken: null,
      username: '',
      password: '',
    };

    this.oktaAuth = new OktaAuth({ url: props.baseUrl });
  }

  handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    const { username, password } = this.state;

    this.setState({ loading: true });

    e.preventDefault();
    this.hideErrorMessage();
    this.oktaAuth.signIn({ username, password })
      .then((res: any) => this.setState({
        sessionToken: res.sessionToken,
      }))
      .finally(() => this.setState({ loading: false }))
      .catch(() => this.setState({ failed: true }));
  }

  handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ username: e.target.value });
  }

  handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ password: e.target.value });
  }

  hideErrorMessage = () => {
    const { failed } = this.state;

    if (failed) {
      this.setState({ failed: false });
    }
  }

  oktaAuth: any;

  render() {
    const { baseClass } = LoginForm;
    const { auth } = this.props;
    const {
      failed,
      loading,
      password,
      sessionToken,
      username,
    } = this.state;

    const labelClass = `${baseClass}__label`;
    const inputClass = `${baseClass}__input`;
    const errorMessageClass = classnames(`${baseClass}__error-message`, {
      [`${baseClass}__error-message--show`]: failed,
    });

    if (sessionToken) {
      auth.redirect({ sessionToken });
      return null;
    }

    return (
      <div className={`${baseClass}`}>
        <form className={`${baseClass}__form`} onSubmit={this.handleSubmit}>
          <h1 className={`${baseClass}__title`}>
            Log in
          </h1>
          <p className={errorMessageClass}>
            Username or password is incorrect.
          </p>
          <label className={labelClass} htmlFor="username">
            <span className={`${labelClass}-text`}>
              Username:
            </span>
            <Input
              className={inputClass}
              id="username"
              type="text"
              value={username}
              onChange={this.handleUsernameChange}
            />
          </label>
          <label className={labelClass} htmlFor="password">
            <span className={`${labelClass}-text`}>
              Password:
            </span>
            <Input
              className={`${inputClass} ${inputClass}--password`}
              id="password"
              type="password"
              value={password}
              onChange={this.handlePasswordChange}
            />
          </label>
          <Button
            className={`${baseClass}__button`}
            id="submit"
            type="submit"
            loading={loading}
          >
            Log in
          </Button>
        </form>
      </div>
    );
  }
}

export default withAuth(LoginForm);
