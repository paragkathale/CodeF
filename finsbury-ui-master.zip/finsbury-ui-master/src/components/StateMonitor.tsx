import * as React from 'react';
import classnames from 'classnames';

interface Props {
  showParties?: boolean;
  state: null | 'im' | 'cust' | 'broker' | 'admin'
}

/**
 * Base CSS class.
 * @private
 */
const baseClass = 'state-monitor';

/**
 * Available 'steps'
 * @private
 */
const steps = [
  'im',
  'cust',
  'broker',
  'admin',
];

/**
 * StateMonitor component.
 *
 * @param {Props}
 *
 * @returns {React.ReactElement}
 */
export default ({ showParties = true, state }: Props): React.ReactElement => {
  const step = state ? steps.indexOf(state) + 1 : 0;
  const cls = classnames(baseClass, {
    [`${baseClass}--step-${step}`]: step > 0,
  });

  return (
    <div className={cls}>
      {
        showParties
          ? (
            <>
              <div className={`${baseClass}__shape ${baseClass}__shape--im`} />
              <div className={`${baseClass}__shape ${baseClass}__shape--auditor`} />
              <div className={`${baseClass}__shape ${baseClass}__shape--broker`} />
              <div className={`${baseClass}__shape ${baseClass}__shape--admin`} />
            </>
          )
          : null
      }

      <div className={`${baseClass}__core`} />
    </div>
  );
};
