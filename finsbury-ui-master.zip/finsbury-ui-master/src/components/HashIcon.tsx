import * as React from 'react';

// @ts-ignore no library types
import * as hashicon from 'hashicon';

interface Props {
  hash: string;
  size: number;
}

export default ({ hash, size }: Props) => {
  const containerRef = React.createRef<HTMLDivElement>();

  React.useEffect(() => {
    const container = containerRef.current;

    if (container) {
      const icon = hashicon(hash, { size });
      container.innerHTML = '';
      container.appendChild(icon);
    }
  }, [hash, size]);

  return (
    <div className="hash-icon" ref={containerRef} />
  );
};
