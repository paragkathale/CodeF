import * as React from 'react';

import Icon from './Icon';

interface Props {
  message: string;
}

const baseClass = 'loading';

export default ({ message }: Props) => (
  <div className={baseClass}>
    <Icon name="radio_button_unchecked" />

    <p>{message}</p>
  </div>
);
