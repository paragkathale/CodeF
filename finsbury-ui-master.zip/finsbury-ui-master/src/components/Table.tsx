import * as React from 'react';
import classnames from 'classnames';

import { TableConfig, TableColumnConfig } from '../types';

type ColumnClasses = { [key: string]: string[] };

interface Props {
  data: object[];
  className?: string,
  tableConfig: TableConfig;
  columnClasses?: ColumnClasses;
}

/**
 * Base CSS class
 * @private
 */
const baseClass = 'table';

/**
 * Base column CSS class
 * @private
 */
const baseColumnClass = `${baseClass}__column`;

/**
 * Render the table header.
 *
 * @param {TableColumnConfig[]} columns
 *
 * @returns {React.ReactElement}
 */
const renderTableHeader = (columns: TableColumnConfig[]): React.ReactElement => (
  <div className={`${baseClass}__header`}>
    {columns.map((column) => {
      const cls = classnames(
        `${baseClass}__header-column`,
        baseColumnClass,
        `${baseColumnClass}--${column.propertyName}`,
      );

      return (
        <div
          className={cls}
          key={`${column.displayName}`}
          title={column.displayName}
        >
          {column.displayName}
        </div>
      );
    })}
  </div>
);

/**
 * Render a row.
 *
 * @param {{ [key: string]: any }} row
 * @param {TableColumnConfig[]} columns
 * @param {ColumnClasses} [columnClasses]
 *
 * @returns {React.ReactElement}
 */
const renderRow = (
  row: { [key: string]: any },
  columns: TableColumnConfig[],
  columnClasses?: ColumnClasses,
): React.ReactElement => (
  <div
    className={`${baseClass}__row`}
    key={row.id}
  >
    {columns.map((column) => {
      const extra = columnClasses
        ? columnClasses[column.propertyName]
        : '';
      const cls = classnames(
        `${baseClass}__row-column`,
        baseColumnClass,
        `${baseColumnClass}--${column.propertyName}`,
        extra,
      );
      let value = column.renderer
        ? column.renderer(row[column.propertyName], row as any)
        : row[column.propertyName];
      if (typeof value === 'string' && value.indexOf('Corda_') !== -1) {
        value = value.replace('Corda_', '');
      }

      return (
        <div
          className={cls}
          key={`${column.displayName}-${column.propertyName}`}
          title={`${column.displayName}: ${value}`}
        >
          <span className={`${baseClass}__column-value`}>
            {value}
          </span>
        </div>
      );
    })}
  </div>
);

/**
 * Table component.
 * TODO (brianmcallister) - Make this accept a generic to represent row type.
 *
 * @param {Props} props
 *
 * @returns {React.ReactElement}
 */
const Table = ({
  className,
  columnClasses,
  data,
  tableConfig,
}: Props): React.ReactElement => {
  const { name: tableName, columnConfig } = tableConfig;
  const cls = classnames(baseClass, className, `${tableName}-table`);

  return (
    <div className={cls}>
      {renderTableHeader(columnConfig)}

      <div className={`${baseClass}__row-container`}>
        {data.map(row => renderRow(row, columnConfig, columnClasses))}
      </div>
    </div>
  );
};

export default Table;
