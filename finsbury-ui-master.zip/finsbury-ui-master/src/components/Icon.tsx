import * as React from 'react';

type Props = {
  name: string,
  size?: 's' | 'l' | 'xl',
}

/**
 * Available icon sizes.
 * @private
 */
const sizes = {
  s: 18,
  l: 36,
  xl: 48,
};

/**
 * Icon component.
 *
 * @param {Props}
 *
 * @returns {React.ReactElement}
 */
export default ({ name, size }: Props): React.ReactElement => {
  const style = size
    ? { fontSize: sizes[size] }
    : undefined;

  return (
    <i className="icon material-icons" style={style}>{name}</i>
  );
};
