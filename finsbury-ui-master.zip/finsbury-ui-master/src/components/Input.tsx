import * as React from 'react';
import classNames from 'classnames';

interface Props extends React.InputHTMLAttributes<HTMLInputElement> {
  className?: string;
  id: string;
  type: string;
  value: string;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const baseClass = 'input';

const Input = ({
  className,
  id,
  type,
  value,
  onChange,
  ...rest
}: Props) => (
  <input
    className={classNames(baseClass, className)}
    id={id}
    type={type}
    value={value}
    onChange={onChange}
    {...rest}
  />
);

export default Input;
