import * as React from 'react';
import classnames from 'classnames';

interface Props {
  hostname: string;
  organization: string | null;
}

const orgBannerCls = 'org-banner';

const hostnameClassMap: {[key: string]: string} = {
  localhost: `${orgBannerCls}--a`,
  'dev-fin00-ui00.drumg.io': `${orgBannerCls}--a`,
  'dev-fin00-b-ui00.drumg.io': `${orgBannerCls}--b`,
  'dev-fin00-c-ui00.drumg.io': `${orgBannerCls}--c`,
  'dev-fin00-d-ui00.drumg.io': `${orgBannerCls}--d`,
};

export default ({ hostname, organization }: Props) => (
  <div className={classnames(orgBannerCls, hostnameClassMap[hostname])}>
    {organization}
  </div>
);
