import * as React from 'react';

import { safeFormatDate } from '../utils/formatters';
import NumberFlash from './NumberFlash';

type Metric = {
  label: string,
  value: number,
};

type Props = {
  title: string,
  lastUpdated: Date,
  metrics: Array<Metric>,
}

/**
 * Base CSS class.
 * @private
 */
const baseClass = 'metrics-bar';

/**
 * MetricsBar component.
 *
 * @param {Props}
 *
 * @returns {React.ReactElement}
 */
export default ({ metrics, title, lastUpdated }: Props) => {
  const metricsEls = metrics.map(metric => (
    <div
      key={metric.label}
      className={`${baseClass}__metric`}
    >
      <p className={`${baseClass}__label`}>
        {metric.label}
      </p>

      <div className={`${baseClass}__value`}>
        <NumberFlash number={metric.value} />
      </div>
    </div>
  ));

  return (
    <div className={baseClass}>
      <header className={`${baseClass}__header`}>
        <p className={`${baseClass}__title`}>{title}</p>

        <p className={`${baseClass}__last-updated`}>
          Last Updated:
          <span className={`${baseClass}__date`}>{safeFormatDate(lastUpdated)}</span>
        </p>
      </header>

      <div className={`${baseClass}__metrics`}>
        {metricsEls}
      </div>

      <div className={`${baseClass}__bar-labels`}>
        <div className={`${baseClass}__bar-label ${baseClass}__bar-label--unlinked`}>
          Unlinked
        </div>

        <div className={`${baseClass}__bar-label ${baseClass}__bar-label--linked`}>
          Linked
        </div>
      </div>
    </div>
  );
};
