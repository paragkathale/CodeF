import * as React from 'react';
import classnames from 'classnames';

interface Tab {
  title?: React.ReactNode,
  content: React.ReactNode,
  renderer?: (arg: { focused: boolean }) => React.ReactNode
  id: string,
}

interface Props {
  content: Tab[]
}

interface State {
  currentTab: number,
}

/**
 * Tabs component.
 */
export default class Tabs extends React.Component<Props, State> {
  /**
   * Base CSS class
   * @static
   */
  static baseClass = 'tabs';

  /**
   * Constructor.
   * @constructor
   *
   * @param {Props}
   */
  constructor(props: Props) {
    super(props);

    this.state = {
      currentTab: 0,
    };
  }

  /**
   * Render the tabs.
   *
   * @returns {React.ReactNode}
   */
  renderTabs = (): React.ReactNode => {
    const { baseClass } = Tabs;
    const { content } = this.props;
    const { currentTab } = this.state;

    return content.map((item, index) => {
      const base = `${baseClass}__header-tab`;
      const isCurrent = index === currentTab;
      const cls = classnames(base, {
        [`${base}--current`]: isCurrent,
      });
      const onClick = () => this.setState({ currentTab: index });
      const rendered = item.renderer
        ? item.renderer({ focused: isCurrent })
        : item.title;

      return (
        <div className={cls} onClick={onClick} key={item.id}>
          {rendered}
        </div>
      );
    });
  }

  /**
   * Render.
   *
   * @returns {React.ReactNode}
   */
  render = (): React.ReactNode => {
    const { baseClass } = Tabs;
    const { content } = this.props;
    const { currentTab } = this.state;
    const currentContent = content[currentTab];

    return (
      <div className={baseClass}>
        <header className={`${baseClass}__header`}>
          {this.renderTabs()}
        </header>

        <div>
          {currentContent.content}
        </div>
      </div>
    );
  }
}
