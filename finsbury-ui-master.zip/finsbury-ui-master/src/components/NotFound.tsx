import * as React from 'react';

const baseClass = 'not-found';

const NotFound = () => (
  <div className={`${baseClass}`}>
    <h1 className={`${baseClass}__title`}>
      404
    </h1>
    <h2 className={`${baseClass}__subtext`}>
      Page not found.
    </h2>
  </div>
);

export default NotFound;
