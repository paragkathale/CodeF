import * as React from 'react';
import classnames from 'classnames';

type Props = {
  number: number | string,
};

type State = {
  number: number | string,
  flashing: boolean,
  direction: 'up' | 'down' | null,
};

export default class Flash extends React.Component<Props, State> {
  static baseClass = 'flash';

  static getDerivedStateFromProps(props: Props, state: State) {
    const direction = parseFloat(`${props.number}`.replace(/,/gi, '')) > parseFloat(`${state.number}`.replace(/,/gi, ''))
      ? 'up'
      : 'down';

    return {
      ...state,
      number: props.number,
      flashing: state.direction != null && props.number !== state.number,
      direction,
    };
  }

  constructor(props: Props) {
    super(props);

    this.state = {
      number: props.number,
      flashing: false,
      direction: null,
    };
  }

  componentDidUpdate(_prevProps: Props, prevState: State) {
    clearTimeout(this.timeout);

    this.timeout = window.setTimeout(() => {
      const { number } = this.state;

      if (prevState.number !== number) {
        this.setState({ flashing: false });
      }
    }, 250);
  }

  componentWillUnmount() {
    if (this.timeout) {
      clearTimeout(this.timeout);
    }
  }

  timeout: number | undefined;

  render() {
    const { number, flashing, direction } = this.state;
    const cls = classnames(Flash.baseClass, {
      [`${Flash.baseClass}--flashing`]: flashing,
      [`${Flash.baseClass}--flashing-${direction}`]: flashing && direction,
    });

    return (
      <div className={cls}>
        {number}
      </div>
    );
  }
}
