import * as React from 'react';

import convertBlankFields from '../utils/convertBlankFields';
import { TradeDetails } from '../types';
import {
  // affirmationConfig,
  matchSubTableConfig,
  matchTableConfig,
  settlementConfig,
  tableConfig,
} from '../config/tableConfig';
import Button from './Button';
import DebugPane from './DebugPane';
import formatTradeDetails from '../utils/formatTradeDetails';
import Table from './Table';
import Icon from './Icon';
import AuditLogContainer from './AuditLogContainer';

interface Props {
  custData?: TradeDetails
  dgId: string,
  imData: TradeDetails
  status: string
}

interface State {
  auditExpanded: boolean,
  debug: boolean,
  expanded: boolean,
}

/**
 * TradeListItem component.
 */
export default class TradeListItem extends React.Component<Props, State> {
  /**
   * Base CSS class
   * @static
   */
  static baseClass = 'trade-list-item';

  // Details height when expanded.
  DETAILS_HEIGHT = 350;

  // Height when a trade is expanded and has exceptions.
  WITH_EXCEPTIONS_HEIGHT = 394;

  // Height when audit log is expanded.
  AUDIT_HEIGHT = 600;

  // Height when audit log is expanded and there are exceptions.
  AUDIT_WITH_EXCEPTIONS_HEIGHT = 644;

  /**
   * Constructor
   * @constructor
   *
   * @param {Props}
   */
  constructor(props: Props) {
    super(props);

    this.state = {
      auditExpanded: false,
      debug: false,
      expanded: false,
    };
  }

  /**
   * Find unequal fields in two objects.
   *
   * @param {any} first
   * @param {any} second
   *
   * @returns {string[]}
   */
  private findUnequal = (first: any, second: any): string[] => (
    Object
      .keys(first)
      .filter(key => ['netTradeAmount', 'price', 'quantity'].includes(key))
      .filter((field) => {
        const isPending = first[field] === 'Pending' || second[field] === 'Pending';
        const isEqual = first[field] === second[field];

        return !isPending && !isEqual;
      })
  )

  private toggleExpand = () => {
    const { expanded } = this.state;
    this.setState({
      auditExpanded: false,
      expanded: !expanded,
    });
  }

  private toggleAuditExpand = () => {
    const { auditExpanded } = this.state;
    this.setState({ auditExpanded: !auditExpanded });
  }

  /**
   * Render.
   *
   * @returns {React.ReactNode}
   */
  render(): React.ReactNode {
    const { baseClass } = TradeListItem;
    const {
      custData,
      dgId,
      imData,
      status,
    } = this.props;
    const { auditExpanded, expanded, debug } = this.state;
    const transactionId = imData.transaction.identifiers.TransID;
    const formattedImData = convertBlankFields(formatTradeDetails(imData));
    const formattedCustData = convertBlankFields(formatTradeDetails(custData));
    const breaks = this.findUnequal(formattedImData, formattedCustData);
    const columnClasses = breaks.reduce((acc, next) => (
      { ...acc, [next]: `${baseClass}__column--broken` }
    ), {});
    const buttonText = expanded ? 'Close Details' : 'Open Details';

    let style;
    if (auditExpanded) {
      style = breaks.length
        ? { height: this.AUDIT_WITH_EXCEPTIONS_HEIGHT }
        : { height: this.AUDIT_HEIGHT };
    } else {
      style = expanded
        ? { height: (breaks.length ? this.WITH_EXCEPTIONS_HEIGHT : this.DETAILS_HEIGHT) }
        : { height: 0 };
    }

    // Data for the match analysis table.
    const matchAnalysisData = [
      { ...formattedImData, id: 'im' },
      { ...formattedCustData, id: 'cust' },
    ];

    // If there are breaks, calculate the differences between breaks, and add
    // that data as an extra row into the match analysis table.
    if (breaks.length) {
      const result = breaks.reduce((acc, next) => {
        const val = formattedImData[next] - formattedCustData[next];
        const formatted = Number.isNaN(val) ? 'Break' : val;

        return { ...acc, [next]: formatted };
      }, {});

      matchAnalysisData.push({ ...result, id: 'results' });
    }

    return (
      <div className={baseClass}>
        <button type="button" className={`${baseClass}__debug-button`} onClick={() => this.setState({ debug: !debug })}>
          <Icon name="comment" size="s" />
        </button>

        <DebugPane
          dgId={dgId}
          imData={JSON.stringify(imData, null, 2)}
          custData={custData ? JSON.stringify(custData, null, 2) : 'No Custodian Data'}
          open={debug}
        />

        <header className={`${baseClass}__header`}>
          <p className={`${baseClass}__title`} title={`Transaction ID: ${transactionId}`}>
            <span>Transaction ID:</span>

            {transactionId}
          </p>

          <Button onClick={this.toggleExpand}>{buttonText}</Button>
        </header>

        <div className={`${baseClass}__main-data`}>
          <Table
            data={[{ ...formattedImData, id: 'one' }]}
            tableConfig={tableConfig}
            columnClasses={columnClasses}
          />
        </div>

        <div className={`${baseClass}__expanded-wrapper`} style={style}>
          {expanded && (
            <>
              <div className={`${baseClass}__expanded-data`}>
                <Table
                  data={[{
                    ...formattedImData,
                    status,
                    imSourceTimestamp: formattedImData.sourceTimestamp,
                    custodySourceTimestamp: formattedCustData.sourceTimestamp,
                    id: 'one',
                  }]}
                  tableConfig={matchTableConfig}
                />

                <hr className="divider" />

                <Table
                  data={matchAnalysisData}
                  tableConfig={matchSubTableConfig}
                  columnClasses={columnClasses}
                />

                <hr className="divider" />

                <Table
                  data={[{ ...formattedCustData, id: 'one' }]}
                  tableConfig={settlementConfig}
                />

              </div>

              <div className={`${baseClass}__audit-log`}>
                <div className={`${baseClass}__audit-log-header`} onClick={this.toggleAuditExpand}>
                  Audit Log
                  <Icon name={auditExpanded ? 'expand_less' : 'expand_more'} />
                </div>

                { auditExpanded && (
                  <div className={`${baseClass}__audit-log-content`}>
                    <AuditLogContainer transactionId={transactionId} />
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    );
  }
}
