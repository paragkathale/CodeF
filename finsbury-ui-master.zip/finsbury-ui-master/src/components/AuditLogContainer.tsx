import * as React from 'react';

import { TradeEvent } from '../types';
import ApiPoller from '../api/apiPoller';
import AuditLog from './AuditLog';
import Loading from './Loading';
import convertBlankFields from '../utils/convertBlankFields';

interface Props {
  transactionId: string;
}

interface State {
  entries: TradeEvent[];
  loading: boolean;
}

const { API_URL } = process.env;

/**
 * AuditLogContainer component.
 */
export default class AuditLogContainer extends React.Component<Props, State> {
  static POLLING_INTERVAL = 5000;

  apiPoller: ApiPoller;

  /**
   * Constructor.
   * @constructor
   *
   * @param {Props}
   */
  constructor(props: Props) {
    super(props);

    const { POLLING_INTERVAL } = AuditLogContainer;
    const { transactionId } = props;
    const tradeEventUrl = `${API_URL}/tradeEvents?transactionId=${transactionId}`;

    this.apiPoller = new ApiPoller(tradeEventUrl, POLLING_INTERVAL);
    this.apiPoller.onData(data => this.setState({ entries: data, loading: false }));

    this.state = {
      entries: [],
      loading: true,
    };
  }

  /**
   * Component did mount.
   */
  componentDidMount = () => {
    this.apiPoller.start();
  }

  componentWillUnmount = () => {
    this.apiPoller.stop();
  }

  /**
   * Render.
   *
   * @returns {React.ReactElement}
   */
  render(): React.ReactElement {
    const { entries, loading } = this.state;
    const processedEntries = entries.map(entry => convertBlankFields(entry));

    return loading
      ? <Loading message="Waiting for audit log…" />
      : <AuditLog entries={processedEntries} />;
  }
}
