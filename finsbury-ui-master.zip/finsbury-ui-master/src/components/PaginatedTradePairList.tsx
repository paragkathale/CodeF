import paginate from '../HOC/paginate';
import TradePairList from './TradePairList';

export default paginate(TradePairList);
