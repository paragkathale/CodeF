import * as React from 'react';
import classnames from 'classnames';
import hljs from 'highlight.js/lib/highlight';
import json from 'highlight.js/lib/languages/json';

import 'highlight.js/styles/github.css';

interface Props {
  dgId: string;
  imData: string;
  custData?: string;
  open: boolean;
}

export default class DebugPane extends React.Component<Props, {}> {
  static baseClass = 'debug-pane';

  debugPane = React.createRef<HTMLDivElement>();

  constructor(props: Props) {
    super(props);

    hljs.registerLanguage('json', json);
  }

  componentDidMount() {
    const { current } = this.debugPane;

    if (current) {
      const imEl = current.querySelector(`.${DebugPane.baseClass}--im`);
      const custEl = current.querySelector(`.${DebugPane.baseClass}--cust`);

      if (imEl) {
        const imCode = imEl.textContent;
        const imHighlighted = hljs.highlightAuto(imCode);

        imEl.innerHTML = imHighlighted.value;
      }

      if (custEl) {
        const custCode = custEl.textContent;
        const custHighlighted = hljs.highlightAuto(custCode);

        custEl.innerHTML = custHighlighted.value;
      }
    }
  }

  render() {
    const {
      dgId,
      imData,
      custData,
      open,
    } = this.props;
    const { baseClass } = DebugPane;
    const debugCls = classnames(`${baseClass}`, {
      [`${baseClass}--hidden`]: !open,
    });

    return (
      <div className={debugCls} ref={this.debugPane}>
        <pre className={`${baseClass}__id`}>
          dgId:&nbsp;
          {dgId}
        </pre>

        <div className={`${baseClass}__wrap`}>
          <pre className={`${baseClass}--im`}>
            {imData}
          </pre>

          {custData && (
            <>
              <hr className="divider" />

              <pre className={`${baseClass}--cust`}>
                {custData}
              </pre>
            </>
          )}
        </div>
      </div>
    );
  }
}
