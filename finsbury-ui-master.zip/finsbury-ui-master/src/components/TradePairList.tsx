import * as React from 'react';
import classnames from 'classnames';

import { ParsedTradePair } from '../types';
import TradeListItem from './TradeListItem';
import Loading from './Loading';

interface Props {
  trades: ParsedTradePair[];
  pendingMessage?: string,
}

/**
 * Base CSS class.
 * @private
 */
const baseClass = 'trade-list';

/**
 * Render trades.
 * @private
 *
 * @param {Trade[]} trades
 *
 * @returns {React.ReactNode}
 */
const renderTrades = (trades: ParsedTradePair[], pendingMessage: string = 'Loading…'): React.ReactNode => {
  if (!trades.length) {
    return <Loading message={pendingMessage} />;
  }

  return trades.map(trade => (
    <TradeListItem
      custData={trade.pair.second.details}
      dgId={trade.dgId}
      imData={trade.pair.first.details}
      key={trade.dgId}
      status={trade.status}
    />
  ));
};

/**
 * TradeList component.
 *
 * @param {Props}
 *
 * @returns {React.ReactElement}
 */
const TradeList = (props: Props): React.ReactElement => {
  const { trades, pendingMessage } = props;
  const cls = classnames(baseClass, {
    [`${baseClass}--loading`]: !trades.length,
  });

  return (
    <div className={cls}>
      {renderTrades(trades, pendingMessage)}
    </div>
  );
};

export default TradeList;
