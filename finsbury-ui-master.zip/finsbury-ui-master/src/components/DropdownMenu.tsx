import * as React from 'react';
import classnames from 'classnames';

interface Option {
  key: string;
  onClick?: (e?: React.MouseEvent<HTMLDivElement, MouseEvent>) => void;
  render: React.ReactNode;
}

interface Props {
  className?: string;
  options: Option[];
  title: string | React.ReactNode;
}

/**
 * Base CSS class.
 * @private
 */
const baseClass = 'dropdown-menu';

/**
 * DropdownMenu component.
 *
 * @param {Props}
 *
 * @returns {React.ReactElement}
 */
export default ({ className, options, title }: Props): React.ReactElement => (
  <div className={classnames(baseClass, className)}>
    <div className={`${baseClass}__title`}>
      {title}
    </div>

    <div className={`${baseClass}__item-container`}>
      {
        options.map(({ key, onClick, render }) => (
          <div
            className={`${baseClass}__item`}
            onClick={onClick}
            key={key}
          >
            {render}
          </div>
        ))
      }
    </div>
  </div>
);
