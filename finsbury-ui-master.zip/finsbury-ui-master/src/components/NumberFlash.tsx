import * as React from 'react';

import Flash from './Flash';

type Props = {
  number: number,
}

const baseClass = 'number-flash';

export default ({ number }: Props) => {
  const formatted = new Intl.NumberFormat('en').format(number);

  return (
    <div className={baseClass}>
      <Flash number={formatted} />
    </div>
  );
};
