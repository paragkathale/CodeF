import * as React from 'react';

import { ParsedTradePair, ParsedTradeRecord } from '../types';
import { safeFormatNumber } from '../utils/formatters';
import PaginatedTradePairList from './PaginatedTradePairList';
import PaginatedTradeRecordList from './PaginatedTradeRecordList';
import Tabs from './Tabs';
import TitleTab from './TitleTab';

interface Props {
  newAndCancelledRecords: {
    new: ParsedTradeRecord[]
    cancelled: ParsedTradeRecord[]
  }
  parsedTradePairs: ParsedTradePair[]
  tradesWithExceptions: ParsedTradePair[],
  settledTrades: ParsedTradePair[]
}

/**
 * Base CSS class.
 * @private
 */
const baseClass = 'app-content';

/**
 * AppContent component.
 *
 * @param {Props}
 *
 * @returns {React.ReactElement}
 */
export default ({
  newAndCancelledRecords,
  parsedTradePairs,
  tradesWithExceptions,
  settledTrades,
}: Props) => {
  const newTradeRecordsList = (
    <PaginatedTradeRecordList
      data={newAndCancelledRecords.new}
      pageSize={10}
      propName="trades"
      type="tradeRecord"
      pendingMessage="Waiting for proposed trade records…"
    />
  );

  const tradePairsList = (
    <PaginatedTradePairList
      data={parsedTradePairs}
      pageSize={10}
      propName="trades"
      type="tradePair"
      pendingMessage="Waiting for trade pairs…"
    />
  );

  const cancelledTradeRecordsList = (
    <PaginatedTradeRecordList
      data={newAndCancelledRecords.cancelled}
      pageSize={10}
      propName="trades"
      type="tradeRecord"
      pendingMessage="Waiting for cancelled trade records…"
    />
  );

  const tradesWithExceptionsList = (
    <PaginatedTradePairList
      data={tradesWithExceptions}
      pageSize={10}
      propName="trades"
      type="tradePair"
      pendingMessage="Waiting for trade pairs with exceptions…"
    />
  );

  const settledTradesList = (
    <PaginatedTradePairList
      data={settledTrades}
      pageSize={10}
      propName="trades"
      type="tradePair"
      pendingMessage="Waiting for settled trade paris…"
    />
  );

  // Calculate counts for each type of list.
  const proposedCount = safeFormatNumber(newAndCancelledRecords.new.length);
  const pairedCount = safeFormatNumber(parsedTradePairs.length);
  const cancelledCount = safeFormatNumber(newAndCancelledRecords.cancelled.length);
  const exceptionsCount = safeFormatNumber(tradesWithExceptions.length);
  const settledCount = safeFormatNumber(settledTrades.length);

  return (
    <div className={baseClass}>
      <Tabs
        content={[
          {
            id: 'unmatched',
            renderer: ({ focused }: { focused: boolean }) => (
              <TitleTab
                text="Proposed"
                focused={focused}
                count={proposedCount}
              />
            ),
            content: newTradeRecordsList,
          },
          {
            id: 'cancelled',
            renderer: ({ focused }: { focused: boolean }) => (
              <TitleTab
                text="Cancelled"
                focused={focused}
                count={cancelledCount}
              />
            ),
            content: cancelledTradeRecordsList,
          },
          {
            id: 'paired',
            renderer: ({ focused }: { focused: boolean }) => (
              <TitleTab
                text="Linked"
                focused={focused}
                count={pairedCount}
              />
            ),
            content: tradePairsList,
          },
          {
            id: 'exceptions',
            renderer: ({ focused }: { focused: boolean }) => (
              <TitleTab
                text="With Exceptions"
                focused={focused}
                count={exceptionsCount}
              />
            ),
            content: tradesWithExceptionsList,
          },
          {
            id: 'settled',
            renderer: ({ focused }: { focused: boolean }) => (
              <TitleTab
                text="Settled"
                focused={focused}
                count={settledCount}
              />
            ),
            content: settledTradesList,
          },
        ]}
      />
    </div>
  );
};
