import * as React from 'react';
import classnames from 'classnames';

import Flash from './Flash';

interface Props {
  text: string
  count: number
  focused: boolean
}

interface State {
  hasUpdate: boolean
}

/**
 * TabTitle component.
 */
export default class TabTitle extends React.Component<Props, State> {
  /**
   * Base CSS class.
   * @static
   */
  static baseClass = 'tab-title';

  // State
  state = {
    hasUpdate: false,
  }

  /**
   * Component did update.
   *
   * @param {Props} nextProps
   */
  componentDidUpdate = (nextProps: Props) => {
    const { count, focused } = this.props;
    const { count: nextCount, focused: nextFocused } = nextProps;

    if (count !== nextCount) {
      this.setState({
        hasUpdate: count !== nextCount && !focused,
      });
    }

    if (focused === true && nextFocused === false) {
      this.setState({
        hasUpdate: false,
      });
    }
  }

  /**
   * Render.
   *
   * @returns {React.ReactNode}
   */
  render = (): React.ReactNode => {
    const { baseClass } = TabTitle;
    const { text, count } = this.props;
    const { hasUpdate } = this.state;
    const cls = classnames(baseClass, {
      [`${baseClass}--has-update`]: hasUpdate,
    });

    return (
      <div className={cls}>
        {text}

        <Flash number={count} key={text} />
      </div>
    );
  }
}
