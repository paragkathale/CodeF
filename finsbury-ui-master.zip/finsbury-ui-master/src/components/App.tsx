import * as React from 'react';

import {
  ParsedTradePair,
  ParsedTradeRecord,
  TradePairState,
  TradeRecordState,
} from '../types';
import ApiWorker from '../api/apiWorker';
import AppContent from './AppContent';
import GlobalHeader from './GlobalHeader';
import MetricsBar from './MetricsBar';
import OrgBanner from './OrgBanner';
import parseTradePair from '../utils/parseTradePair';
import parseTradeRecord from '../utils/parseTradeRecord';
import reducer from '../state/reducer';
import safeGet from '../utils/safeGet';

interface CategorizedTradeRecords {
  [key: string]: ParsedTradeRecord[]
  new: ParsedTradeRecord[]
  cancelled: ParsedTradeRecord[]
}

interface Props {
  apiWebworker: ApiWorker;
}

interface State {
  organization: string | null;
  stickyVisible: boolean,
  tradeRecords: {
    byId: any, // { [key: string]: ParsedTradeRecord },
    ids: Set<string>,
  },
  tradePairs: {
    byId: any, // { [key: string]: ParsedTradePair },
    ids: Set<string>,
  },
  username: string | null;
}

const { ORG_NAME } = process.env;

/**
 * App component.
 */
export default class App extends React.Component<Props, State> {
  /**
   * Base CSS class.
   * @static
   */
  static baseClass = 'app';

  /**
   * Scroll threshold for showing the sticky header.
   * @private
   */
  private SCROLL_THRESHOLD = 280;

  /**
   * Constructor.
   * @constructor
   *
   * @param {Props} props
   */
  constructor(props: any) {
    super(props);

    this.state = {
      organization: null,
      stickyVisible: false,
      tradeRecords: {
        byId: {},
        ids: new Set(),
      },
      tradePairs: {
        byId: {},
        ids: new Set(),
      },
      username: null,
    };
  }

  /**
   * Component did mount.
   */
  componentDidMount() {
    const { apiWebworker } = this.props;

    apiWebworker.onMessage((msg) => {
      const nextState = reducer(this.state, msg);

      this.setState(nextState);
    });

    apiWebworker.send('start');

    // Detect when to show the sticky header.
    document.addEventListener('scroll', this.detectStickyHeader);

    const tokens = this.getOktaTokens();

    if (tokens) {
      const { name } = tokens.idToken.claims;
      this.setState({
        username: name,
        organization: `${ORG_NAME}`,
      });
    }
  }

  /**
   * Component will unmount
   */
  componentWillUnmount() {
    const { apiWebworker } = this.props;

    apiWebworker.send('stop');
    document.removeEventListener('scroll', this.detectStickyHeader);
  }

  /**
   * Detect whether to make header sticky
   * @private
   */
  private detectStickyHeader = () => {
    const { stickyVisible } = this.state;

    if (window.pageYOffset > this.SCROLL_THRESHOLD && !stickyVisible) {
      this.setState({ stickyVisible: true });
    } else if (window.pageYOffset < this.SCROLL_THRESHOLD && stickyVisible) {
      this.setState({ stickyVisible: false });
    }
  }

  /**
   * Check if a tradePair has an exception.
   * @private
   *
   * @param {string[]} path - Path to pass to `get`.
   * @param {ParsedTradePair} src - Source object.
   *
   * @returns {boolean}
   */
  private pairHasException = (path: string[], src: ParsedTradePair): boolean => {
    const firstVal = safeGet(['pair', 'first', 'details', ...path], src);
    const secondVal = safeGet(['pair', 'second', 'details', ...path], src);

    return firstVal != null && secondVal != null && (firstVal !== secondVal);
  };

  /**
   * Parse trade record objects.
   * @private
   *
   * @param {TradeRecordState}
   *
   * @returns {ParsedTradeRecord[]}
   */
  private parseTradeRecords = (records: TradeRecordState): ParsedTradeRecord[] => (
    [...records.ids].map((tradeId) => {
      const trade = records.byId[tradeId];

      return parseTradeRecord(trade);
    })
  )

  /**
   * Parse trade pair objects.
   * @private
   *
   * @param {TradePairState}
   *
   * @returns {ParsedTradePair[]}
   */
  private parseTradePairs = (records: TradePairState): ParsedTradePair[] => (
    [...records.ids].map((id) => {
      const trade = records.byId[id];

      return parseTradePair(trade);
    })
  )

  /**
   * Get the number of trade pairs that have exceptions.
   *
   * @param {ParsedTradePair[]}
   *
   * @returns {ParsedTradePair[]}
   */
  private getTradesWithExceptions = (tradePairs: ParsedTradePair[]): ParsedTradePair[] => (
    tradePairs.reduce((acc, next) => {
      // Check price, quantity, and net trade amount.
      const priceException = this.pairHasException(['details', 'price'], next);
      const quantityException = this.pairHasException(['details', 'quantity'], next);
      const amtException = this.pairHasException(['details', 'netTradeAmount'], next);

      return [priceException, quantityException, amtException].some(el => el === true)
        ? [...acc, next]
        : acc;
    }, [] as ParsedTradePair[])
  )

  /**
   * Get trade records categorized as new or cancelled based on status.
   *
   * @param {ParsedTradeRecord[]}
   *
   * @returns {CategorizedTradePairs}
   */
  private getNewAndCancelled = (tradeRecords: ParsedTradeRecord[]): CategorizedTradeRecords => (
    tradeRecords.reduce<CategorizedTradeRecords>((acc, next) => {
      acc[next.status.toLowerCase()].push(next);

      return acc;
    }, { new: [], cancelled: [] })
  )

  /**
   * Get okta tokens from local storage
   */
  private getOktaTokens = (): any => {
    const tokenString = localStorage.getItem('okta-token-storage');

    if (!tokenString) return null;

    return JSON.parse(tokenString);
  }

  /**
   * Get trade pairs that have settled
   *
   * @param {ParsedTradePair[]}
   *
   * @returns {ParsedTradePair[]}
   */
  private getSettledTradePairs = (parsedTradePairs: ParsedTradePair[]): ParsedTradePair[] => (
    parsedTradePairs.filter((tradePair) => {
      const settlementStatus = safeGet(['pair', 'second', 'details', 'status', 'latest', 'custodianStatus', 'value'], tradePair);
      return settlementStatus && settlementStatus.toLowerCase() === 'settled';
    })
  )

  /**
   * Render.
   *
   * @returns {React.ReactNode}
   */
  render = (): React.ReactNode => {
    const {
      stickyVisible,
      tradeRecords,
      tradePairs,
      organization,
      username,
    } = this.state;
    const { baseClass } = App;
    const { hostname } = window.location;
    const parsedTradeRecords = this.parseTradeRecords(tradeRecords);
    const parsedTradePairs = this.parseTradePairs(tradePairs);
    const records = this.getNewAndCancelled(parsedTradeRecords);
    const tradesWithExceptions = this.getTradesWithExceptions(parsedTradePairs);
    const settledTradePairs = this.getSettledTradePairs(parsedTradePairs);

    const metrics = (
      <MetricsBar
        title="Object Activity"
        lastUpdated={new Date()}
        metrics={[
          { label: 'Proposed', value: records.new.length },
          { label: 'Cancelled', value: records.cancelled.length },
          { label: 'Linked', value: tradePairs.ids.size },
          { label: 'With Exceptions', value: tradesWithExceptions.length },
          { label: 'No Exceptions', value: tradePairs.ids.size - tradesWithExceptions.length },
          { label: 'Settled', value: settledTradePairs.length },
        ]}
      />
    );

    return (
      <div className={baseClass}>
        <OrgBanner hostname={hostname} organization={organization} />

        <GlobalHeader username={username} />

        {stickyVisible && (
          <div className={`${App.baseClass}__sticky-header`}>
            {metrics}
          </div>
        )}

        <div className="container">
          {metrics}
        </div>

        <div className="container">
          <AppContent
            newAndCancelledRecords={records}
            parsedTradePairs={parsedTradePairs}
            tradesWithExceptions={tradesWithExceptions}
            settledTrades={settledTradePairs}
          />
        </div>
      </div>
    );
  }
}
