import * as React from 'react';
import { Redirect } from 'react-router-dom';
import { withAuth } from '@okta/okta-react';
import LoginForm from './LoginForm';

interface Props {
  auth: any;
  baseUrl: string;
}

interface State {
  authenticated: boolean | null;
}

export default withAuth(class Login extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { authenticated: null };
    this.checkAuthentication();
  }

  componentDidUpdate() {
    this.checkAuthentication();
  }

  checkAuthentication() {
    const { auth } = this.props;

    const { authenticated: authenticatedState } = this.state;
    auth.isAuthenticated()
      .then((authenticated: any) => {
        if (authenticated !== authenticatedState) {
          this.setState({ authenticated });
        }
        return authenticated;
      })
      .catch((err: any) => {
        console.log(err);
      });
  }

  render() {
    const { baseUrl } = this.props;
    const { authenticated } = this.state;
    if (authenticated === null) return null;
    return authenticated
      ? <Redirect to={{ pathname: '/' }} />
      : <LoginForm baseUrl={baseUrl} />;
  }
});
