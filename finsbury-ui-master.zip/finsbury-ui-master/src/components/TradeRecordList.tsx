import * as React from 'react';
import classnames from 'classnames';

import { ParsedTradeRecord } from '../types';

import TradeListItem from './TradeListItem';
import Loading from './Loading';

interface Props {
  trades: ParsedTradeRecord[];
  pendingMessage?: string
}

/**
 * Base CSS class.
 * @private
 */
const baseClass = 'trade-list';

/**
 * Render trades.
 * @private
 *
 * @param {ParsedTradeRecord[]} trades
 *
 * @returns {React.ReactNode}
 */
const renderTrades = (trades: ParsedTradeRecord[], pendingMessage: string = 'Loading…'): React.ReactNode => {
  if (!trades.length) {
    return <Loading message={pendingMessage} />;
  }

  return trades.map(trade => (
    <TradeListItem
      dgId={trade.dgId}
      imData={trade.tradeDetails}
      key={trade.dgId}
      status={trade.status}
    />
  ));
};

/**
 * TradeList component.
 *
 * @param {Props}
 *
 * @returns {React.ReactElement}
 */
const TradeList = (props: Props): React.ReactElement => {
  const { trades, pendingMessage } = props;
  const cls = classnames(baseClass, {
    [`${baseClass}--loading`]: !trades.length,
  });

  return (
    <div className={cls}>
      {renderTrades(trades, pendingMessage)}
    </div>
  );
};

export default TradeList;
