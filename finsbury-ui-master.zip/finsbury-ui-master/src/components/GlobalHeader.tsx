import { withAuth } from '@okta/okta-react';
import * as React from 'react';

import DropdownMenu from './DropdownMenu';
import Icon from './Icon';
import logo from '../assets/logo.png';

interface Props {
  auth: any;
  username: string | null;
}

/**
 * Base CSS class.
 */
const baseClass = 'global-header';

/**
 * GlobalHeader component.
 */
const GlobalHeader = ({ auth, username }: Props) => (
  <header className={baseClass}>
    <div className="container">
      <div className={`${baseClass}__brand-wrapper`}>
        <img
          src={logo}
          alt="logo"
          className={`${baseClass}__logo`}
        />

        <p className={`${baseClass}__brand-name`}>The Finsbury Network</p>
      </div>

      <nav className={`${baseClass}__navigation`}>
        <p className={`${baseClass}__navigation-link ${baseClass}__navigation-link--active`}>Home</p>

        {/*
        <p className={`${baseClass}__navigation-link`}>Exceptions</p>

        <p className={`${baseClass}__navigation-link`}>Search</p>

        <p className={`${baseClass}__navigation-link`}>History</p>
        */}
      </nav>

      <div className={`${baseClass}__spacer`} />

      <div className={`${baseClass}__user-menu`}>
        <DropdownMenu
          title={(
            <div className={`${baseClass}__user-menu-title`}>
              <p>
                {username ? `Hi, ${username}` : 'Account' }
              </p>
              <Icon name="expand_more" />
            </div>
          )}
          options={[
            {
              onClick: () => auth.logout('/'),
              render: (
                <>
                  <Icon name="power_settings_new" />
                  Logout
                </>
              ),
              key: 'logout',
            },
          ]}
        />
      </div>
    </div>
  </header>
);

export default withAuth(GlobalHeader);
