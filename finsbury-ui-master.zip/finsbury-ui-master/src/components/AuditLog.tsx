import * as React from 'react';

import {
  TradeEvent,
  TradeRecord,
  TradePair,
} from '../types';
import { safeFormatTimestamp } from '../utils/formatters';
import DebugPane from './DebugPane';
import HashIcon from './HashIcon';
import Icon from './Icon';
import parseTradePair from '../utils/parseTradePair';
import parseTradeRecord from '../utils/parseTradeRecord';
import safeGet from '../utils/safeGet';
import StateMonitor from './StateMonitor';
import Table from './Table';

interface Props {
  entries: TradeEvent[]
}

interface State {
  debug: boolean;
  debugData: any;
  dgId: string;
}

/**
 * AuditLog component.
 */
export default class AuditLog extends React.Component<Props, State> {
  /**
   * Base CSS class
   * @private
   */
  static baseClass = 'audit-log';

  /**
   * Constructor.
   * @constructor
   *
   * @param {Props}
   */
  constructor(props: Props) {
    super(props);

    this.state = {
      debug: false,
      debugData: null,
      dgId: '',
    };
  }

  /**
   * Toggle the debug window.
   *
   * @param {TradeEvent}
   */
  private toggleDebug = (tradeEvent: TradeEvent) => {
    const { data, dataType, dgId } = tradeEvent;
    const { debug } = this.state;

    switch (dataType) {
      case 'tradeRecord': {
        this.setState({
          debug: !debug,
          debugData: parseTradeRecord(data as TradeRecord),
          dgId,
        });
        break;
      }

      case 'tradePair': {
        this.setState({
          debug: !debug,
          debugData: parseTradePair(data as TradePair),
          dgId,
        });
        break;
      }

      default:
        break;
    }
  }

  /**
   * Data button renderer
   *
   * @returns {React.ReactElement}
   */
  private dataButtonRenderer = (_data: string, row: any): React.ReactElement => {
    const { baseClass } = AuditLog;

    return (
      <div
        className={`${baseClass}__debug-button`}
        onClick={() => this.toggleDebug(row as TradeEvent)}
      >
        <Icon name="comment" size="s" />
      </div>
    );
  }

  private hashCodeRenderer = (hash: string): React.ReactElement => {
    const { baseClass } = AuditLog;

    return (
      <div className={`${baseClass}__hash-container`}>
        <HashIcon hash={hash} size={20} />
        {hash}
      </div>
    );
  };

  /**
   * Table config
   * @private
   */
  /* eslint-disable-next-line react/sort-comp */
  private tableConfig = {
    name: 'audit-log',
    columnConfig: [
      { displayName: 'Source', propertyName: 'source' },
      { displayName: 'Timestamp', propertyName: 'eventTime', renderer: safeFormatTimestamp },
      { displayName: 'State', propertyName: 'state' },
      { displayName: 'Status', propertyName: 'custodianStatus' },
      { displayName: 'Additional detail', propertyName: 'custodianNarrative' },
      { displayName: 'Data', propertyName: 'blank', renderer: this.dataButtonRenderer },
      { displayName: 'Hash code', propertyName: 'stateRef', renderer: this.hashCodeRenderer },
    ],
  }

  /**
   * Render the table component.
   *
   * @param {Entries[]}
   *
   * @returns {React.ReactElement<typeof Table>}
   */
  private renderTable = (entries: TradeEvent[]): React.ReactElement<typeof Table> => (
    <Table
      tableConfig={this.tableConfig}
      data={entries.map(entry => ({
        ...entry,
        id: `${entry.dgId}:${entry.eventTime}:${entry.state}`,
        stateRef: safeGet(['data', 'stateRef'], entry),
      }))}
    />
  )

  /**
   * Render.
   *
   * @returns {React.ReactElement}
   */
  render(): React.ReactElement {
    const { baseClass } = AuditLog;
    const { debug, debugData, dgId } = this.state;
    const { entries } = this.props;
    const data = entries.length
      ? this.renderTable(entries)
      : <p className={`${baseClass}__empty`}>No audit log data available</p>;

    return (
      <div className={baseClass}>
        {debug
          ? (
            <DebugPane
              dgId={dgId}
              imData={debugData ? JSON.stringify(debugData, null, 2) : 'No Debug Data'}
              custData=""
              open={debug}
            />
          )
          : null}

        <div className={`${baseClass}__state-monitor`}>
          <StateMonitor
            showParties={false}
            state="cust"
          />
        </div>

        {data}
      </div>
    );
  }
}
