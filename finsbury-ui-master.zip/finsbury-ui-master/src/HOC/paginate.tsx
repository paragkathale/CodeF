import * as React from 'react';

interface Props {
  buffer: number;
  data: any[];
  pageSize: number;
  propName: string;
  type: string,
  pendingMessage: string
}

interface State {
  page: number;
}

const paginate = <P extends object>(PaginatedComponent: React.ComponentType<P>) => (
  class extends React.Component<Props & object, State> {
    containerRef = React.createRef<HTMLDivElement>();

    static defaultProps = {
      buffer: 300,
    }

    constructor(props: Props) {
      super(props);

      this.state = {
        page: 1,
      };
    }

    componentDidMount() {
      window.addEventListener('scroll', this.handlePageScroll);
    }

    componentWillUnmount() {
      window.removeEventListener('scroll', this.handlePageScroll);
    }

    handlePageScroll = () => {
      const { buffer } = this.props;
      const { page } = this.state;
      const containerEl = this.containerRef.current;

      if (containerEl === null) return;

      const containerBottomPos = containerEl.offsetTop + containerEl.offsetHeight;
      const windowBottomPos = window.scrollY + window.innerHeight;

      if (windowBottomPos + buffer >= containerBottomPos) {
        this.setState({
          page: page + 1,
        });
      }
    };

    render() {
      const {
        data,
        pageSize,
        propName,
        ...passThroughProps
      } = this.props;
      const { page } = this.state;

      const paginatedData = data.slice(0, page * pageSize);

      const paginatedDataProp = { [propName]: paginatedData };

      return (
        <div ref={this.containerRef}>
          <PaginatedComponent
            {...paginatedDataProp}
            {...passThroughProps as P}
          />
        </div>
      );
    }
  }
);

export default paginate;
