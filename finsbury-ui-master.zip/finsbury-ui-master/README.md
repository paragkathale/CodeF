# Finsbury UI

This is the repo for the Finsbury UI.

## Getting Started

- Add environment variables to a `.env` file at the root of the project.
- This repo includes a mock API server for development purposes. To use this server run `npm run start:dev` and make sure the `API_URL` environment variable is set to `http://localhost:3000`
- `npm start` to start the development UI server.

## NPM Scripts

These scripts require node and npm to be installed. Use `npm run <script name>` to run a script.

| Name | Description |
|---|---|
| build | Run the build script that creates build for each environment. |
| clean | Delete the build folder. |
| lint | Run javascript and scss linting. |
| lint:js| Lint javascript files. |
| lint:styles | Lint scss files. |
| start | Start the development UI server. |
| start:dev | Start the development API server. |
| storybook | Start storybook for UI development separate from main app. |
| tools:generateMockData | Generate a json file that mocks response from API. |
| types:check | Check typescript types. |

## Environment Variables

| Name | Description |
|---|---|
| API_URL | Base URL for the API. Use `http://localhost:3000` if using development API server. |
| BEARER_TOKEN | Token for API authentication. |
| OKTA_BASE_URL | Base URL for OKTA authentication. See environments table for possible values. |
| OKTA_CLIENT_ID | Client ID for OKTA authentication. See environments table for possible values. |

## Environments

There are a number of servers that host this UI, each server mapped to a different
organization.

You can log into these servers via `ssh` with the user `dga`. Authentication
requires ssh keys, so contact a DrumG engineer to have that configured.

Authentication into the UI itself is handled with Okta, and each server is pointing at a different Okta instance, representing an individual organization.

See a DrumG engineer to get the password to these accounts.

| URL | Organization | Okta Base URL | Okta Client ID | User |
| --- | --- | --- | --- | --- |
| https://dev-fin00-ui00.drumg.io | Investment Manager | https://dev-489565.okta.com | 0oackkp9o4Pddjw33356 | `demo@drumg.com` |
| https://dev-fin00-b-ui00.drumg.io | Custodian | https://dev-489565.okta.com | 0oam7o8xzj3jqd9jr356 | `demo1@drumg.com` |
| https://dev-fin00-c-ui00.drumg.io | Prime Broker | https://dev-489565.okta.com | 0oam7u5x9uFcSQvTw356 | `demo2@drumg.com` |
| https://dev-fin00-d-ui00.drumg.io | Fund Administrator | https://dev-489565.okta.com | 0oam7x3wlNm7Bqd9i356 | `demo3@drumg.com` |

## Okta

Each Okta instance has an application setup to handle authentication from the UI. To access Okta application settings login to Okta with an admin account and click on **Applications** in the nav menu. The client ID, login redirect URLs, and application users can be managed from here. Each Okta instance has at least one demo user associated with it.

In order to give the UI access to Okta APIs, the origins the UI will be served from must be added to the trusted origins. To manage trusted origins go to **API > Trusted Origins**. If the trusted origins are not set properly you will most likely receive CORS errors when attempting to login.

To set the organization names on Okta a custom `org` claim was added to the authorization servers. To change the organization name for an Okta instance go to **API > Authorization Servers** and click on the default server. From here click on claims to see all the claims setup for the default auth server. The `org` claim is a string value that is set to always be included in the id token. On the front-end we pull this value from the token and display it in the banner at the top of the screen. 
