require('dotenv').config();

const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const {
  API_URL,
  BEARER_TOKEN,
  NODE_ENV: env = 'development',
  OKTA_BASE_URL,
  OKTA_CLIENT_ID,
  ORG_NAME,
} = process.env;

module.exports = {
  mode: 'development',
  entry: {
    worker: ['./src/workers/apiWorker.ts'],
    app: [path.resolve('src', 'Index.tsx')],
    vendor: ['react', 'react-dom'],
  },
  devServer: {
    historyApiFallback: true,
  },
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'js/[name].bundle.js',
    publicPath: '/',
  },
  resolve: {
    extensions: ['.js', '.jsx', '.json', '.ts', '.tsx'],
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        loader: 'babel-loader',
        query: {
          cacheDirectory: true,
        },
      },
      {
        enforce: 'pre',
        test: /\.js$/,
        loader: 'source-map-loader',
      },
      {
        test: /\.(png|jpg|gif|svg)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name].[ext]?[hash]',
              outputPath: 'assets',
            },
          },
        ],
      },
      {
        test: /\.s?css$/,
        use: [
          'style-loader',
          'css-loader',
          'sass-loader',
        ],
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, 'src', 'index.html'),
      excludeChunks: ['worker'],
    }),
    new webpack.DefinePlugin({
      'process.env': {
        API_URL: JSON.stringify(API_URL),
        BEARER_TOKEN: JSON.stringify(BEARER_TOKEN),
        NODE_ENV: JSON.stringify(env),
        OKTA_BASE_URL: JSON.stringify(OKTA_BASE_URL),
        OKTA_CLIENT_ID: JSON.stringify(OKTA_CLIENT_ID),
        ORG_NAME: JSON.stringify(ORG_NAME),
      },
    }),
  ],
};
