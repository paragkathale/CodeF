module.exports = {
  env: {
    browser: true
  },
  plugins: [
    'eslint-comments',
    'promise',
    '@typescript-eslint',
  ],
  parser: '@typescript-eslint/parser',
  extends: [
    'airbnb-typescript',
    'plugin:eslint-comments/recommended',
    'plugin:promise/recommended',
  ],
  rules: {
    'indent': ['error', 2, {
      'SwitchCase': 1,
    }],
    'no-unused-vars': 'off',
    '@typescript-eslint/no-unused-vars': ['error', {
      vars: 'all',
      args: 'after-used',
      ignoreRestSiblings: false,
    }],
    'react/sort-comp': 1,
    'jsx-a11y/no-template-curly-in-string': 'off',
    'jsx-a11y/no-noninteractive-element-interactions': 'off',
    'jsx-a11y/no-static-element-interactions': 'off',
    'jsx-a11y/click-events-have-key-events': 'off',
    "jsx-a11y/label-has-associated-control": [ "error", {
      "required": {
        "some": [ "nesting", "id"  ]
      }
    }],
    "jsx-a11y/label-has-for": [ "error", {
      "required": {
        "some": [ "nesting", "id"  ]
      }
    }]
  },
}
