const cors = require('cors');
const crypto = require('crypto');
const express = require('express');

const createTradeRecord = require('./createTradeRecord');
const createTradePair = require('./createTradePair');
const generateTradeEvents = require('./generateTradeEvents');

const app = express();
const {
  PORT = 3000,
} = process.env;

app.use(cors());

// Data.
const tradeRecords = [
  createTradeRecord(),
  createTradeRecord(),
  createTradeRecord(),
  createTradeRecord(),
  createTradeRecord(),
];
const tradePairs = [
  createTradePair(),
  createTradePair(),
  createTradePair(),
  createTradePair(),
  createTradePair(),
];

// Randomly update some fields on random records.
setInterval(() => {
  try {
    const record = tradeRecords[Math.floor(Math.random() * tradeRecords.length - 1)];
    const details = JSON.parse(record.tradeDetails);

    details.investment.identifiers.CUSIP = crypto.randomBytes(64).toString('hex');
    record.tradeDetails = JSON.stringify(details);
  } catch (err) {
    // Didn't modify, because it might have gotten removed in the other interval.
  }

  try {
    const pair = tradePairs[Math.floor(Math.random() * tradePairs.length - 1)];
    const pairDetails = JSON.parse(pair.pair.first.details);

    pairDetails.details.quantity = Math.floor(Math.random() * 3000) + 1;
    pair.pair.first.details = JSON.stringify(pairDetails);
  } catch (err) {
    // Didn't modify, because it might have gotten removed in the other interval.
  }
}, 5000);

// Start a timer that will create a tradeRecord with some random data and push
// it into the list.
setInterval(() => {
  tradeRecords.push(createTradeRecord());
  tradePairs.push(createTradePair());
}, 10000);

setInterval(() => {
  const num = Math.floor(Math.random() * Math.min(5, tradeRecords.length)) + 1;

  tradeRecords.splice(num, 1);
  tradePairs.splice(num, 1);
}, 15000);

app.get('/tradeRecords', (req, res) => {
  res.status(200).json({ tradeRecords });
});

app.get('/tradePairs', (req, res) => {
  res.status(200).json({ tradePairs });
});

app.get('/tradeEvents', (req, res) => {
  const tradeEvents = generateTradeEvents();
  res.status(200).json(tradeEvents);
});

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`---> Listening on port: ${PORT}`);
});
