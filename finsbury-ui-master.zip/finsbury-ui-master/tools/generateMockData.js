/**
 * Generate Mock Data
 */

const uuid = require('uuid/v4');
const fs = require('fs');

const tradeDetailsJson = fs.readFileSync('./data/sample-trade-details.json');
const tradeDetails = JSON.parse(tradeDetailsJson);

const tradeRecordJson = fs.readFileSync('./data/trade-record-schema.json');
const tradeRecordSchema = JSON.parse(tradeRecordJson);

const tradeRecords = tradeDetails.map(tradeDetail => ({
  ...tradeRecordSchema,
  id: uuid(),
  tradeDetails: JSON.stringify(tradeDetail),
}));

const mockApiResponse = {
  tradeRecords,
};

const fileName = `mock-api-response-${Date.now()}.json`;

fs.writeFileSync(`./data/generated/${fileName}`, JSON.stringify(mockApiResponse));
