const uuidv1 = require('uuid/v1');

let count = 1000;

module.exports = () => {
  count += 1;

  return {
    fund: {
      accountNumber: 'P39009',
      manager: 'Corda_IM',
      administrator: null,
    },
    provider: 'Corda_IM',
    role: 'InvestmentManager',
    investmentId: 'ISIN',
    transactionId: `${count}`,
    tradeDetails:
      // eslint-disable-next-line no-useless-escape
      `{\"fund\":{\"manager\":\"AQR\",\"identifiers\":{\"accountNumber\":\"JPM\",\"adminAccount\":\"FUNDABC\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"lotID\":\"491315808\",\"TransID\":\"${count}\"}},\"investment\":{\"type\":\"EQ-COM\",\"identifiers\":{\"ISIN\":\"US10922N1037\",\"SEDOL\":\"BF429K9\",\"CUSIP\":\"BHF\"}},\"details\":{\"type\":\"BUYL\",\"tradeDate\":\"20170807\",\"settleDate\":\"20170807\",\"tradeCurrency\":\"USD\",\"settleCurrency\":\"USD\",\"fees\":{\"SEC\":\"0\",\"other\":\"0\"},\"grossTradeAmount\":\"0\",\"clearingBroker\":{\"code\":\"JPMC\"},\"executingBroker\":{}},\"status\":{}}`,
    broker: 'Corda_CU',
    source: 'file location',
    status: 'NEW',
    dgId: uuidv1(),
  };
};
