const uuidv1 = require('uuid/v1');
const createTradePair = require('./createTradePair');
const createTradeRecord = require('./createTradeRecord');

module.exports = () => ([
  {
    state: 'New',
    custodianStatus: '',
    custodianNarrative: '',
    eventTime: new Date().toISOString(),
    source: 'IM',
    transType: '',
    dgId: uuidv1(),
    dataType: 'tradeRecord',
    data: JSON.stringify(createTradeRecord()),
  },
  {
    state: 'New',
    custodianStatus: 'Affirmed',
    custodianNarrative: 'Control Number: 457632',
    eventTime: new Date().toISOString(),
    source: 'CUSTODIAN',
    transType: '',
    dgId: uuidv1(),
    dataType: 'tradePair',
    data: JSON.stringify(createTradePair()),
  },
  {
    state: 'Paired',
    custodianStatus: 'Affirmed',
    custodianNarrative: 'Control Number: 457632',
    eventTime: new Date().toISOString(),
    source: 'CUSTODIAN',
    transType: '',
    dgId: uuidv1(),
    dataType: 'tradePair',
    data: JSON.stringify(createTradePair()),
  },
  {
    state: 'Paired',
    custodianStatus: 'Settled',
    custodianNarrative: 'Good settle for 20190325.  Control Number: 457632',
    eventTime: new Date().toISOString(),
    source: 'CUSTODIAN',
    transType: '',
    dgId: uuidv1(),
    dataType: 'tradePair',
    data: JSON.stringify(createTradePair()),
  },
]);
