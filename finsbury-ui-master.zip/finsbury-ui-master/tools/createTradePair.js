const uuidv1 = require('uuid/v1');

let count = 1000;

module.exports = () => {
  count += 1;

  return {
    fund: {
      accountNumber: 'P39009',
      manager: 'Corda_IM',
      administrator: null,
    },
    pair: {
      first: {
        details:
          // eslint-disable-next-line no-useless-escape, quotes
          `{\"fund\":{\"manager\":\"AQR\",\"identifiers\":{\"accountNumber\":\"JPM\",\"adminAccount\":\"Fund C\",\"clearingAccountNumber\":\"ABC\",\"locationAccount\":\"USAALK1\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"TransID\":\"4776aa5c-3610-4461-9739-da9ea5683575\",\"fundCode\":\"USAALK1\"}},\"investment\":{\"identifiers\":{\"CUSIP\":\"PACB\",\"AQRID\":\"USAALK1\",\"securityName\":\"Pacific Biosciences of California Ord Shs\"}},\"details\":{\"tradeDate\":\"2018-11-16 12:00 AM\",\"settleDate\":\"2018-11-20 12:00 AM\",\"quantity\":\"37700\",\"price\":\"7.57\",\"commissions\":\"377\",\"fees\":{},\"netTradeAmount\":\"285389\",\"clearingBroker\":{\"code\":\"JPMC\"},\"executingBroker\":{\"code\":\"DB\"}},\"status\":{\"lastUpdate\":\"2018-11-19 16:38:09.427\",\"shortCode\":\"ACCT\"}}`,
        dgId: uuidv1(),
      },
      second: {
        details:
          // eslint-disable-next-line no-useless-escape, quotes
          `{\"fund\":{\"manager\":\"AQR\",\"identifiers\":{\"accountNumber\":\"JPM\",\"adminAccount\":\"Fund C\",\"clearingAccountNumber\":\"ABC\",\"locationAccount\":\"USAALK1\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"TransID\":\"4776aa5c-3610-4461-9739-da9ea5683575\",\"fundCode\":\"USAALK1\"}},\"investment\":{\"identifiers\":{\"CUSIP\":\"PACB\",\"AQRID\":\"USAALK1\",\"securityName\":\"Pacific Biosciences of California Ord Shs\"}},\"details\":{\"tradeDate\":\"2018-11-16 12:00 AM\",\"settleDate\":\"2018-11-20 12:00 AM\",\"quantity\":\"37700\",\"price\":\"7.57\",\"commissions\":\"377\",\"fees\":{},\"netTradeAmount\":\"285389\",\"clearingBroker\":{\"code\":\"JPMC\"},\"executingBroker\":{\"code\":\"DB\"}},\"status\":{\"lastUpdate\":\"2018-11-19 16:38:09.427\",\"shortCode\":\"ACCT\"}}`,
        dgId: uuidv1(),
      },
    },
    broker: 'Corda_CU',
    status: 'PAIRED',
    dgId: uuidv1(),
  };
};
