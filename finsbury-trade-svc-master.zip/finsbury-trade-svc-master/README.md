<p align="center">
  <img src="https://www.drumg.com/wp-content/themes/drumg/dist/img/logo.png" alt="DrumG" width="500">
</p>

# DrumG Trade Service

Trade Service is responsible for routing transaction to the DLT located at ```http://localhost:10050```
# Pre-Requisites

This service contains best-practices and defaults that any DrumG Node service should have. Refer to 
[Service Standards](https://drumg1.atlassian.net/wiki/spaces/ENG/pages/111280183/Service+Standards) for
the comprehensive list of standards, both in code implementation and in documentation.

This service implements:
- README documentation
- CHANGELOG documentation
- Proper files naming convention
- Proper directory structure
- Must-have npm script targets and default commands
- Must-have systemd service file and script
- Default healthcheck end-point
- Default process shutdown handling
- CircleCI configuration
- Use of common DrumG library package, e.g., logger
- Typescript linting
- SonarCloud integration
- Test coverage reporting

# Service Information

| Attribute | Info |
| --------- | ---- |
| Owner | DrumG Engineering Team (Suri) |
| Co-Owner | DrumG Engineering Team (Jimmy Zion) |
| Service Port | 9000 |
| Network Zone | App network ( App ) |

# API Reference

## POST /api/trades
### Sample Post:
```json
{
        "@context": "https://drumg.com/finsbury/v1",
        "fund": {
            "dgid": "12345",
            "identifiers": {
                "adminAccount": "FUNDABC",
                "adminAccountName": "AQR Tax Adv Global RC Eqt Fund LP",
                "brokerAccountName": "JPMBLSA RE: AQR LUX FUNDS II - AQR GLOBAL DEFENSIVE EQUITY",
                "brokerCashAccount": "728139009",
                "primary": "DEFGLUX-JPM-EQ",
                "clearerAccountName": "JPMNY PB DEFGLUX FUND",
                "custodyAccount": "EFV15",
                "accountNumber": "JPM"
            }
        },
        "transaction": {
            "type": "C",
            "brokerAccount": "P 39009",
            "identifiers": {
                "lot": "2145936887",
                "primary": "2145936887",
                "admin": "43603700",
                "adminVersion": "8139590",
                "broker": "T318310EGY7"
            }
        },
        "investment": {
            "type": "EQUITY",
            "identifiers": {
                "ISIN": "US0236081024",
                "Ticker": "AEE",
                "SEDOL": "2050832",
                "CUSIP": "23608102",
                "BBTICKER": "AEE US EQUITY",
                "RIC": "AEE.N",
                "fundCode": "USAZ1V1",
                "fundDescription": "Ameren Ord Shs",
                "adminCode": "29743",
                "adminDescription": "AMEREN CORPORATION",
                "brokerCode": "23608102",
                "brokerDescription": "AMEREN CORP COMMON STOCK USD 0.01"
            }
        },
        "details": {
            "type": "BUY",
            "tradeDate": "20181106",
            "settleDate": "20181108",
            "tradeCurrency": "USD",
            "settleCurrency": "USD",
            "fxRate": "1.0",
            "quantity": "27544",
            "price": "64.86340964",
            "commissions": "35.8072",
            "fees": {
                "SEC": "0.0",
                "other": "0.0"
            },
            "netTradeAmount": "1786633.56",
            "grossTradeAmount": "1786597.76",
            "executingBroker": {
                "identifiers": {
                    "fundCode": "GS",
                    "fundDescription": "Goldman Sachs",
                    "adminCode": "GS",
                    "brokerCode": "4",
                    "brokerDescription": "JP MORGAN"
                }
            },
            "clearingBroker": {
                "identifiers": {
                    "fundCode": "JPM",
                    "brokerCode": "4",
                    "brokerDescription": "JP MORGAN"
                }
            }
        },
        "status": {
            "messages": [{
                "Transaction Status Description": "SETTLED",
                "Additional Information": "AQR CAPITAL MANAGEMENT LLC AVG.PRICE IN ACCORD WITH THE CLIENT'S INSTRUCTIONS % SHS PRIN= 002.02: 2337351609"
            }],
            "lastUpdate": "2018-11-08T10:30:28Z"
        },
        "source": {
            "provider": "AQR",
            "received": "2018-12-31T17:35:00Z",
            "transport": "SFTP",
            "protocol": "CSV",
            "storage": {
                "provider": "Azure",
                "url": "https://aqr.drumg.blob.core.windows.net/finsbury/20181231-DEFGLUX-JPM.csv",
                "hash": "0x268936593782349AB3"
            }
        }
    }
    ```
Returns status 200 "OK" if the service is responsive.

## GET /healthcheck

Returns status 200 "OK" if the service is responsive.

### Example Response body
```json
{
    "status": "ok",
    "msg": "I am alive" 
}
```

# Development Usage

## Install

Obtain an API token from https://packagecloud.io for access to DrumG's private package repo.  Then run:

    export PKGCLOUD_NPM_TOKEN=<token-value>
    npm install @drumg/long-island-tea --save

### Commands

- `npm run build` to download pre-requisites like NPM packages, compile contracts and services files.
- `npm run start` to start service
- `npm run stop` to stop service
- `npm run clean` to clean runtime files and built package
- `npm run test` to execute unit tests
- `npm run check-license` to check dependency licenses