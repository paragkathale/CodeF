import { logger } from '@drumg/long-island-tea';
import bodyParser = require('body-parser');
import cors = require('cors');
import express = require('express');
import http = require('http');
import { HealthcheckController, IngestionController } from './controllers/index';
import { AddressInfo } from 'net';

const app = express();

app.use(cors());
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));

app.use((err: any, _req: any, res: any, next: any) => {
    logger.error(err.message);
    res.status(500).send(err.message);
    next();
});

app.use('/api/trades', IngestionController);
app.use('/healthcheck', HealthcheckController);

export class Server {
    public static instance: http.Server;

    public static start(port: number): void {
        this.instance = app.listen(port, () => {
            logger.info(`http server listening on ${(this.instance.address() as AddressInfo).port}`);
        });
    }
}
