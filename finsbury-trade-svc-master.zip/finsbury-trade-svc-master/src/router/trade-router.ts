import { logger } from '@drumg/long-island-tea';
import axios from 'axios';

const NEW_TRADE = 'NEW';
const AMEND_TRADE = 'AMEND';
const CLASS = '[Router]-';

export class TradeRouter {

    public async routeTrades(submissions: any[]) {
        const [newTrades, amendTradesRecords, amendTradePairs] = this.mapTrades(submissions);
        logger.info(
            `${CLASS} newTrades: ${JSON.stringify(newTrades)}
            amendTradeRecords: ${JSON.stringify(amendTradesRecords)}
            amendTradePairs: ${JSON.stringify(amendTradePairs)}`
        );

        if (newTrades.length > 0) {
            await this.sendTradesToLedger('post', 'tradeRecords', { tradeRecords: newTrades });
            logger.info(`${CLASS} sent ${newTrades.length} new trades`);
        }

        if (amendTradesRecords.length > 0) {
            await this.sendTradesToLedger('put', 'tradeRecords', { tradeRecords: amendTradesRecords });
            logger.info(`${CLASS} sent ${amendTradesRecords.length} amend tradesRecords`);
        }

        if (amendTradePairs.length > 0) {
            await this.sendTradesToLedger('put', 'tradePairs', { tradePairs: amendTradePairs });
            logger.info(`${CLASS} sent ${amendTradePairs.length} amend tradesPairs`);
        }
    }

    public async postCompleteNotification(routedTrades: any[], recipients: Set<string>) {
        const tradeSample: any = this.findSingleTradeRecord(routedTrades);

        if (!tradeSample) {
            logger.info(`${CLASS} no tradeSample found to post notification. Notification not sent`);
            return;
        }

        const data = {
            source: tradeSample.source,
            recipients: [...recipients]
        };
        const dltServiceURL = process.env.DLT_SERVICE_URL + '/notifications/batch-tx-upload-complete';

        logger.info(`${CLASS} source: ${data.source} recipients:
        ${JSON.stringify(data.recipients)} dltSericeURL: ${dltServiceURL}`);

        await axios.post(dltServiceURL, data)
            .catch((err: any) => { logger.error(`${CLASS} error posting completion notification ${err}`); throw err; });
        logger.info(`${CLASS} notification sent successfully`);
    }

    private mapTrades(trades: any[]): any[] {
        const newTrades: any[] = [];
        const amendTradesRecords: any[] = [];
        const amendTradePairs: any[] = [];

        trades.forEach((trade) => {
            switch (trade.routeInfo.type) {
                case NEW_TRADE:
                    newTrades.push(trade.enrichedTrade);
                    break;
                case AMEND_TRADE:
                    const route = trade.routeInfo.route;
                    switch (route) {
                        case 'tradeRecords':
                            amendTradesRecords.push(trade.enrichedTrade);
                            break;
                        case 'tradePairs':
                            amendTradePairs.push(trade.enrichedTrade);
                            break;
                        default:
                            logger.error(`${CLASS} unrecongized ${trade.routeInfo.type} for ${route}
                            with case ${AMEND_TRADE}`);
                    }

            }
        });

        return [newTrades, amendTradesRecords, amendTradePairs];
    }

    private async sendTradesToLedger(restType: string, endpoint: string, data: any) {
        const url: string = `${process.env.DLT_SERVICE_URL}/${endpoint}`;
        // @ts-ignore
        await axios[restType](url, data).catch((err: any) => {
            throw err;
        });
    }

    private findSingleTradeRecord(routedTrades: any[]) {
        for (const trade of routedTrades) {
            if (trade.enrichedTrade.source) {
                return trade.enrichedTrade;
            }
        }

        return null;
    }
}
