import {HttpUtils, logger} from '@drumg/long-island-tea';

const CLASS = '[OxfordService]-';

export default class OxfordService {

    private readonly client: HttpUtils;
    private readonly api = 'api/v1';

    constructor(url: string) {
        this.client = new HttpUtils(url);
    }

    public async getParticipants(accountNumber: string) {
        let response;
        const endpoint = `${this.api}/fund?accountNumber=${encodeURIComponent(accountNumber)}`;

        try {
            response = await this.client.get(endpoint, 'finsbury-trade-svc/getParticipants');
            logger.debug(`[${CLASS}] identity response: ${response}`);

        } catch (error) {
            logger.error(`${CLASS} error querying endpoint ${endpoint}: ${error}`);
            throw error;
        }

        const partArray: any[] = JSON.parse(response);
        if (partArray.length <= 0) {
            throw Error(`${CLASS} ${endpoint} return zero participants object`);
        }

        return partArray[0];
    }

    public async getIdentity() {
        let response;
        const endpoint = `${this.api}/me`;
        try {
            response = await this.client.get(endpoint, 'finsbury-trade-svc/getIdentity');
            logger.debug(`[${CLASS}] identity response: ${response}`);
        } catch (error) {
            logger.error(`${CLASS} error querying endpoint ${endpoint}: ${error}`);
            throw error;
        }

        return JSON.parse(response);
    }

    public async getAllParticipants() {
        let response;
        const endpoint = `${this.api}/fund`;
        try {
            response = await this.client.get(endpoint, 'finsbury-trade-svc/getAllParticipants');
            logger.debug(`[${CLASS}] getAllParticipants response: ${response}`);
        } catch (error) {
            logger.error(`${CLASS} error querying endpoint ${endpoint}: ${error}`);
            throw error;
        }

        return JSON.parse(response);
    }
}
