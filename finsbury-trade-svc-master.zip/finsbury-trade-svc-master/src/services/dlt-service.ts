import {logger} from '@drumg/long-island-tea';
import axios from 'axios';

const CLASS = '[DLTService]-';

export default class DLTService {

    public async getTradeData(provider: string): Promise<any[]> {
        const DLT_SVC_URL = process.env.DLT_SERVICE_URL;
        const tradeRecordsURL = `${DLT_SVC_URL}/tradeRecords?provider=${provider}`;
        const tradePairsURL = `${DLT_SVC_URL}/tradePairs`;

        logger.info(`${CLASS} provider: ${provider} tradeRecordsURL: ${tradeRecordsURL}
            tradePairsURL: ${tradePairsURL}`);

        const tradeRecordsRequest = axios.get(tradeRecordsURL);
        const tradePairsRequest = axios.get(tradePairsURL);
        const [dltTradesRecords, dltTradePairs] = await Promise.all([tradeRecordsRequest, tradePairsRequest]);

        return [dltTradesRecords, dltTradePairs];
    }
}
