import { logger } from '@drumg/long-island-tea';
import {DGTrade, Identity, TradePair, TradeRecord, Participants} from '../interfaces';
import get = require('get-value');

const CLASS = '[TradeDataEnricher]- ';

export class TradeDataEnricher {
    private readonly recipients: Set<string>;
    private readonly identity: Identity;
    private readonly ParticipantCache: Map<string, Participants> = new Map();
    private readonly TradeMap: Map<string, any> = new Map();

    constructor(tradeRecods: any, tradePair: any, participants: Participants[], identity: Identity) {
        this.recipients = new Set<string>();
        this.identity = identity;
        this.populateParticipantCache(participants);
        this.populateTradeMap(tradeRecods.data.tradeRecords, tradePair.data.tradePairs);
    }

    public enrich(tradeData: any[]): any[] {
        if (!tradeData) {
            const errorMsg = `${CLASS} tradeData is ${tradeData}`;
            logger.error(errorMsg);
            throw new Error(errorMsg);
        }

        if (tradeData.length === 0) {
            logger.info(`${CLASS} no trades`);
            throw new Error('No trades to be submitted');
        }

        const trades = tradeData.map((trade) => this.enrichTrade(trade));

        logger.info(`${CLASS} ${tradeData.length} trades parsed successfully`);

        return trades;
    }

    public getRecipients(): Set<string> {
        return this.recipients;
    }

    public enrichTrade(trade: DGTrade) {
        const accountNumber: string = get(trade, 'fund.identifiers.accountNumber') as string;

        if (!accountNumber || accountNumber.length <= 0) {
            const errorMsg = `${CLASS} accountNumber is ${accountNumber}`;
            logger.error(errorMsg);
            throw Error(errorMsg);
        }

        const participants = this.ParticipantCache.get(accountNumber);
        const routeInfo = this.getRouteInfo(trade);
        const enrichedTrade = routeInfo.route.route === 'tradeRecords' ?
            this.tradeRecordPayload(trade, participants, routeInfo.existingTrade) :
            this.tradePairPayload(trade, routeInfo.existingTrade);

        this.appendRecipients(participants);

        logger.info(`${CLASS} enrichedTrade: ${JSON.stringify(enrichedTrade)} routeInfo: ${JSON.stringify(routeInfo)}`);

        return { enrichedTrade, routeInfo: routeInfo.route };
    }

    private tradePairPayload(trade: DGTrade, existingTrade: any) {
        this.setTradeDetails(existingTrade, trade);
        if (get(trade, 'transaction.type') === 'C') {
            existingTrade.status = 'CANCELLED';
        }
        return existingTrade;
    }

    private tradeRecordPayload(trade: DGTrade, participants: any, existingTrade: TradeRecord) {
        return {
            fund: {
                accountNumber: trade.fund.identifiers.accountNumber,
                manager: participants.Manager,
                administrator: participants.Administrator
            },
            broker: participants.Broker,
            provider: this.identity.name,
            role: this.identity.role,
            investmentId: 'ISIN',
            transactionId: get(trade, 'transaction.identifiers.TransID'),
            tradeDetails: JSON.stringify(trade),
            source: JSON.stringify(trade.source || 'no source found'),
            status: get(trade, 'transaction.type') === 'N' ? 'NEW' : 'CANCELLED',
            dgId: get(existingTrade, 'dgId')
        };
    }

    private setTradeDetails(tradePair: TradePair, trade: DGTrade) {
        ['first', 'second'].forEach((prop) => {
            const record: any = tradePair.pair[prop];
            if (record.provider === this.identity.name) {
                record.details = JSON.stringify(trade);
            }
        });
    }

    private getRouteInfo(trade: DGTrade) {
        const transID: string = get(trade, 'transaction.identifiers.TransID');
        const tradeRecord: any = this.TradeMap.get(transID);

        if (tradeRecord) {
            return {
                existingTrade: tradeRecord.record,
                route: { type: 'AMEND', route: tradeRecord.type }
            };
        }

        return { route: { type: 'NEW', route: 'tradeRecords' } };
    }

    private appendRecipients(participants: any) {
        ['Broker', 'Manager', 'Administrator'].forEach((name) => {
            this.recipients.add(participants[name]);
        });
    }

    private populateParticipantCache(participants: Participants[]) {
        participants.forEach((participant) => {
            this.ParticipantCache.set(participant.AccountNumber, participant);
        });
    }

    private populateTradeMap(tradeRecords: TradeRecord[], tradePairs: TradePair[]) {
        this.populateTrades(tradeRecords, 'tradeRecords');
        this.populateTrades(tradePairs, 'tradePairs');
    }

    private populateTrades(trades: any[], type: string) {
        trades.forEach((trade: any) => {
            const transactionId: string = get(trade, 'transactionId');
            if (transactionId) {
                this.TradeMap.set(transactionId, { record: trade, type });
            }
        });
    }
}
