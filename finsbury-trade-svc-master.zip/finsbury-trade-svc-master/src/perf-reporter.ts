import {PerformanceMetricLogger, PerformanceMetricStep} from '@drumg/long-island-tea';

export class PerfReporter {
    private readonly source: string;
    private readonly description: string;

    constructor(source: string, description: string) {
        this.source = source;
        this.description = description;
    }

    public enter() {
        PerformanceMetricLogger.log(this.makeEvent(PerformanceMetricStep.Entry));
    }

    public exit() {
        PerformanceMetricLogger.log(this.makeEvent(PerformanceMetricStep.Exit));
    }

    private makeEvent(step: PerformanceMetricStep) {
        return {
            source: this.source,
            step,
            description: this.description
        };
    }
}
