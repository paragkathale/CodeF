import { logger } from '@drumg/long-island-tea';
import { Router } from 'express';
import { TradeDataEnricher } from '../enrichment/trade-data-enricher';
import {Identity, Participants} from '../interfaces';
import {PerfReporter} from '../perf-reporter';
import {TradeRouter} from '../router/trade-router';
import OxfordService from '../services/oxford-service';
import DLTService from '../services/dlt-service';

const CLASS = '[IngestionController]- ';

const router: Router = Router();

router.post('/', async (req, res) => {
    const trades: any[] = req.body;
    const perfLogger = createPerfReporter(trades);

    perfLogger.enter();
    await ingest(req, res);
    perfLogger.exit();
});

async function ingest(req: any, res: any) {
    logger.info(`${CLASS} trades post route hit`);
    try {
        const dictionaryUrl = process.env.DICTIONARY_SVC_URL || 'DICTIONARY_SVC_URL not defined';
        const tradeData: object[] = req.body;
        const oxfordService = new OxfordService(dictionaryUrl);
        const dltService = new DLTService();
        const identity: Identity = await oxfordService.getIdentity();
        const participants: Participants[] = await oxfordService.getAllParticipants();
        const [tradeRecords, tradePairs] = await dltService.getTradeData(identity.name);

        logger.info(`${CLASS}Participants: ${participants} identity: ${identity} and tradeData acquired successfully.`);

        const enricher: TradeDataEnricher = new TradeDataEnricher(tradeRecords, tradePairs, participants, identity);
        const routedTrades: any[] = enricher.enrich(tradeData);

        logger.info(`${CLASS} routedTrades: ${JSON.stringify(routedTrades)}`);

        const tradeRouter = new TradeRouter();
        await tradeRouter.routeTrades(routedTrades);

        logger.info(CLASS + 'all trades posted successfully');

        await tradeRouter.postCompleteNotification(routedTrades, enricher.getRecipients());

        res.sendStatus(200);
        logger.info(CLASS + 'response status returned 200');
    } catch (err) {
        logger.error(CLASS + err);
        res.status(500).send(err.message);
    }
}

function createPerfReporter(trades: any[]) {
    let docName = 'Cannot retrieve the document name';

    if (trades && trades.length > 0 && trades[0] && trades[0].source) {
        docName = trades[0].source.documentName;
    }

    return new PerfReporter(docName, 'inside api/trades');
}

export const IngestionController: Router = router;
