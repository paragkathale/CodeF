export interface Identity {
    name: string;
    role: string;
}

export interface DGTrade {
    fund: any;
    source: string;
}

export interface TradePair {
    provider: string;
    details: string;
    pair: any;
    transactionId: string;
}

export interface TradeRecord {
    dgId: string;
    transactionId: string;
    routeInfo: any;
}

export interface Participants {
    AccountNumber: string;
    Manager: string;
    Administrator: string;
    Broker: string;
}
