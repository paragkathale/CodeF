import DLTService from '../../src/services/dlt-service';
import { TradeRecord, TradePair } from '../../src/interfaces';
import nock = require('nock');
import { expect } from 'chai';

describe('DLT Service Test', () => {
    const dltService = new DLTService();
    const tradeRecords: TradeRecord[] = require('../mocks/trade-records-response');
    const tradePairs: TradePair[] = require('../mocks/trade-pair-response');
    const fundName: string = 'TEST_FUND';

    before(() => {
        nock(process.env.DLT_SERVICE_URL || '')
            .get('/tradeRecords')
            .query({provider: fundName})
            .reply(200, tradeRecords);

        nock(process.env.DLT_SERVICE_URL || '')
            .get('/tradePairs')
            .reply(200, tradePairs);
    });

    context('Test getData', async () => {
        it('should return correct data from DLT Services', async () => {
            const [tradeRecordsDLT, tradePairsDLT] = await dltService.getTradeData(fundName);
            expect(JSON.stringify(tradePairsDLT.data)).to.equal(JSON.stringify(tradePairs));
            expect(JSON.stringify(tradeRecordsDLT.data)).to.equal(JSON.stringify(tradeRecords));
        });
    });

    after(() => {
        nock.cleanAll();
    });
});
