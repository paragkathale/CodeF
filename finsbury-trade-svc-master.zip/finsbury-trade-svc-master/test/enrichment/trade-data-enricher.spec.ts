import get = require('get-value');
import { TradeDataEnricher } from '../../src/enrichment/trade-data-enricher';
import { expect } from 'chai';
import nock from 'nock';
import {Identity} from '../../src/interfaces';
import dotenv = require('dotenv');

dotenv.load({path: __dirname + '/../../.env'});

describe('enrich trade', async () => {
    let enricher: TradeDataEnricher;
    let tradeOutputCU1: any;
    let tradeOutputCU2: any;

    const tradeRecordsResponse = require('../mocks/trade-records-response.json');
    const tradePairsResponse = require('../mocks/trade-pair-response.json');

    const identityResponse: Identity = {
        name: 'Corda_IM',
        role: 'IM'
    };

    const participants = [
        {
            AccountNumber: 'JPM',
            Administrator: 'Corda_FA',
            Broker: 'Corda_CU',
            Manager: 'Corda_IM'
        },
        {
            AccountNumber: 'GSC',
            Administrator: 'Corda_FA',
            Broker: 'Corda_CU2',
            Manager: 'Corda_IM'
        }
    ];

    const cu1ParticipantsResponse = [{
        AccountNumnber: 'JPM',
        Administrator: 'Corda_FA',
        Broker: 'Corda_CU',
        Manager: 'Corda_IM'}];

    const cu2ParticipantsResponse = [{
        AccountNumber: 'JPM',
        Administrator: 'Corda_FA',
        Broker: 'Corda_CU2',
        Manager: 'Corda_IM'
    }];

    const inputs: any[] = require('../mocks/ingested-input.json');

    before(() => {
        nock(process.env.DICTIONARY_SVC_URL || '')
            .get('/api/v1/me')
                .reply(200, identityResponse)
                .persist()
            .get('/api/v1/fund')
                .reply(200, participants)
                .persist();

        enricher = new TradeDataEnricher(tradeRecordsResponse, tradePairsResponse, participants, identityResponse);

        const tradeInputCU1 = inputs[2];
        tradeOutputCU1 = enricher.enrichTrade(tradeInputCU1);

        const tradeInputCU2 = inputs[1];
        tradeOutputCU2 = enricher.enrichTrade(tradeInputCU2);
    });

    it('should map route NEW tradeRecord', async () => {
        expect(tradeOutputCU1.routeInfo.type).to.equal('NEW');
        expect(tradeOutputCU1.routeInfo.route).to.equal('tradeRecords');
    });

    it('should map route AMEND tradeRecords', async () => {
        const tradeAmend: any = inputs.filter((trade: any) => {
            const TransID = get(trade, 'transaction.identifiers.TransID');
            return TransID === 'amendTradeRecords';
        })[0];
        const tradeAmendOuput = enricher.enrichTrade(tradeAmend);

        expect(tradeAmendOuput.routeInfo.type).to.equal('AMEND');
        expect(tradeAmendOuput.routeInfo.route).to.equal('tradeRecords');
    });

    it('should map route AMEND tradePairs', async () => {
        const tradeAmend: any = inputs.filter((trade: any) => {
            const TransID = get(trade, 'transaction.identifiers.TransID');
            return TransID === 'amendTradePairs';
        })[0];
        const tradeAmendOuput = enricher.enrichTrade(tradeAmend);

        expect(tradeAmendOuput.routeInfo.type).to.equal('AMEND');
        expect(tradeAmendOuput.routeInfo.route).to.equal('tradePairs');
    });

    it('source property should not be undefined', () => {
        expect(tradeOutputCU1.enrichedTrade.source).not.to.equal(undefined);
    });

    it('should populate provider and role', async () => {
        expect(tradeOutputCU1.enrichedTrade.provider).to.equal(identityResponse.name);
        expect(tradeOutputCU1.enrichedTrade.role).to.equal(identityResponse.role);
    });

    it('CU1 maps the correct manager, administrator and broker', async () => {
        expect(tradeOutputCU1.enrichedTrade.fund.manager).to.equal(cu1ParticipantsResponse[0].Manager);
        expect(tradeOutputCU1.enrichedTrade.fund.administrator).to.equal(cu1ParticipantsResponse[0].Administrator);
        expect(tradeOutputCU1.enrichedTrade.broker).to.equal(cu1ParticipantsResponse[0].Broker);
    });

    it('CU2 input maps the correct manager, administrator and broker', async () => {
        expect(tradeOutputCU2.enrichedTrade.fund.manager).to.equal(cu2ParticipantsResponse[0].Manager);
        expect(tradeOutputCU2.enrichedTrade.fund.administrator).to.equal(cu2ParticipantsResponse[0].Administrator);
        expect(tradeOutputCU2.enrichedTrade.broker).to.equal(cu2ParticipantsResponse[0].Broker);
    });

});
