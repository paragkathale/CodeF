'use strict';

import chai = require('chai');
import { expect } from 'chai';
import chaiHttp = require('chai-http');
import dotenv = require('dotenv');
import nock from 'nock';

import { Server } from '../src/server';
import INGESTED_PARSED_DATA from './mocks/ingested-input.json';

const EMPTY_INPUT = [{}];

chai.use(chaiHttp);
dotenv.load({path: __dirname + '/../.env'});

describe('TradeRoute Tests', () => {

    beforeEach(async () => {
        Server.start(0);

        const identityResponse = {
            name: 'Corda_IM',
            role: 'IM'
        };

        const dictionaryResponse = [
            {
                AccountNumber: 'JPM',
                Administrator: 'Corda_FA',
                Broker: 'Corda_CU',
                Manager: 'Corda_IM'
            },
            {
                AccountNumber: 'GSC',
                Administrator: 'Corda_FA',
                Broker: 'Corda_CU',
                Manager: 'Corda_IM'
            }
        ];

        const tradeRecordsResponse = require('./mocks/trade-records-response.json').data;
        const tradePairsResponse = require('./mocks/trade-pair-response.json').data;

        nock(process.env.DLT_SERVICE_URL || '')
            .post('/tradeRecords')
                .reply(200)
            .post('/notifications/batch-tx-upload-complete')
                .reply(200)
            .put('/tradeRecords')
                .reply(200)
            .put('/tradePairs')
                .reply(200)
            .get('/tradePairs')
                .reply(200, tradePairsResponse)
            .get('/tradeRecords')
                .query({ provider: dictionaryResponse[0].Manager })
                .reply(200, tradeRecordsResponse)
                .persist();

        nock(process.env.DICTIONARY_SVC_URL || '')
            .get('/api/v1/me')
                .reply(200, identityResponse)
            .persist();

        nock(process.env.DICTIONARY_SVC_URL || '')
            .get('/api/v1/fund' )
                .reply(200, dictionaryResponse)
                .persist();
    });

    it('/api/trades should return 200 Happy Path', (done) => {

        chai.request(Server.instance)
            .post('/api/trades')
            .send(INGESTED_PARSED_DATA)
            .end((_err, res) => {
                expect(res.status).to.equal(200);
                done();
            });
    });

    it('/api/trades empty trades', (done) => {

        chai.request(Server.instance)
            .post('/api/trades')
            .send(EMPTY_INPUT)
            .end((_err, res) => {
                expect(res.status).to.equal(500);
                done();
            });
    });

    it('/api/trades endpoint should return 500 Sad Path. No Data Passed', (done) => {

        chai.request(Server.instance)
            .post('/api/trades')
            .end((_err, res) => {
                expect(res.status).to.equal(500);
                done();
            });
    });

    it('/healthcheck returns status 200', (done) => {
        chai.request(Server.instance)
            .get('/healthcheck')
            .end((_err, res) => {
                expect(res.status).to.equal(200);
                expect(JSON.parse(res.text)).to.deep.equal({ status: 'ok', msg: 'I am alive'});
                done();
            });
    });

    afterEach(() => {
        nock.cleanAll();
    });
});
