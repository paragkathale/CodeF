import { TradeRouter } from '../../src/router/trade-router';
import dotenv = require('dotenv');
import nock = require('nock');

dotenv.load({ path: __dirname + '/../../.env' });

describe('Trade-Router-Class Test', () => {
    const tradeRouter = new TradeRouter();

    context('Test routeTrades', async () => {
        let createNewTradeRequest: nock.Scope;
        let amendTradeRecordRequest: nock.Scope;
        let amendTradePairRequest: nock.Scope;

        before(async () => {
            const submissions = require('../mocks/submission-data');

            createNewTradeRequest = nock(process.env.DLT_SERVICE_URL!)
                .post('/tradeRecords', (body: any) => body.tradeRecords[0].transactionId === 'newTrade')
                .reply(200);

            amendTradeRecordRequest = nock(process.env.DLT_SERVICE_URL!)
                .put('/tradeRecords', (body: any) => body.tradeRecords[0].transactionId === 'tradeRecord')
                .reply(200);

            amendTradePairRequest = nock(process.env.DLT_SERVICE_URL!)
                .put('/tradePairs', (body: any) => body.tradePairs[0].transactionId === 'tradePair')
            .reply(200);

            await tradeRouter.routeTrades(submissions);
        });

        it('should map new trades correctly', async () => {
            createNewTradeRequest.isDone();
        });

        it('should map amend records correctly', async () => {
            amendTradeRecordRequest.isDone();
        });

        it('should map amend pairs correctly', async () => {
            amendTradePairRequest.isDone();
        });

        after(() => {
            nock.cleanAll();
        });
    });

});
