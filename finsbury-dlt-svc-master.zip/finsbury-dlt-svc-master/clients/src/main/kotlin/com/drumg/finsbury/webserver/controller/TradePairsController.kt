package com.drumg.finsbury.webserver.controller

import com.drumg.finsbury.webserver.controller.validation.PaginationValidator
import com.drumg.finsbury.webserver.dto.MessageDTO
import com.drumg.finsbury.webserver.dto.TradePairsDTO
import com.drumg.finsbury.webserver.service.TradePairService
import org.slf4j.LoggerFactory
import org.springframework.http.MediaType.APPLICATION_JSON_VALUE
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/tradePairs")
class TradePairsController(private val tradePairService: TradePairService,
                           private val paginationValidator: PaginationValidator) {

    companion object {
        private val VALID_QUERY_PARAMS = setOf("transactionId", "pageSize", "page", "includeHistory")

        private val logger = LoggerFactory.getLogger(TradePairsController::class.java)
    }

    /**
     * Create one or more trade pairs and share with other participants on the DLT.
     */
    @PostMapping(produces = arrayOf(APPLICATION_JSON_VALUE), consumes = arrayOf(APPLICATION_JSON_VALUE))
    private fun createTradePairs(@RequestBody body: TradePairsDTO): MessageDTO {
        logger.debug("Received ${body.tradePairs} trade pairs.")

        if (body.tradePairs.isEmpty()) {
            return MessageDTO("No flows required.")
        }

        logger.debug("Submitted ${body.tradePairs.size} trade pairs to DLT.")

        tradePairService.pairTrades(body.tradePairs).get()

        return MessageDTO("Flows completed successfully.")
    }

    /**
     * Amend one or more trade pairs and share the changes with other participants on the DLT.
     */
    @PutMapping(produces = arrayOf(APPLICATION_JSON_VALUE), consumes = arrayOf(APPLICATION_JSON_VALUE))
    private fun amendTradePairs(@RequestBody body: TradePairsDTO): MessageDTO {
        logger.debug("Received ${body.tradePairs} trade pair amends.")

        if (body.tradePairs.isEmpty()) {
            return MessageDTO("No flows required.")
        }

        logger.debug("Submitted ${body.tradePairs.size} trade pair amends to DLT.")

        tradePairService.amendPairs(body.tradePairs).get()

        return MessageDTO("Flows completed successfully.")
    }

    /**
     * Returns trade pairs on the DLT.
     */
    @GetMapping(produces = arrayOf(APPLICATION_JSON_VALUE))
    private fun getTradePairs(
            @RequestParam(required = false, defaultValue = "1") page: Int,
            @RequestParam(required = false, defaultValue = "\${finsbury.api.pagination.pageSize.default}") pageSize: Int,
            @RequestParam(required = false, defaultValue = "false") includeHistory: Boolean,
            @RequestParam params: Map<String, String>
    ): TradePairsDTO {
        when {
            paginationValidator.invalidPage(page) -> throw BadRequestException("Invalid page number")
            paginationValidator.invalidPageSize(pageSize) -> throw BadRequestException("Invalid page size")
            !VALID_QUERY_PARAMS.containsAll(params.keys) -> throw BadRequestException("Invalid query parameters")
        }

        val queryParams = params.minus(setOf("page", "pageSize", "includeHistory"))

        val tradePairs = when {
            queryParams.isNotEmpty() -> tradePairService.getByQueryParams(queryParams, page, pageSize, includeHistory)
            else -> tradePairService.getAll(page, pageSize)
        }

        return TradePairsDTO(tradePairs)
    }
}
