package com.drumg.finsbury.webserver.messaging.messages

class TxNotificationMessage(sourceHash: String) : JsonSerializableMessage("1.0.0", toMessageBody(sourceHash)) {

    companion object {
        private fun toMessageBody(sourceHash: String) = mapOf("sourceHash" to sourceHash)
    }
}
