package com.drumg.finsbury.webserver.util

import com.drumg.finsbury.webserver.dto.TradeRecordsDTO
import com.fasterxml.jackson.databind.ObjectMapper
import org.slf4j.Logger

class PerformanceLogger<T>(private val logger: Logger) {
    companion object {
        private val PREFIX = "PERF-TEST"

    }

    private enum class Step {
        ENTRY, EXIT
    }

    fun entry() = entry(null)

    fun exit() = exit(null)

    fun entry(data: T?) = perfLog(Step.ENTRY, data)

    fun exit(data: T?) = perfLog(Step.EXIT, data)

    private fun perfLog(step: Step, data: T?) {
        val stepStr = step.toString().toLowerCase()

        when {
            data is TradeRecordsDTO && data.tradeRecords.isNotEmpty() -> {
                val documentName = ObjectMapper().readTree(data.tradeRecords.first().source).get("documentName").textValue()
                val transactionCount = data.tradeRecords.size

                logger.info("[$PREFIX] { \"source\": \"$documentName\", \"transactionCount\": $transactionCount, \"step\": \"$stepStr\" }")
            }

            data == null || data is TradeRecordsDTO && data.tradeRecords.isEmpty() ->
                logger.info("[$PREFIX] { \"step\": \"$stepStr\" }")

            else -> throw IllegalArgumentException("Invalid data type")
        }
    }
}