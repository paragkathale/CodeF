package com.drumg.finsbury.webserver.dlt

import com.drumg.finsbury.state.NotificationTypes

interface NotificationDLTClient {
    /**
     * Sends a notification on the DLT to the given set of recipients.
     */
    fun sendNotification(type: NotificationTypes, payload: String, recipients: Set<String>)
}