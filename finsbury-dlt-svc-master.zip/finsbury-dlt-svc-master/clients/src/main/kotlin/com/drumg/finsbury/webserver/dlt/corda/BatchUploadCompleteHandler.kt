package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.state.NotificationSchemaV1
import com.drumg.finsbury.state.NotificationState
import com.drumg.finsbury.state.NotificationTypes
import com.drumg.finsbury.webserver.NodeRPCConnection
import com.drumg.finsbury.webserver.messaging.MessagePublisher
import com.drumg.finsbury.webserver.messaging.MessageTopic
import com.drumg.finsbury.webserver.messaging.messages.TxNotificationMessage
import net.corda.core.messaging.vaultTrackBy
import net.corda.core.node.services.vault.*
import org.slf4j.LoggerFactory
import org.springframework.boot.context.event.ApplicationReadyEvent
import org.springframework.context.ApplicationListener
import org.springframework.stereotype.Component

@Component
class BatchUploadCompleteHandler(rpc: NodeRPCConnection,
                                 private val messagePublisher: MessagePublisher) : ApplicationListener<ApplicationReadyEvent> {

    companion object {
        private val logger = LoggerFactory.getLogger(BatchUploadCompleteHandler::class.java)
    }

    private val proxy = rpc.proxy

    private fun subscribe() {
        val expression = builder {
            NotificationSchemaV1.PersistentNotification::type.equal(NotificationTypes.BATCH_TX_UPLOAD_COMPLETE.toString())
        }

        val criteria = QueryCriteria.VaultCustomQueryCriteria(expression)

        val pageSpecification = PageSpecification(pageNumber = DEFAULT_PAGE_NUM, pageSize = MAX_PAGE_SIZE)

        val dataFeed = proxy.vaultTrackBy<NotificationState>(criteria, pageSpecification)

        dataFeed.updates.forEach { vaultUpdate ->
            try {
                vaultUpdate.produced.forEach { stateAndRef ->
                    val notification = stateAndRef.state.data
                    val message = TxNotificationMessage(notification.data)
                    messagePublisher.send(MessageTopic.BATCH_TX_UPLOAD_COMPLETE, message)
                }
            } catch (err: Exception) {
                logger.error("Error handling vaultUpdate ${err.message}", err)
            }
        }

        logger.info("Subscribed to ${NotificationTypes.BATCH_TX_UPLOAD_COMPLETE} notifications")
    }

    override fun onApplicationEvent(event: ApplicationReadyEvent) {
        this.subscribe()
    }

}
