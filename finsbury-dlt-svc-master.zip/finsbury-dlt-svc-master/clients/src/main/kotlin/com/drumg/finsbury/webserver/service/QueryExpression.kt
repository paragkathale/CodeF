package com.drumg.finsbury.webserver.service

import java.util.*

class QueryExpression : Iterable<QueryExpression.ExpressionGroup> {
    enum class Operator {
        AND,
        EQUALS
    }

    class ExpressionGroup(val operator: Operator) : Iterable<Expression<*>> {
        private val expressions: MutableList<Expression<*>> = LinkedList()

        override fun iterator(): Iterator<Expression<*>> = expressions.iterator()

        fun <T> add(left: T, operator: Operator, right: T) = expressions.add(Expression(left, operator, right))
    }

    class Expression<T> (val left: T, val operator: Operator, val right: T)

    private val groups: MutableList<ExpressionGroup> = LinkedList()

    private fun createGroup(operator: Operator): ExpressionGroup {
        val group = ExpressionGroup(operator)
        groups.add(group)
        return group
    }

    override fun iterator(): Iterator<ExpressionGroup> = groups.iterator()

    fun and(): ExpressionGroup = createGroup(Operator.AND)
}

