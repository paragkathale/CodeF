package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.flow.AmendTradePairFlow
import com.drumg.finsbury.flow.CancelTradePairFlow
import com.drumg.finsbury.flow.CreateTradePairFlow
import com.drumg.finsbury.state.TradePairSchemaV1
import com.drumg.finsbury.state.TradePairState
import com.drumg.finsbury.webserver.NodeRPCConnection
import com.drumg.finsbury.webserver.dlt.TradePairDLTClient
import com.drumg.finsbury.webserver.dto.Trade
import com.drumg.finsbury.webserver.dto.TradePair
import com.drumg.finsbury.webserver.service.QueryExpression
import net.corda.core.contracts.StateAndRef
import net.corda.core.messaging.startTrackedFlow
import net.corda.core.messaging.vaultQueryBy
import net.corda.core.node.services.Vault
import net.corda.core.node.services.vault.PageSpecification
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.builder
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ExecutionException

@Service
class TradePairCordaClient(rpc: NodeRPCConnection,
                           private val tradePairMapper: TradePairMapper) : TradePairDLTClient {
    companion object {
        private val logger = LoggerFactory.getLogger(TradePairCordaClient::class.java)
    }

    private val proxy = rpc.proxy

    override fun createPair(tradePair: TradePair): CompletableFuture<Unit> {
        val future = CompletableFuture<Unit>()

        val state = tradePairMapper.dtoToState(tradePair, mapLinearId = false)

        logger.debug("Starting CreateTradePairFlow for pair ${tradePair.pair.toPairString()}")

        val flowProgressHandle = proxy.startTrackedFlow(::CreateTradePairFlow, state)
        flowProgressHandle.progress.forEach { step -> logger.info("CreateTradePairFlow progress for pair ${tradePair.pair.toPairString()}: $step") }
        flowProgressHandle.returnValue.then { returnVal ->
            try {
                logger.info("CreateTradePairFlow returned value for pair ${tradePair.pair.toPairString()}: ${returnVal.get()}")
                future.complete(Unit)
            } catch (e: ExecutionException) {
                logger.error("CreateTradePairFlow execution failed with error", e)
                future.completeExceptionally(e)
            } finally {
                flowProgressHandle.close()
            }
        }

        return future
    }

    override fun amendPair(tradePair: TradePair): CompletableFuture<Unit> {
        val future = CompletableFuture<Unit>()

        val state = tradePairMapper.dtoToState(tradePair, mapLinearId = true)

        logger.debug("Starting AmendTradePairFlow for pair ${tradePair.pair.toPairString()}")

        val flowProgressHandle = proxy.startTrackedFlow(::AmendTradePairFlow, state)
        flowProgressHandle.progress.forEach { step -> logger.info("AmendTradePairFlow progress for pair ${tradePair.pair.toPairString()}: $step") }
        flowProgressHandle.returnValue.then { returnVal ->
            try {
                logger.info("AmendTradePairFlow returned value for pair ${tradePair.pair.toPairString()}: ${returnVal.get()}")
                future.complete(Unit)
            } catch (e: ExecutionException) {
                logger.error("AmendTradePairFlow execution failed with error", e)
                future.completeExceptionally(e)
            } finally {
                flowProgressHandle.close()
            }
        }

        return future
    }

    override fun cancelPair(tradePair: TradePair): CompletableFuture<Unit> {
        val future = CompletableFuture<Unit>()

        val updatedState = tradePairMapper.dtoToState(tradePair, mapLinearId = true)

        logger.debug("Starting CancelTradePairFlow for pair ${tradePair.pair.toPairString()}")

        val queryCriteria = QueryCriteria.LinearStateQueryCriteria(linearId = listOf(updatedState.linearId))
        val inputStateAndRef: StateAndRef<TradePairState>

        try {
            inputStateAndRef = proxy.vaultQueryBy<TradePairState>(queryCriteria).states.single()
        } catch (ex: Exception) {
            when (ex) {
                is IllegalArgumentException, is NoSuchElementException -> {
                    logger.error("Failed to query trade pair, reason: $ex")
                    return CompletableFuture.completedFuture(null)
                }
                else -> throw ex
            }
        }

        val flowProgressHandle = proxy.startTrackedFlow(::CancelTradePairFlow, inputStateAndRef, updatedState.pair)
        flowProgressHandle.progress.forEach { step -> logger.info("CancelTradePairFlow progress for pair ${tradePair.pair.toPairString()}: $step") }
        flowProgressHandle.returnValue.then { returnVal ->
            try {
                logger.info("CancelTradePairFlow returned value for pair ${tradePair.pair.toPairString()}: ${returnVal.get()}")
                future.complete(Unit)
            } catch (e: ExecutionException) {
                logger.error("CancelTradePairFlow execution failed with error", e)
                future.completeExceptionally(e)
            } finally {
                flowProgressHandle.close()
            }
        }

        return future
    }

    override fun getAll(page: Int, pageSize: Int): List<TradePair> {
        val (states, statesMetadata) = proxy.vaultQueryBy<TradePairState>(paging = PageSpecification(page, pageSize))

        return states.mapIndexed { index, state -> tradePairMapper.stateToDto(state, statesMetadata[index]) }
    }

    override fun queryByExpression(queryExpression: QueryExpression, page: Int, pageSize: Int, includeHistory: Boolean): List<TradePair> {
        val criteria = queryExpression.map { group ->
            // TODO: This logic could be moved to a (recursive) parse function that handles nested expression groups.
            (group.map {
                val left = when (it.left) {
                    "transactionId" -> TradePairSchemaV1.PersistentTradeRecord::transactionId
                    else -> throw IllegalArgumentException("Unhandled field in query expression: ${it.left}")
                }

                val pred = when (it.operator) {
                    QueryExpression.Operator.EQUALS -> builder { left.equal(it.right) }
                    else -> throw IllegalArgumentException("Unhandled operator in query expression: ${it.operator}")
                }

                val stateStatus = when (includeHistory) {
                    true -> Vault.StateStatus.ALL
                    else -> Vault.StateStatus.UNCONSUMED
                }

                QueryCriteria.VaultCustomQueryCriteria(pred, status = stateStatus)
            } as List<QueryCriteria>).reduce { accumulator, criteria ->
                when (group.operator) {
                    QueryExpression.Operator.AND -> accumulator.and(criteria)
                    else -> throw IllegalArgumentException("Unhandled operator in expression group: ${group.operator}")
                }
            }
        }.reduce { accumulator, criteria -> accumulator.and(criteria) }

        val pageSpecification = PageSpecification(pageNumber = page, pageSize = pageSize)

        val (states, statesMetadata) = proxy.vaultQueryBy<TradePairState>(criteria, pageSpecification)

        return states.mapIndexed { index, state -> tradePairMapper.stateToDto(state, statesMetadata[index]) }
    }

    private fun Pair<Trade, Trade>.toPairString(): String = "(${this.first.dgId}, ${this.second.dgId})"
}