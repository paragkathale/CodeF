package com.drumg.finsbury.webserver.dlt

import com.drumg.finsbury.webserver.dto.TradeRecord
import com.drumg.finsbury.webserver.service.QueryExpression
import java.util.concurrent.CompletableFuture

interface TradeRecordsDLTClient {
    /**
     * Proposes a trade record to the DLT.
     */
    fun propose(tradeRecord: TradeRecord): CompletableFuture<Unit>

    /**
     * Amends a trade record on the DLT.
     */
    fun amend(tradeRecord: TradeRecord): CompletableFuture<Unit>

    /**
     * Returns all trade records on the DLT
     */
    fun getAll(page: Int, pageSize: Int): List<TradeRecord>

    /**
     * Returns a list of trade records matching the given query expression.
     */
    fun queryByExpression(queryExpression: QueryExpression, page: Int, pageSize: Int, includeHistory: Boolean = false): List<TradeRecord>
}
