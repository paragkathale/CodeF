package com.drumg.finsbury.webserver.messaging.messages

import com.drumg.finsbury.webserver.dto.TradeRecord

class TxUpdateMessage(body: TradeRecord): JsonSerializableMessage("1.1.0", body)

