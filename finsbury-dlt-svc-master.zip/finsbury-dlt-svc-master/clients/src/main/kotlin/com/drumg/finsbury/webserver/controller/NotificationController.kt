package com.drumg.finsbury.webserver.controller

import com.drumg.finsbury.webserver.dto.BatchTxUploadCompleteDTO
import com.drumg.finsbury.webserver.dto.MessageDTO
import com.drumg.finsbury.webserver.service.InvalidRecipientException
import com.drumg.finsbury.webserver.service.NotificationService
import org.slf4j.LoggerFactory
import org.springframework.http.MediaType
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController


@RestController
@RequestMapping("/notifications")
class NotificationController(private val notificationService: NotificationService) {

    companion object {
        private val logger = LoggerFactory.getLogger(NotificationController::class.java)
    }

    @PostMapping(value = "batch-tx-upload-complete", produces = arrayOf(MediaType.APPLICATION_JSON_VALUE), consumes = arrayOf(MediaType.APPLICATION_JSON_VALUE))
    private fun batchTxUploadComplete(@RequestBody body: BatchTxUploadCompleteDTO): MessageDTO {
        logger.info("Batch upload complete for source \"${body.source}\". Notifying other participants...")

        try {
            notificationService.sendBatchTxUploadComplete(body.source, body.recipients)
        } catch (ex: InvalidRecipientException) {
            logger.error("Failed to send batch upload complete notification, reason: $ex")

            throw BadRequestException(ex.message)
        }

        return MessageDTO("Flows started successfully")
    }
}