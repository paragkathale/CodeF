package com.drumg.finsbury.webserver.service

import com.drumg.finsbury.webserver.dlt.TradePairDLTClient
import com.drumg.finsbury.webserver.dto.TradePair
import com.drumg.finsbury.webserver.dto.TradePairStatus
import org.springframework.stereotype.Service
import java.util.concurrent.CompletableFuture

@Service
class TradePairService(private val dltClient: TradePairDLTClient) {
    fun pairTrades(tradePairs: List<TradePair>): CompletableFuture<Void> {
        val futures = tradePairs.map { dltClient.createPair(it) }

        return CompletableFuture.allOf(*futures.toTypedArray()).toCompletableFuture()
    }

    fun amendPairs(tradePairs: List<TradePair>): CompletableFuture<Void> {
        val futures = tradePairs.map {
            when (it.status) {
                TradePairStatus.PAIRED -> dltClient.amendPair(it)
                TradePairStatus.CANCELLED -> dltClient.cancelPair(it)
            }
        }

        return CompletableFuture.allOf(*futures.toTypedArray()).toCompletableFuture()
    }

    fun getAll(page: Int, pageSize: Int): List<TradePair> = dltClient.getAll(page, pageSize)

    fun getByQueryParams(queryParams: Map<String, String>, page: Int, pageSize: Int, includeHistory: Boolean = false): List<TradePair> {
        val expression = QueryExpression()
        val group = expression.and()

        queryParams.forEach { entry -> group.add(entry.key, QueryExpression.Operator.EQUALS, entry.value) }

        return dltClient.queryByExpression(expression, page, pageSize, includeHistory)
    }
}
