package com.drumg.finsbury.webserver.dto

data class BatchTxUploadCompleteDTO(val source: String,
                                    val recipients: Set<String>)
