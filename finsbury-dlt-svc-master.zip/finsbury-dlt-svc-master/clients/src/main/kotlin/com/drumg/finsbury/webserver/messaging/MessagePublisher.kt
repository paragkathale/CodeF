package com.drumg.finsbury.webserver.messaging

import com.drumg.utils.pubsub.factory.impl.AmqpMessageQueueFactory
import com.drumg.utils.pubsub.link.Delivery
import com.drumg.utils.pubsub.link.Publisher
import com.drumg.utils.pubsub.message.BaseMessage
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import javax.annotation.PostConstruct

private const val CONNECTION_STRING = "finsbury.messaging.amqp.connectionString"

@Component
open class MessagePublisher(@Value("\${$CONNECTION_STRING}") private val connectionString: String) {

    private lateinit var topicToPublisherMap: Map<MessageTopic, Publisher>

    companion object {
        private val logger = LoggerFactory.getLogger(MessagePublisher::class.java)
    }

    @PostConstruct
    fun init() {
        val factory = AmqpMessageQueueFactory(connectionString)

        topicToPublisherMap = MessageTopic.values()
                .map { it to factory.createPublisher(it.value) }
                .toMap()
    }

    fun send(topic: MessageTopic, message: BaseMessage): Delivery<*> {
        val publisher = topicToPublisherMap.getValue(topic)
        logger.info("Sending message to ${topic.value}: ${message.body}")
        return publisher.send(message)
    }
}
