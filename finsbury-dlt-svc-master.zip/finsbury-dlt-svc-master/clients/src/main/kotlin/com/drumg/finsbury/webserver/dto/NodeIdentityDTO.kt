package com.drumg.finsbury.webserver.dto

data class NodeIdentityDTO(val me: NodeIdentity)

data class NodePeersDTO(val peers: List<NodeIdentity>)

data class NodeIdentity(val name: String?, val role: String?)
