package com.drumg.finsbury.webserver.dto

import java.time.Instant

data class TradePairsDTO(val tradePairs: List<TradePair> = ArrayList())

data class TradePair(val fund: Fund,
                     val broker: String,
                     val transactionId: String,
                     val pair: Pair<Trade, Trade>,
                     val status: TradePairStatus,
                     val stateRef: String? = null,
                     val dgCreatedTimestamp: Instant? = null,
                     val dgConsumedTimestamp: Instant? = null,
                     val dgId: String? = null) // id ignored for POST

data class Trade(val details: String,
                 val provider: String,
                 val dgId: String)

enum class TradePairStatus {
    PAIRED, CANCELLED
}
