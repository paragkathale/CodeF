package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.flow.RaiseNotificationFlow
import com.drumg.finsbury.flow.ShareNotificationFlow
import com.drumg.finsbury.state.NotificationState
import com.drumg.finsbury.state.NotificationTypes
import com.drumg.finsbury.webserver.NodeRPCConnection
import com.drumg.finsbury.webserver.dlt.NotificationDLTClient
import net.corda.core.messaging.startFlow
import org.springframework.stereotype.Service

@Service
class NotificationCordaClient(rpc: NodeRPCConnection,
                              private val partyLookupService: PartyLookupService) : NotificationDLTClient {

    private val proxy = rpc.proxy

    override fun sendNotification(type: NotificationTypes, payload: String, recipients: Set<String>) {
        val notificationState = NotificationState(type = type, data = payload)
        val nodes = recipients.map { partyLookupService.byOrgName(it) ?: throw IllegalArgumentException("Invalid recipient: $it") }

        proxy.startFlow(::RaiseNotificationFlow, notificationState).returnValue.toCompletableFuture().thenAccept {
            proxy.startFlow(::ShareNotificationFlow, it.tx.outRefsOfType<NotificationState>().single(), nodes)
        }
    }
}