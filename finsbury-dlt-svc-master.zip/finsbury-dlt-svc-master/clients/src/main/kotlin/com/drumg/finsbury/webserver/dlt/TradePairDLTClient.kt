package com.drumg.finsbury.webserver.dlt

import com.drumg.finsbury.webserver.dto.TradePair
import com.drumg.finsbury.webserver.service.QueryExpression
import java.util.concurrent.CompletableFuture

interface TradePairDLTClient {
    /**
     * Creates a trade pairs from two input trades on the DLT.
     */
    fun createPair(tradePair: TradePair): CompletableFuture<Unit>

    /**
     * Amends a trade pair on the DLT.
     */
    fun amendPair(tradePair: TradePair): CompletableFuture<Unit>

    /**
     * Cancels a trade pair and creates two trade records on the DLT.
     */
    fun cancelPair(tradePair: TradePair): CompletableFuture<Unit>

    /**
     * Return all paired trades on the DLT.
     */
    fun getAll(page: Int, pageSize: Int): List<TradePair>

    /**
     * Returns a list of trade pairs matching the given query expression.
     */
    fun queryByExpression(queryExpression: QueryExpression, page: Int, pageSize: Int, includeHistory: Boolean = false): List<TradePair>
}