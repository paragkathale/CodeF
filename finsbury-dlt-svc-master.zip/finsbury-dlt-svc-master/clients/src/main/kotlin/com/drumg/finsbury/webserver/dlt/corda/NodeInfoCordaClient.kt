package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.webserver.NodeRPCConnection
import com.drumg.finsbury.webserver.dlt.NodeInfoDLTClient
import com.drumg.finsbury.webserver.dto.NodeIdentity
import net.corda.core.node.NodeInfo
import org.springframework.stereotype.Service

@Service
class NodeInfoCordaClient(rpc: NodeRPCConnection): NodeInfoDLTClient {
    private val proxy = rpc.proxy
    private val me = proxy.nodeInfo().legalIdentities.first().name

    /** Helpers for filtering the network map cache. */
    private fun isMe(nodeInfo: NodeInfo) = nodeInfo.legalIdentities.first().name == me
    private fun isNetworkMap(nodeInfo : NodeInfo) = nodeInfo.legalIdentities.single().name.organisation == "Network Map Service"

    /**
     * Returns the node's name.
     */
    override fun me(): NodeIdentity {
        return NodeIdentity(me.organisation, me.organisationUnit)
    }

    /**
     * Returns all parties registered with the [NetworkMapService]. These names can be used to look up identities
     * using the [IdentityService].
     */
    override fun getPeers(): List<NodeIdentity> {
        return proxy.networkMapSnapshot()
                .filter { isMe(it).not() && isNetworkMap(it).not() }
                .map {
                    val cordaName = it.legalIdentities.first().name
                    NodeIdentity(cordaName.organisation, cordaName.organisationUnit)
                }
    }
}
