package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.flow.AmendTradeRecordFlow
import com.drumg.finsbury.flow.ProposeTradeRecordFlow
import com.drumg.finsbury.state.TradeRecordSchemaV1
import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.webserver.NodeRPCConnection
import com.drumg.finsbury.webserver.controller.TradeRecordsController
import com.drumg.finsbury.webserver.dlt.TradeRecordsDLTClient
import com.drumg.finsbury.webserver.dto.TradeRecord
import com.drumg.finsbury.webserver.service.QueryExpression
import net.corda.core.messaging.startTrackedFlow
import net.corda.core.messaging.vaultQueryBy
import net.corda.core.node.services.Vault
import net.corda.core.node.services.vault.PageSpecification
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.builder
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ExecutionException

@Service
class TradeRecordsCordaClient(rpc: NodeRPCConnection,
                              private val tradeRecordMapper: TradeRecordMapper) : TradeRecordsDLTClient {
    companion object {
        private val logger = LoggerFactory.getLogger(TradeRecordsController::class.java)
    }

    private val proxy = rpc.proxy

    override fun propose(tradeRecord: TradeRecord): CompletableFuture<Unit> {
        val future = CompletableFuture<Unit>()

        val state = tradeRecordMapper.dtoToState(tradeRecord, mapLinearId = false)

        logger.debug("Starting ProposeTradeRecordFlow for transaction ${tradeRecord.transactionId}.")

        val flowProgressHandle = proxy.startTrackedFlow(::ProposeTradeRecordFlow, state)
        flowProgressHandle.progress.forEach { step -> logger.info("ProposeTradeRecordFlow progress for transaction ${tradeRecord.transactionId}: $step") }
        flowProgressHandle.returnValue.then { returnVal ->
            try {
                logger.info("ProposeTradeRecordFlow returned value for transaction ${tradeRecord.transactionId}: ${returnVal.get()}")
                future.complete(Unit)
            } catch (e: ExecutionException) {
                logger.error("ProposeTradeRecordFlow execution failed with error", e)
                future.completeExceptionally(e)
            } finally {
                flowProgressHandle.close()
            }
        }

        return future
    }

    override fun amend(tradeRecord: TradeRecord): CompletableFuture<Unit> {
        val future = CompletableFuture<Unit>()

        val state = tradeRecordMapper.dtoToState(tradeRecord, mapLinearId = true)

        logger.debug("Starting AmendTradeRecordFlow for transaction ${tradeRecord.transactionId}.")

        val flowProgressHandle = proxy.startTrackedFlow(::AmendTradeRecordFlow, state)
        flowProgressHandle.progress.forEach { step -> logger.info("AmendTradeRecordFlow progress for transaction ${tradeRecord.transactionId}: $step") }
        flowProgressHandle.returnValue.then { returnVal ->
            try {
                logger.info("AmendTradeRecordFlow returned value for transaction ${tradeRecord.transactionId}: ${returnVal.get()}")
                future.complete(Unit)
            } catch (e: ExecutionException) {
                logger.error("AmendTradeRecordFlow execution failed with error", e)
                future.completeExceptionally(e)
            } finally {
                flowProgressHandle.close()
            }
        }

        return future
    }

    override fun queryByExpression(queryExpression: QueryExpression, page: Int, pageSize: Int, includeHistory: Boolean): List<TradeRecord> {
        val criteria = queryExpression.map { group ->
            // TODO: This logic could be moved to a (recursive) parse function that handles nested expression groups.
            (group.map {
                val left = when (it.left) {
                    "provider" -> TradeRecordSchemaV1.PersistentTradeRecord::provider
                    "role" -> TradeRecordSchemaV1.PersistentTradeRecord::role
                    "transactionId" -> TradeRecordSchemaV1.PersistentTradeRecord::transactionId
                    "sourceHash" -> TradeRecordSchemaV1.PersistentTradeRecord::sourceHash
                    else -> throw IllegalArgumentException("Unhandled field in query expression: ${it.left}")
                }

                val pred = when (it.operator) {
                    QueryExpression.Operator.EQUALS -> builder { left.equal(it.right) }
                    else -> throw IllegalArgumentException("Unhandled operator in query expression: ${it.operator}")
                }

                val stateStatus = when (includeHistory) {
                    true -> Vault.StateStatus.ALL
                    else -> Vault.StateStatus.UNCONSUMED
                }

                QueryCriteria.VaultCustomQueryCriteria(pred, status = stateStatus)
            } as List<QueryCriteria>).reduce { accumulator, criteria ->
                when (group.operator) {
                    QueryExpression.Operator.AND -> accumulator.and(criteria)
                    else -> throw IllegalArgumentException("Unhandled operator in expression group: ${group.operator}")
                }
            }
        }.reduce { accumulator, criteria -> accumulator.and(criteria) }

        val pageSpecification = PageSpecification(pageNumber = page, pageSize = pageSize)
        val (states, statesMetadata) = proxy.vaultQueryBy<TradeRecordState>(criteria, pageSpecification)

        return states.mapIndexed { index, state -> tradeRecordMapper.stateToDto(state, statesMetadata[index])  }
    }

    override fun getAll(page: Int, pageSize: Int): List<TradeRecord> {
        val (states, statesMetadata) = proxy.vaultQueryBy<TradeRecordState>(paging = PageSpecification(page, pageSize))

        return states.mapIndexed { index, state -> tradeRecordMapper.stateToDto(state, statesMetadata[index])  }
    }
}