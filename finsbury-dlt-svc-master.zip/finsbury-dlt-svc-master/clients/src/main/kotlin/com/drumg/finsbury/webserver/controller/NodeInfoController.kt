package com.drumg.finsbury.webserver.controller

import com.drumg.finsbury.webserver.dlt.NodeInfoDLTClient
import com.drumg.finsbury.webserver.dto.NodeIdentityDTO
import com.drumg.finsbury.webserver.dto.NodePeersDTO
import org.springframework.http.MediaType
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/")
class NodeInfoController(private val dltClient: NodeInfoDLTClient) {

    /**
     * Returns the node's name.
     */
    @GetMapping(value="/me",  produces = arrayOf(MediaType.APPLICATION_JSON_VALUE))
    fun whoami(): NodeIdentityDTO = NodeIdentityDTO(dltClient.me())

    /**
     * Returns all connected peers in the network.
     */
    @GetMapping(value="/peers",  produces = arrayOf(MediaType.APPLICATION_JSON_VALUE))
    fun getPeers(): NodePeersDTO = NodePeersDTO(dltClient.getPeers())
}