package com.drumg.finsbury.webserver.controller

import com.drumg.finsbury.webserver.controller.validation.PaginationValidator
import com.drumg.finsbury.webserver.dto.MessageDTO
import com.drumg.finsbury.webserver.dto.TradeRecordsDTO
import com.drumg.finsbury.webserver.service.TradeRecordService
import com.drumg.finsbury.webserver.util.PerformanceLogger
import org.slf4j.LoggerFactory
import org.springframework.http.MediaType.APPLICATION_JSON_VALUE
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/tradeRecords")
class TradeRecordsController(private val tradeRecordService: TradeRecordService,
                             private val paginationValidator: PaginationValidator) {

    companion object {
        private val VALID_QUERY_PARAMS = setOf("transactionId", "role", "provider", "sourceHash", "pageSize", "page", "includeHistory")

        private val logger = LoggerFactory.getLogger(TradeRecordsController::class.java)
        private val perfLogger = PerformanceLogger<TradeRecordsDTO>(logger)
    }

    /**
     * Submits one or more trade records to other participants on the DLT.
     */
    @PostMapping(produces = arrayOf(APPLICATION_JSON_VALUE), consumes = arrayOf(APPLICATION_JSON_VALUE))
    private fun submitTradeRecords(@RequestBody body: TradeRecordsDTO): MessageDTO {
        perfLogger.entry(body)

        logger.debug("Received ${body.tradeRecords.size} trade record submissions.")

        if (body.tradeRecords.isEmpty()) {
            return MessageDTO("No flows required.")
        }

        logger.debug("Submitted ${body.tradeRecords.size} trade records to DLT.")

        tradeRecordService.newTrades(body.tradeRecords).get()

        perfLogger.exit(body)

        return MessageDTO("Flows completed successfully.")
    }

    @PutMapping(produces = arrayOf(APPLICATION_JSON_VALUE), consumes = arrayOf(APPLICATION_JSON_VALUE))
    private fun amendTradeRecords(@RequestBody body: TradeRecordsDTO): MessageDTO {
        logger.debug("Received ${body.tradeRecords.size} trade record amendments.")

        if (body.tradeRecords.isEmpty()) {
            return MessageDTO("No flows required.")
        }

        logger.debug("Submitted ${body.tradeRecords.size} trade record amendments to DLT.")

        tradeRecordService.amendTrades(body.tradeRecords).get()

        return MessageDTO("Flows completed successfully.")
    }

    /**
     * Returns trade records on the DLT.
     */
    @GetMapping(produces = arrayOf(APPLICATION_JSON_VALUE))
    private fun getTradeRecords(
            @RequestParam(required = false, defaultValue = "1") page: Int,
            @RequestParam(required = false, defaultValue = "\${finsbury.api.pagination.pageSize.default}") pageSize: Int,
            @RequestParam(required = false, defaultValue = "false") includeHistory: Boolean,
            @RequestParam params: Map<String, String>
    ): TradeRecordsDTO {
        perfLogger.entry()

        when {
            paginationValidator.invalidPage(page) -> throw BadRequestException("Invalid page number")
            paginationValidator.invalidPageSize(pageSize) -> throw BadRequestException("Invalid page size")
            !VALID_QUERY_PARAMS.containsAll(params.keys) -> throw BadRequestException("Invalid query parameters")
        }

        val queryParams = params.minus(setOf("page", "pageSize", "includeHistory"))

        val tradeRecords = when {
            queryParams.isNotEmpty() -> tradeRecordService.getByQueryParams(queryParams, page, pageSize, includeHistory)
            else -> tradeRecordService.getAll(page, pageSize)
        }

        perfLogger.exit()

        return TradeRecordsDTO(tradeRecords)
    }
}
