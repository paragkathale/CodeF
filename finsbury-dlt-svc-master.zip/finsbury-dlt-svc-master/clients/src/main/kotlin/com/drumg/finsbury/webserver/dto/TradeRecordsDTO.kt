package com.drumg.finsbury.webserver.dto

import java.time.Instant

data class TradeRecordsDTO(val tradeRecords: List<TradeRecord> = ArrayList())

data class TradeRecord(val fund: Fund,
                       val provider: String,
                       val role: String,
                       val investmentId: String,
                       val transactionId: String,
                       val tradeDetails: String,
                       val broker: String,
                       val source: String,
                       val status: String,
                       val stateRef: String? = null,
                       val dgCreatedTimestamp: Instant? = null,
                       val dgConsumedTimestamp: Instant? = null,
                       val dgId: String? = null)

data class Fund(val accountNumber: String,
                val manager: String,
                val administrator: String?)
