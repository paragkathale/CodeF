package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.webserver.NodeRPCConnection
import com.drumg.finsbury.webserver.messaging.MessagePublisher
import com.drumg.finsbury.webserver.messaging.MessageTopic
import com.drumg.finsbury.webserver.messaging.messages.TxUpdateMessage
import net.corda.core.messaging.vaultTrackBy
import net.corda.core.node.services.vault.DEFAULT_PAGE_NUM
import net.corda.core.node.services.vault.MAX_PAGE_SIZE
import net.corda.core.node.services.vault.PageSpecification
import org.slf4j.LoggerFactory
import org.springframework.boot.context.event.ApplicationReadyEvent
import org.springframework.context.ApplicationListener
import org.springframework.stereotype.Component

@Component
class TradeRecordStateUpdateHandler(rpc: NodeRPCConnection,
                                    private val messagePublisher: MessagePublisher,
                                    private val tradeRecordMapper: TradeRecordMapper) : ApplicationListener<ApplicationReadyEvent> {

    companion object {
        private val logger = LoggerFactory.getLogger(TradeRecordStateUpdateHandler::class.java)
    }

    private val proxy = rpc.proxy

    private fun subscribe() {
        val pageSpecification = PageSpecification(pageNumber = DEFAULT_PAGE_NUM, pageSize = MAX_PAGE_SIZE)
        val dataFeed = proxy.vaultTrackBy<TradeRecordState>(paging = pageSpecification)

        dataFeed.updates.forEach { vaultUpdate ->
            try {
                vaultUpdate.produced.forEach { stateAndRef ->
                    val tradeRecord = tradeRecordMapper.stateToDto(stateAndRef, null)
                    val message = TxUpdateMessage(tradeRecord)
                    messagePublisher.send(MessageTopic.TX_UPDATE, message)
                }
            } catch (err: Exception) {
                logger.error("Error handling vaultUpdate ${err.message}", err)
            }
        }

        logger.info("Subscribed to trade record updates")
    }

    override fun onApplicationEvent(event: ApplicationReadyEvent) {
        this.subscribe()
    }
}
