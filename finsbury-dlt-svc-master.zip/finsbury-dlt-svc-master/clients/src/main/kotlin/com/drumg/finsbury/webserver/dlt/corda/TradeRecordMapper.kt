package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.state.TradeRecordStatus
import com.drumg.finsbury.webserver.dto.TradeRecord
import net.corda.core.contracts.StateAndRef
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import org.springframework.stereotype.Component

@Component
class TradeRecordMapper(private val partyLookupService: PartyLookupService) {
    fun stateToDto(stateAndRef: StateAndRef<TradeRecordState>, metadata: Vault.StateMetadata?): TradeRecord {
        val state = stateAndRef.state.data
        val ref = stateAndRef.ref

        val fund = state.fund
        val fundDto = com.drumg.finsbury.webserver.dto.Fund(
                fund.accountNumber,
                fund.manager.toName(),
                fund.administrator?.toName()
        )

        return TradeRecord(
                fund = fundDto,
                provider = state.provider,
                role = state.role,
                transactionId = state.transactionId,
                investmentId = state.investmentId,
                tradeDetails = state.tradeDetails,
                broker = state.broker.toName(),
                source = state.source,
                status = state.status.toString(),
                stateRef = "${ref.txhash}[${ref.index}]",
                dgCreatedTimestamp = metadata?.recordedTime,
                dgConsumedTimestamp = metadata?.consumedTime,
                dgId = state.linearId.toString()
        )
    }

    fun dtoToState(tradeRecord: TradeRecord, mapLinearId: Boolean): TradeRecordState {
        val fund = tradeRecord.fund
        val manager = partyLookupService.byOrgName(fund.manager)!!
        val admin = fund.administrator?.let { partyLookupService.byOrgName(it) }
        val broker = partyLookupService.byOrgName(tradeRecord.broker)!!

        val fundState = com.drumg.finsbury.state.Fund(fund.accountNumber, manager, admin)

        return TradeRecordState(
                fund = fundState,
                role = tradeRecord.role,
                provider = tradeRecord.provider,
                transactionId = tradeRecord.transactionId,
                investmentId = tradeRecord.investmentId,
                tradeDetails = tradeRecord.tradeDetails,
                broker = broker,
                source = tradeRecord.source,
                status = TradeRecordStatus.valueOf(tradeRecord.status),
                linearId = if (mapLinearId && tradeRecord.dgId != null) UniqueIdentifier.fromString(tradeRecord.dgId) else UniqueIdentifier()
        )
    }

    private fun Party.toName(): String {
        return this.name.organisation
    }
}