package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.webserver.NodeRPCConnection
import net.corda.core.identity.Party
import org.springframework.stereotype.Service

@Service
class PartyLookupService(rpc: NodeRPCConnection) {
    private val proxy = rpc.proxy

    fun byOrgName(orgName: String): Party? {
        return proxy.networkMapSnapshot()
                .map { it.legalIdentities.first() }
                .find { it.name.organisation == orgName }
    }
}