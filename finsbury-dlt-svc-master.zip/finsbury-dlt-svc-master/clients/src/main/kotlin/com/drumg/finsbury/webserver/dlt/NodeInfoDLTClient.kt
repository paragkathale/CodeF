package com.drumg.finsbury.webserver.dlt

import com.drumg.finsbury.webserver.dto.NodeIdentity

interface NodeInfoDLTClient {
    /**
     * Returns the node's name.
     */
    fun me(): NodeIdentity

    /**
     * Returns all connected peers.
     */
    fun getPeers(): List<NodeIdentity>
}
