package com.drumg.finsbury.webserver.controller.validation

import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

@Component
class PaginationValidator {
    @Value("\${finsbury.api.pagination.pageSize.max}")
    val maxPageSize: Int? = null

    fun invalidPage(page: Int) = page < 1
    fun invalidPageSize(pageSize: Int) = pageSize < 1 || pageSize > maxPageSize!!
}