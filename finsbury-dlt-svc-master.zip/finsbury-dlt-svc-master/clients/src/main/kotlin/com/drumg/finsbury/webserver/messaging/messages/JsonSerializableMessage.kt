package com.drumg.finsbury.webserver.messaging.messages

import com.drumg.utils.pubsub.message.BaseMessage
import com.fasterxml.jackson.databind.ObjectMapper

abstract class JsonSerializableMessage(version: String, data: Any) : BaseMessage(version, toJson(data)) {
    companion object {
        private val objectMapper = ObjectMapper()

        fun toJson(body: Any): String {
            return objectMapper.writeValueAsString(body)
        }
    }
}
