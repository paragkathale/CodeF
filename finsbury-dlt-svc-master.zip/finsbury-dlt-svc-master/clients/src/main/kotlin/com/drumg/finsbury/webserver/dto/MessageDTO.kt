package com.drumg.finsbury.webserver.dto

data class MessageDTO(val message: String)
