package com.drumg.finsbury.webserver.dlt.corda

import com.drumg.finsbury.state.TradePairState
import com.drumg.finsbury.webserver.dto.TradePair
import net.corda.core.contracts.StateAndRef
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import org.springframework.stereotype.Component

@Component
class TradePairMapper(private val partyLookupService: PartyLookupService) {
    fun stateToDto(stateAndRef: StateAndRef<TradePairState>, metadata: Vault.StateMetadata?): TradePair {
        val state = stateAndRef.state.data
        val ref = stateAndRef.ref
        val fund = state.fund

        val fundDto = com.drumg.finsbury.webserver.dto.Fund(fund.accountNumber, fund.manager.toName(), fund.administrator?.toName())

        val pairDto = Pair(
                com.drumg.finsbury.webserver.dto.Trade(
                        details = state.pair.first.details,
                        provider = state.pair.first.provider,
                        dgId = state.pair.first.linearId.toString()
                ),
                com.drumg.finsbury.webserver.dto.Trade(
                        details = state.pair.second.details,
                        provider = state.pair.second.provider,
                        dgId = state.pair.second.linearId.toString()
                )
        )

        return TradePair(
                fund = fundDto,
                broker = state.broker.toName(),
                transactionId = state.transactionId,
                pair = pairDto,
                status = com.drumg.finsbury.webserver.dto.TradePairStatus.valueOf(state.status.toString()),
                stateRef = "${ref.txhash}[${ref.index}]",
                dgCreatedTimestamp = metadata?.recordedTime,
                dgConsumedTimestamp = metadata?.consumedTime,
                dgId = state.linearId.toString()
        )
    }

    fun dtoToState(tradePair: TradePair, mapLinearId: Boolean): TradePairState {
        val fund = tradePair.fund
        val manager = partyLookupService.byOrgName(fund.manager)!!
        val admin = fund.administrator?.let { partyLookupService.byOrgName(it) }
        val broker = partyLookupService.byOrgName(tradePair.broker)!!

        val fundState = com.drumg.finsbury.state.Fund(fund.accountNumber, manager, admin)
        val pair = tradePair.pair
        val pairState = Pair(
                com.drumg.finsbury.state.Trade(
                        details = pair.first.details,
                        provider = pair.first.provider,
                        linearId = UniqueIdentifier.fromString(pair.first.dgId)
                ),
                com.drumg.finsbury.state.Trade(
                        details = pair.second.details,
                        provider = pair.second.provider,
                        linearId = UniqueIdentifier.fromString(pair.second.dgId)
                )
        )

        return TradePairState(
                fund = fundState,
                broker = broker,
                transactionId = tradePair.transactionId,
                pair = pairState,
                status = com.drumg.finsbury.state.TradePairStatus.valueOf(tradePair.status.toString()),
                linearId = if (mapLinearId && tradePair.dgId != null) UniqueIdentifier.fromString(tradePair.dgId) else UniqueIdentifier()
        )
    }

    private fun Party.toName(): String {
        return this.name.organisation
    }
}


