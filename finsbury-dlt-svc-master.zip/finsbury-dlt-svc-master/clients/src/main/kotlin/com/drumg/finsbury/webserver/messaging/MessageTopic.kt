package com.drumg.finsbury.webserver.messaging

enum class MessageTopic(val value: String) {
    BATCH_TX_UPLOAD_COMPLETE("batch-tx-upload-complete"),   // Consumed by FileIO service
    TX_UPDATE("tx-update")                                  // Consumed by Matching service
}
