package com.drumg.finsbury.webserver.service

import com.drumg.finsbury.webserver.dlt.TradeRecordsDLTClient
import com.drumg.finsbury.webserver.dto.TradeRecord
import org.springframework.stereotype.Service
import java.util.concurrent.CompletableFuture

@Service
class TradeRecordService(private val dltClient: TradeRecordsDLTClient) {
    fun newTrades(tradeRecords: List<TradeRecord>): CompletableFuture<Void> {
        val futures = tradeRecords.map { dltClient.propose(it) }

        return CompletableFuture.allOf(*futures.toTypedArray()).toCompletableFuture()
    }

    fun amendTrades(tradeRecords: List<TradeRecord>): CompletableFuture<Void> {
        val futures = tradeRecords.map { dltClient.amend(it) }

        return CompletableFuture.allOf(*futures.toTypedArray()).toCompletableFuture()
    }

    fun getAll(page: Int, pageSize: Int): List<TradeRecord> = dltClient.getAll(page, pageSize)

    fun getByQueryParams(queryParams: Map<String, String>, page: Int, pageSize: Int, includeHistory: Boolean = false): List<TradeRecord> {
        val expression = QueryExpression()
        val group = expression.and()

        queryParams.forEach { entry -> group.add(entry.key, QueryExpression.Operator.EQUALS, entry.value) }

        return dltClient.queryByExpression(expression, page, pageSize, includeHistory)
    }
}

