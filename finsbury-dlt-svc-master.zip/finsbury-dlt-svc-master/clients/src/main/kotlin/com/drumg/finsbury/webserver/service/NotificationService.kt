package com.drumg.finsbury.webserver.service

import com.drumg.finsbury.state.NotificationTypes
import com.drumg.finsbury.utils.sha256
import com.drumg.finsbury.webserver.dlt.NotificationDLTClient
import org.springframework.stereotype.Service
import java.lang.IllegalArgumentException

@Service
class NotificationService(private val dltClient: NotificationDLTClient) {
    fun sendBatchTxUploadComplete(source: String, recipients: Set<String>) {
        val sourceHash = sha256(source)

        try {
            dltClient.sendNotification(NotificationTypes.BATCH_TX_UPLOAD_COMPLETE, sourceHash, recipients)
        } catch (ex: IllegalArgumentException) {
            throw InvalidRecipientException(ex.message)
        }
    }
}

class InvalidRecipientException(message: String?) : Exception(message)
