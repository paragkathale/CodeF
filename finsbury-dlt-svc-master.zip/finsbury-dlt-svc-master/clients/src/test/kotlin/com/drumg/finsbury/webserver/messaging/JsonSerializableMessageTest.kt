package com.drumg.finsbury.webserver.messaging

import com.drumg.finsbury.webserver.messaging.messages.JsonSerializableMessage
import org.junit.Test
import kotlin.test.assertEquals

class JsonSerializableMessageTest {

    class TestMessage(body: Any) : JsonSerializableMessage("1.0.0", body)

    class DummyClass(val prop1: String, val prop2: String)

    @Test
    fun `body property should be JSON string value of the data`() {
        val message = TestMessage(mapOf("key1" to "val1", "key2" to "val2"))
        assertEquals("{\"key1\":\"val1\",\"key2\":\"val2\"}", message.body)
    }

    @Test
    fun `body property should be JSON string value of an object`() {
        val message = TestMessage(DummyClass("val1", "val2"))
        assertEquals("{\"prop1\":\"val1\",\"prop2\":\"val2\"}", message.body)
    }
}