package com.drumg.finsbury.testing

import net.corda.core.identity.CordaX500Name
import net.corda.testing.core.TestIdentity


val IM_A = TestIdentity(CordaX500Name(organisation = "Investment Manager A", locality = "TestLand", country = "US"))
val IM_B = TestIdentity(CordaX500Name(organisation = "Investment Manager B", locality = "TestCity", country = "US"))
var PB_A = TestIdentity(CordaX500Name(organisation = "Prime Broker A", locality = "TestVillage", country = "US"))
val PB_B = TestIdentity(CordaX500Name(organisation = "Prime Broker B", locality = "MiniLand", country = "US"))
val FA_A = TestIdentity(CordaX500Name(organisation = "Fund Admin A", locality = "MiniLand", country = "US"))
val FA_B = TestIdentity(CordaX500Name(organisation = "Fund Admin B", locality = "FakeLand", country = "US"))
val AU_A = TestIdentity(CordaX500Name(organisation = "Auditor A", locality = "FakeLand", country = "US"))
val AU_B = TestIdentity(CordaX500Name(organisation = "Auditor B", locality = "FakeLand", country = "US"))
val CUS_A = TestIdentity(CordaX500Name(organisation = "Custodian A", locality = "TestVillage", country = "US"))
val CUS_B = TestIdentity(CordaX500Name(organisation = "Custodian B", locality = "TestVillage", country = "US"))