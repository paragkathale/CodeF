package com.drumg.finsbury.testing

import com.drumg.finsbury.state.Fund
import com.drumg.finsbury.state.Trade
import com.drumg.finsbury.state.TradePairState
import com.drumg.finsbury.state.TradePairStatus
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.Party

fun createTradePairState(
        fund: Fund = createFund(),
        broker: Party = CUS_A.party,
        transactionId: String = "tx_id",
        pair: Pair<Trade, Trade> = createPair(),
        status: TradePairStatus = TradePairStatus.PAIRED,
        linearId: UniqueIdentifier = UniqueIdentifier()
): TradePairState {
    return TradePairState(
            fund = fund,
            broker = broker,
            transactionId = transactionId,
            pair = pair,
            status = status,
            linearId = linearId
    )
}

fun createPair(): Pair<Trade, Trade> {
    return Pair(
            Trade(
                    details = "trade_details_json_from_one_source",
                    provider = "Corda_IM",
                    linearId = UniqueIdentifier()
            ),
            Trade(
                    details = "trade_details_json_from_another_source",
                    provider = "Corda_CU",
                    linearId = UniqueIdentifier()
            )
    )
}