package com.drumg.finsbury.flow

import com.drumg.finsbury.contract.TradeRecordContract
import com.drumg.finsbury.state.Fund
import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.testing.createSource
import com.drumg.finsbury.testing.createTradeDetails
import net.corda.core.contracts.StateRef
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.transactions.SignedTransaction
import net.corda.core.utilities.getOrThrow
import net.corda.testing.internal.chooseIdentityAndCert
import net.corda.testing.node.MockNetwork
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.slf4j.LoggerFactory

class AmendTradeRecordFlowTests {
    private val network = MockNetwork(listOf("com.drumg.finsbury"))
    private val imNode = network.createNode()
    private val cusNode = network.createNode()
    private val faNode = network.createNode()

    private val imParty = imNode.info.chooseIdentityAndCert().party
    private val cusParty = cusNode.info.chooseIdentityAndCert().party
    private val faParty = faNode.info.chooseIdentityAndCert().party

    companion object {
        private val logger = LoggerFactory.getLogger(AmendTradeRecordFlowTests::class.java)
    }

    @Before
    fun setup() = network.runNetwork()

    @After
    fun tearDown() = network.stopNodes()

    /**
     * Propose a trade on the ledger, we need to do this before we can amend one.
     */
    private fun proposeTrade(tradeRecord: TradeRecordState): SignedTransaction {
        val flow = ProposeTradeRecordFlow(tradeRecord)
        val future = imNode.startFlow(flow)
        network.runNetwork()
        return future.getOrThrow()
    }

    /**
     * Created a trade record state to be used by the following tests.
     */
    private fun createTradeRecordState(
            tradeDetails: String = createTradeDetails(),
            linearId: UniqueIdentifier = UniqueIdentifier()
    ) = TradeRecordState(
            fund = Fund("P 39009", imParty, faParty),
            provider = imParty.name.organisation,
            role = imParty.name.organisationUnit ?: "Unknown",
            transactionId = "2145936887",
            investmentId = "US0236081024",
            tradeDetails = tradeDetails,
            source = createSource(),
            broker = cusParty,
            linearId = linearId
    )

    @Test
    fun `flow returns correctly formed partially signed transaction`() {
        val originalTrade = createTradeRecordState()
        val proposeTx = proposeTrade(originalTrade)
        val amendedTrade = createTradeRecordState(linearId = originalTrade.linearId, tradeDetails = "amended data")

        val flow = AmendTradeRecordFlow(amendedTrade)
        val future = imNode.startFlow(flow)
        network.runNetwork()

        val signedTx = future.getOrThrow()
        assert(signedTx.tx.inputs.size == 1)
        assert(signedTx.tx.outputs.size == 1)
        assert(signedTx.tx.inputs.single() == StateRef(proposeTx.id, 0))
        logger.info("Input state ref: ${signedTx.tx.inputs.single()} == ${StateRef(proposeTx.id, 0)}")
        val outputState = signedTx.tx.outputs.single().data as TradeRecordState
        logger.info("Output state: $outputState")
        val command = signedTx.tx.commands.single()
        assert(command.value == TradeRecordContract.Commands.Amend())
        signedTx.verifyRequiredSignatures()
    }

}