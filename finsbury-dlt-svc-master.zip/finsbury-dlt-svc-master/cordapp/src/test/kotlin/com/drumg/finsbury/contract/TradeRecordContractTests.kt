package com.drumg.finsbury.contract

import com.drumg.finsbury.state.Fund
import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.state.TradeRecordStatus
import com.drumg.finsbury.testing.*
import net.corda.core.contracts.TypeOnlyCommandData
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.Party
import net.corda.testing.contracts.DummyState
import net.corda.testing.node.MockServices
import net.corda.testing.node.ledger
import org.junit.Test

class TradeRecordContractTests {
    private val ledgerServices = MockServices(listOf("com.drumg.finsbury"))

    /**
     * Creates a trade record state to be used by the following tests.
     */
    private fun createTradeRecordState(broker: Party, linearId: UniqueIdentifier = UniqueIdentifier()) = TradeRecordState(
            fund = Fund("P 39009", IM_A.party, FA_A.party),
            provider = IM_A.name.organisation,
            role = IM_A.name.organisationUnit ?: "Unknown",
            transactionId = "2145936887",
            investmentId = "US0236081024",
            tradeDetails = createTradeDetails(),
            source = createSource(),
            broker = broker,
            linearId = linearId
    )

    private fun createTradeRecordState() = createTradeRecordState(CUS_A.party)


    class UnknownCommand : TypeOnlyCommandData()
    class UnsupportedCommand : TradeRecordContract.Commands

    @Test
    fun `must accept propose command`() {
        val tradeRecord = createTradeRecordState()
        ledgerServices.ledger {
            transaction {
                output(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), UnknownCommand())
                this.fails()
            }
            transaction {
                output(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Propose())
                this.verifies()
            }
        }
    }

    @Test
    fun `propose transaction must have no inputs`() {
        val tradeRecord = createTradeRecordState()
        ledgerServices.ledger {
            transaction {
                input(TradeRecordContract.ID, DummyState())
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Propose())
                output(TradeRecordContract.ID, tradeRecord)
                this `fails with` "No inputs should be consumed when proposing a trade record."
            }
            transaction {
                output(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Propose())
                this.verifies()
            }
        }
    }

    @Test
    fun `propose transaction must have one output`() {
        val tradeRecord = createTradeRecordState()
        ledgerServices.ledger {
            transaction {
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Propose())
                output(TradeRecordContract.ID, tradeRecord)
                output(TradeRecordContract.ID, tradeRecord)
                this `fails with` "Only one output state should be created when proposing a trade record."
            }
            transaction {
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Propose())
                output(TradeRecordContract.ID, tradeRecord)
                this.verifies()
            }
        }
    }

    @Test
    fun `fund manager and custodian cannot be the same`() {
        val tradeRecord = createTradeRecordState()
        val invalidTradeRecord = createTradeRecordState(IM_A.party)
        ledgerServices.ledger {
            transaction {
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Propose())
                output(TradeRecordContract.ID, invalidTradeRecord)
                this `fails with` "The fund manager and broker cannot have the same identity."
            }
            transaction {
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Propose())
                output(TradeRecordContract.ID, tradeRecord)
                this.verifies()
            }
        }
    }

    @Test
    fun `must accept amend command`() {
        val tradeRecord = createTradeRecordState()
        ledgerServices.ledger {
            transaction {
                input(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey), UnknownCommand())
                this.fails()
            }
            transaction {
                input(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey), TradeRecordContract.Commands.Amend())
                output(TradeRecordContract.ID, tradeRecord.withStatus(TradeRecordStatus.CANCELLED))
                this.verifies()
            }
        }
    }

    @Test
    fun `amend transaction must have one single input`() {
        val tradeRecord = createTradeRecordState()
        ledgerServices.ledger {
            transaction {
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Amend())
                output(TradeRecordContract.ID, tradeRecord)
                this `fails with` "Exactly one input should be consumed when amending a trade record."
            }
            transaction {
                input(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Amend())
                output(TradeRecordContract.ID, tradeRecord.withStatus(TradeRecordStatus.CANCELLED))
                this.verifies()
            }
        }
    }

    @Test
    fun `amend transaction output state linearId must match input state linearId`() {
        val tradeRecord = createTradeRecordState()
        val differentRecord = createTradeRecordState()
        ledgerServices.ledger {
            transaction {
                input(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Amend())
                output(TradeRecordContract.ID, differentRecord)
                this `fails with` "Output state must have the same linearId as the input state"
            }
            transaction {
                input(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Amend())
                output(TradeRecordContract.ID, tradeRecord.withStatus(TradeRecordStatus.CANCELLED))
                this.verifies()
            }
        }
    }

    @Test
    fun `pair transaction must also have a TradePairContract Create command in the transaction`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                input(TradeRecordContract.ID, com.drumg.finsbury.testing.createTradeRecordState())
                input(TradeRecordContract.ID, com.drumg.finsbury.testing.createTradeRecordState())
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Pair())
                this `fails with` "Required ${com.drumg.finsbury.contract.TradePairContract.Commands.Create::class.qualifiedName} command"
            }
            transaction {
                input(TradeRecordContract.ID, com.drumg.finsbury.testing.createTradeRecordState())
                input(TradeRecordContract.ID, com.drumg.finsbury.testing.createTradeRecordState())
                output(TradePairContract.ID, tradePair)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Pair())
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Create())
                this.verifies()
            }
        }
    }

    @Test
    fun `unpair transaction must also have a TradePairContract Cancel command in the transaction`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                output(TradeRecordContract.ID, com.drumg.finsbury.testing.createTradeRecordState())
                output(TradeRecordContract.ID, com.drumg.finsbury.testing.createTradeRecordState())
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Unpair())
                this `fails with` "Required ${com.drumg.finsbury.contract.TradePairContract.Commands.Cancel::class.qualifiedName} command"
            }
            transaction {
                input(TradePairContract.ID, tradePair)
                output(TradeRecordContract.ID, com.drumg.finsbury.testing.createTradeRecordState(linearId = tradePair.pair.first.linearId))
                output(TradeRecordContract.ID, com.drumg.finsbury.testing.createTradeRecordState(linearId = tradePair.pair.second.linearId))
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradeRecordContract.Commands.Unpair())
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Cancel())
                this.verifies()
            }
        }
    }

    @Test
    fun `throws an error when an unsupported transaction type is received`() {
        val tradeRecord = createTradeRecordState()
        ledgerServices.ledger {
            transaction {
                output(TradeRecordContract.ID, tradeRecord)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), UnsupportedCommand())
                this `fails with` "Unsupported command type."
            }
        }
    }
}