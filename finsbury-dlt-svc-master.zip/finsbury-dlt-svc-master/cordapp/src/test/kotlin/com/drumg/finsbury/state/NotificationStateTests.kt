package com.drumg.finsbury.state

import org.junit.Test
import kotlin.test.assertTrue

class NotificationStateTests {

    @Test
    fun `has at least one supported schema`() {
        val notificationState = NotificationState(NotificationTypes.BATCH_TX_UPLOAD_COMPLETE, "refHash")
        assertTrue(notificationState.supportedSchemas().toList().isNotEmpty(), "must have at least one supported schema")
    }

    @Test
    fun `persistent object should contain a type column mapped to the type field of the state`() {
        val notificationState = NotificationState(NotificationTypes.BATCH_TX_UPLOAD_COMPLETE, "refHash")
        val persistentState = notificationState.generateMappedObject(NotificationSchemaV1)
        assertTrue(persistentState is NotificationSchemaV1.PersistentNotification)
    }
}
