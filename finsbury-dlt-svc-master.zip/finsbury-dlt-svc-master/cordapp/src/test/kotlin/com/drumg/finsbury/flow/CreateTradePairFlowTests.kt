package com.drumg.finsbury.flow

import com.drumg.finsbury.contract.TradePairContract
import com.drumg.finsbury.contract.TradeRecordContract
import com.drumg.finsbury.state.Fund
import com.drumg.finsbury.state.Trade
import com.drumg.finsbury.state.TradePairState
import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.testing.createFund
import com.drumg.finsbury.testing.createTradePairState
import com.drumg.finsbury.testing.createTradeRecordState
import net.corda.core.contracts.StateRef
import net.corda.core.identity.Party
import net.corda.core.transactions.SignedTransaction
import net.corda.core.utilities.getOrThrow
import net.corda.testing.internal.chooseIdentityAndCert
import net.corda.testing.node.MockNetwork
import net.corda.testing.node.StartedMockNode
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.slf4j.LoggerFactory

class CreateTradePairFlowTests {
    private val network = MockNetwork(listOf("com.drumg.finsbury"))
    private val imNode = network.createNode()
    private val cusNode = network.createNode()
    private val faNode = network.createNode()

    private val imParty = imNode.info.chooseIdentityAndCert().party
    private val cusParty = cusNode.info.chooseIdentityAndCert().party
    private val faParty = faNode.info.chooseIdentityAndCert().party

    companion object {
        private val logger = LoggerFactory.getLogger(CreateTradePairFlowTests::class.java)
    }

    @Before
    fun setup() = network.runNetwork()

    @After
    fun tearDown() = network.stopNodes()

    @Test
    fun `flow returns correctly formed partially signed transaction`() {
        val fund = createFund(imParty, faParty)
        val (imProposeTradeTx, cusProposeTradeTx, pair) = createTradePair(fund = fund, broker = cusParty)
        val tradePairState = createTradePairState(fund = fund, broker = cusParty, pair = pair)

        val flow = CreateTradePairFlow(tradePairState)
        val future = imNode.startFlow(flow)
        network.runNetwork()

        val partiallySignedTx = future.getOrThrow()
        assert(partiallySignedTx.tx.inputs.size == 2)
        assert(partiallySignedTx.tx.outputs.size == 1)
        assert(partiallySignedTx.tx.inputs[0] == StateRef(imProposeTradeTx.id, 0))
        assert(partiallySignedTx.tx.inputs[1] == StateRef(cusProposeTradeTx.id, 0))

        val outputState = partiallySignedTx.tx.outputs.single().data as TradePairState
        logger.info("Output state: $outputState")
        val commands = partiallySignedTx.tx.commands.map { it.value }.toSet()
        assert(commands == setOf(TradePairContract.Commands.Create(), TradeRecordContract.Commands.Pair()))
        partiallySignedTx.verifyRequiredSignatures()
    }

    private fun createTradePair(fund: Fund, broker: Party): Triple<SignedTransaction, SignedTransaction, Pair<Trade, Trade>> {
        val imTradeRecord = createTradeRecordState("Corda_IM", "InvestmentManager", fund, broker)
        val proposeTx1 = proposeTrade(imTradeRecord, imNode)
        val cusTradeRecord = createTradeRecordState("Corda_CU", "Custodian", fund, broker)
        val proposeTx2 = proposeTrade(cusTradeRecord, cusNode)

        val pair = Pair(
                Trade(imTradeRecord.tradeDetails, imTradeRecord.provider, imTradeRecord.linearId),
                Trade(cusTradeRecord.tradeDetails, cusTradeRecord.provider, cusTradeRecord.linearId)
        )
        return Triple(proposeTx1, proposeTx2, pair)
    }

    /**
     * Propose a trade on the ledger, we need to do this before we can create a pair.
     */
    private fun proposeTrade(tradeRecord: TradeRecordState, node: StartedMockNode): SignedTransaction {
        val flow = ProposeTradeRecordFlow(tradeRecord)
        val future = node.startFlow(flow)
        network.runNetwork()
        return future.getOrThrow()
    }

}