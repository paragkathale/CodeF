package com.drumg.finsbury.state

import com.drumg.finsbury.testing.createTradeRecordState
import org.junit.Test
import kotlin.test.assertTrue

class TradeRecordStateTests {

    @Test
    fun `has at least one supported schema`() {
        val tradeRecordState = createTradeRecordState()
        assertTrue(tradeRecordState.supportedSchemas().toList().isNotEmpty(), "must have at least one supported schema")
    }

    @Test
    fun `persistent object should contain a type column mapped to the type field of the state`() {
        val tradeRecordState = createTradeRecordState()
        val persistentState = tradeRecordState.generateMappedObject(TradeRecordSchemaV1)
        assertTrue(persistentState is TradeRecordSchemaV1.PersistentTradeRecord)
    }
}
