package com.drumg.finsbury.flow

import com.drumg.finsbury.state.NotificationState
import com.drumg.finsbury.state.NotificationTypes
import net.corda.core.transactions.SignedTransaction
import net.corda.core.utilities.getOrThrow
import net.corda.testing.node.MockNetwork
import net.corda.testing.node.StartedMockNode
import org.junit.After
import org.junit.Before
import org.junit.Test
import kotlin.test.assertEquals

class NotificationFlowTests {
    private val network = MockNetwork(listOf("com.drumg.finsbury"))
    private val imNode = network.createNode()
    private val cusNode = network.createNode()
    private val faNode = network.createNode()

    @Before
    fun setup() {
        listOf(imNode, cusNode, faNode).forEach { it.registerInitiatedFlow(ReceiveNotificationFlow::class.java) }
    }

    @After
    fun tearDown() {
        network.stopNodes()
    }

    @Test
    fun `test notification state sharing`() {
        val notificationState = NotificationState(type = NotificationTypes.BATCH_TX_UPLOAD_COMPLETE, data = "hash")
        val signedTxFuture = imNode.startFlow(RaiseNotificationFlow(notificationState))
        network.runNetwork()

        val signedTx = signedTxFuture.getOrThrow()
        imNode.startFlow(ShareNotificationFlow(signedTx.getStateAndRef(), listOf(cusNode, faNode).map(this::toLegalEntities)))
        network.runNetwork()

        listOf(imNode, cusNode, faNode)
                .map { it.services.validatedTransactions.getTransaction(signedTx.id) }
                .forEach {
                    val tx = (it as SignedTransaction)
                    assertEquals(signedTx.id, tx.id)

                    val state = tx.getStateAndRef().state.data
                    assertEquals(NotificationTypes.BATCH_TX_UPLOAD_COMPLETE, state.type)
                    assertEquals("hash", state.data)
                }
    }

    private fun toLegalEntities(node: StartedMockNode) = node.info.legalIdentities.single()

    private fun SignedTransaction.getStateAndRef() = this.tx.outRefsOfType<NotificationState>().single()
}