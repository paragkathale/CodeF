package com.drumg.finsbury.state

import com.drumg.finsbury.testing.createTradePairState
import org.junit.Test
import kotlin.test.assertTrue

class TradePairStateTests {
    @Test
    fun `has at least one supported schema`() {
        val tradePairState = createTradePairState()
        assertTrue(tradePairState.supportedSchemas().toList().isNotEmpty(), "must have at least one supported schema")
    }

    @Test
    fun `persistent object should contain a type column mapped to the type field of the state`() {
        val tradePairState = createTradePairState()
        val persistentState = tradePairState.generateMappedObject(TradePairSchemaV1)
        assertTrue(persistentState is TradePairSchemaV1.PersistentTradeRecord)
    }
}