package com.drumg.finsbury.flow

import com.drumg.finsbury.contract.TradePairContract
import com.drumg.finsbury.contract.TradeRecordContract
import com.drumg.finsbury.state.*
import com.drumg.finsbury.testing.createFund
import com.drumg.finsbury.testing.createTradePairState
import com.drumg.finsbury.testing.createTradeRecordState
import net.corda.core.contracts.StateRef
import net.corda.core.identity.Party
import net.corda.core.transactions.SignedTransaction
import net.corda.core.utilities.getOrThrow
import net.corda.testing.internal.chooseIdentityAndCert
import net.corda.testing.node.MockNetwork
import net.corda.testing.node.StartedMockNode
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.slf4j.LoggerFactory

class CancelTradePairFlowTests {
    private val network = MockNetwork(listOf("com.drumg.finsbury"))
    private val imNode = network.createNode()
    private val cusNode = network.createNode()
    private val faNode = network.createNode()

    private val imParty = imNode.info.chooseIdentityAndCert().party
    private val cusParty = cusNode.info.chooseIdentityAndCert().party
    private val faParty = faNode.info.chooseIdentityAndCert().party

    private val imName = "Corda_IM"
    private val cusName = "Corda_CU"

    companion object {
        private val logger = LoggerFactory.getLogger(CancelTradePairFlowTests::class.java)
    }

    @Before
    fun setup() = network.runNetwork()

    @After
    fun tearDown() = network.stopNodes()

    @Test
    fun `flow returns correctly formed partially signed transaction`() {
        val fund = createFund(imParty, faParty)
        val (imTradeRecord, cusTradeRecord) = createTradeRecords(fund = fund, broker = cusParty)
        val (tradePairState, createPairTx) = createTradePair(fund, imTradeRecord, cusTradeRecord)

        val tradePairStateAndRef = createPairTx.tx.outRef<TradePairState>(tradePairState)
        val outputRecordPair = Pair(
                Trade("amended details", tradePairState.pair.first.provider, tradePairState.pair.first.linearId),
                tradePairState.pair.second
        )
        val flow = CancelTradePairFlow(tradePairStateAndRef, outputRecordPair)
        val future = imNode.startFlow(flow)
        network.runNetwork()

        val cancelPairTx = future.getOrThrow()
        assert(cancelPairTx.tx.inputs.size == 1)
        assert(cancelPairTx.tx.outputs.size == 2)
        assert(cancelPairTx.tx.inputs[0] == StateRef(createPairTx.id, 0))

        val outputStates = cancelPairTx.tx.outputs.map { it.data as TradeRecordState }
        logger.debug("Output state: $outputStates")
        outputStates.forEach { assert(it.status == TradeRecordStatus.CANCELLED) }

        val outputStatesIM = outputStates.filter { it.provider == imName }
        assert(outputStatesIM.size == 1)
        assert(outputStatesIM[0].tradeDetails == "amended details")

        val commands = cancelPairTx.tx.commands.map { it.value }.toSet()
        assert(commands == setOf(TradePairContract.Commands.Cancel(), TradeRecordContract.Commands.Unpair()))
        cancelPairTx.verifyRequiredSignatures()
    }

    private fun createTradeRecords(fund: Fund, broker: Party): Pair<TradeRecordState, TradeRecordState> {
        val imTradeRecord = createTradeRecordState(imName, "InvestmentManager", fund, broker)
        proposeTrade(imTradeRecord, imNode)
        val cusTradeRecord = createTradeRecordState(cusName, "Custodian", fund, broker)
        proposeTrade(cusTradeRecord, cusNode)

        return Pair(imTradeRecord, cusTradeRecord)
    }

    private fun createTradePair(fund: Fund, imTradeRecord: TradeRecordState, cusTradeRecord: TradeRecordState): Pair<TradePairState, SignedTransaction> {
        // using a new set of details to make sure it overwrites the previously consumed trade records
        val pair = Pair(
                Trade("latest im trade details", imName, imTradeRecord.linearId),
                Trade("latest cu trade details", cusName, cusTradeRecord.linearId)
        )
        val tradePairState = createTradePairState(fund = fund, broker = cusParty, pair = pair)

        val flow = CreateTradePairFlow(tradePairState)
        val future = imNode.startFlow(flow)
        network.runNetwork()

        return Pair(tradePairState, future.getOrThrow())
    }

    /**
     * Propose a trade on the ledger, we need to do this before we can create a pair.
     */
    private fun proposeTrade(tradeRecord: TradeRecordState, node: StartedMockNode): SignedTransaction {
        val flow = ProposeTradeRecordFlow(tradeRecord)
        val future = node.startFlow(flow)
        network.runNetwork()
        return future.getOrThrow()
    }

}