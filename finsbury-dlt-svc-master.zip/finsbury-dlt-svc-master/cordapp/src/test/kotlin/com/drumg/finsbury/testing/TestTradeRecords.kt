package com.drumg.finsbury.testing

import com.drumg.finsbury.state.Fund
import com.drumg.finsbury.state.TradeRecordState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.Party

fun createTradeDetails(): String {
    return """
            {
               "type": "BUY",
               "tradeDate": "20181106",
               "settleDate": "20181108",
               "tradeCurrency": "USD",
               "settleCurrency": "USD",
               "fxRate": "1.0",
               "quantity": "27544",
               "price": "64.86340964",
               "commissions": "35.8072",
               "fees": [{ "type": "SEC", "value": "0.0" }, { "type": "other", "value": "0.0" }],
               "netTradeAmount": "1786633.56",
               "grossTradeAmount": "1786597.76",
               "clearingBroker": {
                 "identifiers": [
                     {"type": "code", "value": "GS"},
                   {"type": "custom", "name": "ExecutingBrokerLongName", "value": "Goldman Sachs"}
                 ]
               },
               "executingBroker": {
                 "identifiers": [
                   { "type": "code", "value": "JPM" }
                 ]
               }
            }
            """.trimIndent()
}

fun createSource(): String {
    return """
            {
                "provider": "AQR",
                "received": "2018-12-31T17:35:00Z",
                "transport": "SFTP",
                "protocol": "CSV",
                "storage": {
                    "provider": "Azure",
                    "url": "https://aqr.drumg.blob.core.windows.net/finsbury/20181231-DEFGLUX-JPM.csv",
                    "hash": "0x268936593782349AB3"
                }
            }
        """.trimIndent()
}

fun createFund(manager: Party = IM_A.party, administrator: Party = FA_A.party): Fund {
    return Fund("P 39009", manager, administrator)
}

fun createTradeRecordState(
        provider: String = IM_A.name.organisation,
        role: String = (IM_A.name.organisationUnit ?: "Unknown"),
        fund: Fund = createFund(),
        broker: Party = CUS_A.party,
        details: String = createTradeDetails(),
        linearId: UniqueIdentifier = UniqueIdentifier()
): TradeRecordState = TradeRecordState(
        fund = fund,
        provider = provider,
        role = role,
        transactionId = "2145936887",
        investmentId = "US0236081024",
        tradeDetails = details,
        source = createSource(),
        broker = broker,
        linearId = linearId
)