package com.drumg.finsbury.flow

import com.drumg.finsbury.contract.TradePairContract
import com.drumg.finsbury.state.Trade
import com.drumg.finsbury.state.TradePairState
import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.testing.createFund
import com.drumg.finsbury.testing.createTradePairState
import com.drumg.finsbury.testing.createTradeRecordState
import net.corda.core.contracts.StateRef
import net.corda.core.transactions.SignedTransaction
import net.corda.core.utilities.getOrThrow
import net.corda.testing.internal.chooseIdentityAndCert
import net.corda.testing.node.MockNetwork
import net.corda.testing.node.StartedMockNode
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.slf4j.LoggerFactory

class AmendTradePairFlowTests {
    private val network = MockNetwork(listOf("com.drumg.finsbury"))
    private val imNode = network.createNode()
    private val cusNode = network.createNode()
    private val faNode = network.createNode()

    private val imParty = imNode.info.chooseIdentityAndCert().party
    private val cusParty = cusNode.info.chooseIdentityAndCert().party
    private val faParty = faNode.info.chooseIdentityAndCert().party

    val fund = createFund(imParty, faParty)
    val broker = cusParty

    companion object {
        private val logger = LoggerFactory.getLogger(AmendTradePairFlowTests::class.java)
    }

    @Before
    fun setup() = network.runNetwork()

    @After
    fun tearDown() = network.stopNodes()

    @Test
    fun `flow returns correctly formed partially signed transaction`() {
        val imTradeRecord = runProposeTradeRecordFlow("Corda_IM", "InvestmentManager", imNode)
        val cusTradeRecord = runProposeTradeRecordFlow("Corda_CU", "Custodian", cusNode)
        val (tradePairState, createTx) = runCreateTradePairFlow(imTradeRecord, cusTradeRecord)

        val amendedDetails = "amended details"
        val amendedPair = Pair(tradePairState.pair.first, Trade(amendedDetails, "Corda_CU", tradePairState.pair.second.linearId))
        val amendedState = createTradePairState(linearId = tradePairState.linearId, fund = fund, broker = broker, pair = amendedPair)

        val flow = AmendTradePairFlow(amendedState)
        val future = imNode.startFlow(flow)
        network.runNetwork()

        val signedTx = future.getOrThrow()

        // verify inputs
        assert(signedTx.tx.inputs.single() == StateRef(createTx.id, 0))
        logger.info("Input state ref: ${signedTx.tx.inputs.single()} == ${StateRef(createTx.id, 0)}")

        // verify outputs
        val outputState = signedTx.tx.outputs.single().data as TradePairState
        logger.info("Output state: $outputState")
        assert(outputState.pair.second.details == amendedDetails)

        // verify commands
        val command = signedTx.tx.commands.single()
        assert(command.value == TradePairContract.Commands.Amend())

        // verify signatures
        signedTx.verifyRequiredSignatures()
    }

    /**
     * Propose a trade on the ledger, we need to do this before we can create a pair.
     */
    private fun runProposeTradeRecordFlow(provider: String, role: String, node: StartedMockNode): TradeRecordState {
        val tradeRecord = createTradeRecordState(provider, role, fund, broker)
        val flow = ProposeTradeRecordFlow(tradeRecord)

        val future = node.startFlow(flow)
        network.runNetwork()
        future.getOrThrow()

        return tradeRecord
    }


    /**
     * Create a trade pair on the ledger, we need to do this before we can amend a pair.
     */
    private fun runCreateTradePairFlow(first: TradeRecordState, second: TradeRecordState): Pair<TradePairState, SignedTransaction> {
        val pair = Pair(
                Trade(first.tradeDetails, first.provider, first.linearId),
                Trade(second.tradeDetails, second.provider, second.linearId)
        )

        val tradePairState = createTradePairState(fund = fund, broker = broker, pair = pair)

        val flow = CreateTradePairFlow(tradePairState)
        val future = imNode.startFlow(flow)
        network.runNetwork()

        return Pair(tradePairState, future.getOrThrow())
    }
}