package com.drumg.finsbury.contract

import com.drumg.finsbury.state.TradePairStatus
import com.drumg.finsbury.testing.*
import net.corda.core.contracts.TypeOnlyCommandData
import net.corda.testing.contracts.DummyState
import net.corda.testing.node.MockServices
import net.corda.testing.node.ledger
import org.junit.Test

class TradePairContractTests {
    private val ledgerServices = MockServices(listOf("com.drumg.finsbury"))

    class UnknownCommand : TypeOnlyCommandData()
    class UnsupportedCommand : TradePairContract.Commands

    @Test
    fun `must accept create command`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                output(TradePairContract.ID, tradePair)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), UnknownCommand())
                this.fails()
            }
            transaction {
                input(TradePairContract.ID, createTradeRecordState())
                input(TradePairContract.ID, createTradeRecordState())
                output(TradePairContract.ID, tradePair)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Create())
                this.verifies()
            }
        }
    }

    @Test
    fun `create transaction must have two TradeRecordState inputs`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                input(TradePairContract.ID, DummyState())
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Create())
                output(TradePairContract.ID, tradePair)
                this `fails with` "Two trades must be consumed when creating a trade pair."
            }
            transaction {
                input(TradePairContract.ID, createTradeRecordState())
                input(TradePairContract.ID, createTradeRecordState())
                output(TradePairContract.ID, tradePair)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Create())
                this.verifies()
            }
        }
    }

    @Test
    fun `create transaction must have one TradePairState output`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Create())
                input(TradePairContract.ID, createTradeRecordState())
                input(TradePairContract.ID, createTradeRecordState())
                output(TradePairContract.ID, tradePair)
                output(TradePairContract.ID, tradePair)
                this `fails with` "Only one output state should be created when creating a trade pair."
            }
            transaction {
                input(TradePairContract.ID, createTradeRecordState())
                input(TradePairContract.ID, createTradeRecordState())
                output(TradePairContract.ID, tradePair)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Create())
                this.verifies()
            }
        }
    }

    @Test
    fun `create transaction must have status PAIRED`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                input(TradePairContract.ID, createTradeRecordState())
                input(TradePairContract.ID, createTradeRecordState())
                output(TradePairContract.ID, tradePair.withStatus(TradePairStatus.CANCELLED))
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Create())
                this `fails with` "Created transaction must have a PAIRED status."
            }
            transaction {
                input(TradePairContract.ID, createTradeRecordState())
                input(TradePairContract.ID, createTradeRecordState())
                output(TradePairContract.ID, tradePair)
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Create())
                this.verifies()
            }
        }
    }

    @Test
    fun `must accept amend command`() {
        val inputState = createTradePairState()
        val outputState = createTradePairState(status = TradePairStatus.CANCELLED, linearId = inputState.linearId)

        ledgerServices.ledger {
            transaction {
                input(TradePairContract.ID, inputState)
                command(listOf(IM_A.publicKey), UnknownCommand())
                output(TradePairContract.ID, outputState)
                this.fails()
            }
            transaction {
                input(TradePairContract.ID, inputState)
                command(listOf(IM_A.publicKey), TradePairContract.Commands.Amend())
                output(TradePairContract.ID, outputState)
                this.verifies()
            }
        }
    }

    @Test
    fun `amend transaction must have one single input and one single output`() {
        val inputState = createTradePairState()
        val outputState = createTradePairState(status = TradePairStatus.CANCELLED, linearId = inputState.linearId)

        ledgerServices.ledger {
            transaction {
                command(listOf(IM_A.publicKey), TradePairContract.Commands.Amend())
                output(TradePairContract.ID, outputState)
                this `fails with` "Exactly one input should be consumed when amending a trade pair."
            }
            transaction {
                command(listOf(IM_A.publicKey), TradePairContract.Commands.Amend())
                input(TradePairContract.ID, inputState)
                this `fails with` "Exactly one output should be created when amending a trade pair."
            }
            transaction {
                input(TradePairContract.ID, inputState)
                command(listOf(IM_A.publicKey), TradePairContract.Commands.Amend())
                output(TradePairContract.ID, outputState)
                this.verifies()
            }
        }
    }

    @Test
    fun `amend transaction output state linearId must match input state linearId`() {
        val inputState = createTradePairState()
        val updatedPair = createTradePairState(status = TradePairStatus.CANCELLED, linearId = inputState.linearId)
        val differentPair = createTradePairState()

        ledgerServices.ledger {
            transaction {
                input(TradePairContract.ID, inputState)
                command(listOf(IM_A.publicKey), TradePairContract.Commands.Amend())
                output(TradePairContract.ID, differentPair)
                this `fails with` "Output state must have the same linearId as the input state"
            }
            transaction {
                input(TradePairContract.ID, inputState)
                command(listOf(IM_A.publicKey), TradePairContract.Commands.Amend())
                output(TradePairContract.ID, updatedPair)
                this.verifies()
            }
        }
    }

    @Test
    fun `must accept cancel command`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                input(TradePairContract.ID, tradePair)
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.first.linearId))
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.second.linearId))
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), UnknownCommand())
                this.fails()
            }
            transaction {
                input(TradePairContract.ID, tradePair)
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.first.linearId))
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.second.linearId))
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Cancel())
                this.verifies()
            }
        }
    }

    @Test
    fun `cancel transaction must have one TradePairState input`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Cancel())
                input(TradePairContract.ID, createTradeRecordState())
                input(TradePairContract.ID, createTradeRecordState())
                output(TradePairContract.ID, tradePair)
                this `fails with` "Only one input state should be consumed when cancelling a trade pair."
            }
            transaction {
                input(TradePairContract.ID, tradePair)
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.first.linearId))
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.second.linearId))
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Cancel())
                this.verifies()
            }
        }
    }

    @Test
    fun `cancel transaction must have two TradeRecordState outputs`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                input(TradePairContract.ID, tradePair)
                output(TradePairContract.ID, createTradeRecordState())
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Cancel())
                this `fails with` "Two trades must be created when cancelling a trade pair."
            }
            transaction {
                input(TradePairContract.ID, tradePair)
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.first.linearId))
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.second.linearId))
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Cancel())
                this.verifies()
            }
        }
    }

    @Test
    fun `cancel transaction must have two TradeRecordState outputs with the same linearIds from the pair input state`() {
        val tradePair = createTradePairState()
        ledgerServices.ledger {
            transaction {
                input(TradePairContract.ID, tradePair)
                output(TradePairContract.ID, createTradeRecordState())
                output(TradePairContract.ID, createTradeRecordState())
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Cancel())
                this `fails with` "Two trades must be created with the same trade linearIds from the pair object."
            }
            transaction {
                input(TradePairContract.ID, tradePair)
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.first.linearId))
                output(TradePairContract.ID, createTradeRecordState(linearId = tradePair.pair.second.linearId))
                command(listOf(IM_A.publicKey, CUS_A.publicKey, FA_A.publicKey), TradePairContract.Commands.Cancel())
                this.verifies()
            }
        }
    }

    @Test
    fun `throws an error when an unsupported transaction type is received`() {
        val tradePair = createTradePairState()
        val updatedPair = createTradePairState(status = TradePairStatus.CANCELLED, linearId = tradePair.linearId)

        ledgerServices.ledger {
            transaction {
                input(TradePairContract.ID, tradePair)
                command(listOf(IM_A.publicKey), UnsupportedCommand())
                output(TradePairContract.ID, updatedPair)
                this `fails with` "Unsupported command type."
            }
        }
    }
}