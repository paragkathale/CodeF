package com.drumg.finsbury.flow

import com.drumg.finsbury.state.Fund
import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.testing.createSource
import com.drumg.finsbury.testing.createTradeDetails
import net.corda.core.contracts.TransactionVerificationException
import net.corda.core.identity.Party
import net.corda.core.transactions.SignedTransaction
import net.corda.core.utilities.getOrThrow
import net.corda.testing.internal.chooseIdentityAndCert
import net.corda.testing.node.MockNetwork
import org.junit.After
import org.junit.Before
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class ProposeTradeRecordFlowTests {
    private val network = MockNetwork(listOf("com.drumg.finsbury"))
    private val imNode = network.createNode()
    private val cusNode = network.createNode()
    private val faNode = network.createNode()
    private val auditorNode = network.createNode()

    private val imParty = imNode.info.chooseIdentityAndCert().party
    private val cusParty = cusNode.info.chooseIdentityAndCert().party
    private val faParty = faNode.info.chooseIdentityAndCert().party
    private val auditorParty = auditorNode.info.chooseIdentityAndCert().party

    private fun createTradeRecordState(broker: Party) = createTradeRecordState(broker, emptyList())
    private fun createTradeRecordState(broker: Party, observers: List<Party>) = TradeRecordState(
            fund = Fund("P 39009", imParty, faParty),
            provider = imParty.name.organisation,
            role = imParty.name.organisationUnit ?: "Unknown",
            transactionId = "2145936887",
            investmentId = "US0236081024",
            tradeDetails = createTradeDetails(),
            source = createSource(),
            broker = broker,
            observers = observers
    )

    @Before
    fun setup() = network.runNetwork()

    @After
    fun tearDown() = network.stopNodes()

    @Test
    fun `flow returns correctly formed partially signed transaction`() {
        val tradeRecord = createTradeRecordState(cusParty)
        val flow = ProposeTradeRecordFlow(tradeRecord)
        val future = imNode.startFlow(flow)
        network.runNetwork()

        val partiallySignedTx = future.getOrThrow()
        partiallySignedTx.verifySignaturesExcept(listOf(cusParty, faParty).map { it.owningKey })
    }

    @Test
    fun `flow returns verified partially signed transaction`() {
        // Check that a trade record with a invalid custodian (same identity as IM) fails.
        val invalidTradeRecord = createTradeRecordState(imParty)
        val flowOne = ProposeTradeRecordFlow(invalidTradeRecord)
        val futureOne = imNode.startFlow(flowOne)
        network.runNetwork()
        assertFailsWith<TransactionVerificationException> { futureOne.getOrThrow() }

        val tradeRecord = createTradeRecordState(cusParty)
        val flow = ProposeTradeRecordFlow(tradeRecord)
        val future = imNode.startFlow(flow)
        network.runNetwork()
        future.getOrThrow()
    }

    @Test
    fun `flow returns transaction signed by all participants`() {
        val tradeRecord = createTradeRecordState(cusParty)
        val flow = ProposeTradeRecordFlow(tradeRecord)
        val future = imNode.startFlow(flow)
        network.runNetwork()
        val signedTx = future.getOrThrow()
        signedTx.verifyRequiredSignatures()
    }

    @Test
    fun `flow records the same transaction in all participant and observer vaults when initiated from IM node`() {
        val tradeRecord = createTradeRecordState(cusParty, listOf(auditorParty))
        val flow = ProposeTradeRecordFlow(tradeRecord)
        val future = imNode.startFlow(flow)
        network.runNetwork()

        val signedTx = future.getOrThrow()
        listOf(imNode, cusNode, faNode, auditorNode)
                .map { it.services.validatedTransactions.getTransaction(signedTx.id) }
                .forEach {
                    val txHash = (it as SignedTransaction).id
                    assertEquals(signedTx.id, txHash)
                }
    }

    @Test
    fun `flow records the same transaction in all participant and observer vaults when initiated from custodian node`() {
        val tradeRecord = createTradeRecordState(cusParty, listOf(auditorParty))
        val flow = ProposeTradeRecordFlow(tradeRecord)
        val future = cusNode.startFlow(flow)
        network.runNetwork()

        val signedTx = future.getOrThrow()
        listOf(imNode, cusNode, faNode, auditorNode)
                .map { it.services.validatedTransactions.getTransaction(signedTx.id) }
                .forEach {
                    val txHash = (it as SignedTransaction).id
                    assertEquals(signedTx.id, txHash)
                }
    }
}