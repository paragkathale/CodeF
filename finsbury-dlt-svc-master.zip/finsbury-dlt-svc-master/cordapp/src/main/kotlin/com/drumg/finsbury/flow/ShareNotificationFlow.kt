package com.drumg.finsbury.flow

import co.paralleluniverse.fibers.Suspendable
import com.drumg.finsbury.state.NotificationState
import net.corda.core.contracts.StateAndRef
import net.corda.core.flows.*
import net.corda.core.identity.Party

@StartableByRPC
@InitiatingFlow
class ShareNotificationFlow(private val stateAndRef: StateAndRef<NotificationState>,
                            private val recipients: List<Party>) : FlowLogic<Unit>() {
    @Suspendable
    override fun call() {
        val sessions = recipients.map { initiateFlow(it) }

        val transactionId = stateAndRef.ref.txhash

        val transaction = serviceHub.validatedTransactions.getTransaction(transactionId)
                ?: throw FlowException("Cannot find $transactionId.")

        sessions.forEach { subFlow(SendTransactionFlow(it, transaction)) }
    }
}
