package com.drumg.finsbury.flow

import co.paralleluniverse.fibers.Suspendable
import com.drumg.finsbury.contract.TradePairContract
import com.drumg.finsbury.contract.TradeRecordContract
import com.drumg.finsbury.state.Trade
import com.drumg.finsbury.state.TradePairState
import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.state.TradeRecordStatus
import net.corda.core.contracts.StateAndRef
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.PageSpecification
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.Sort
import net.corda.core.node.services.vault.SortAttribute
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker

@InitiatingFlow
@StartableByRPC
class CancelTradePairFlow(private val inputStateAndRef: StateAndRef<TradePairState>,
                          private val outputRecordPair: Pair<Trade, Trade>) : FlowLogic<SignedTransaction>() {

    @Suppress("ClassName")
    companion object {
        object RETRIEVE_TRADE_DATA : ProgressTracker.Step("Retrieving trade records using linearIds")
        object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on trade pair.")
        object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
        object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
        object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(
                RETRIEVE_TRADE_DATA,
                GENERATING_TRANSACTION,
                VERIFYING_TRANSACTION,
                SIGNING_TRANSACTION,
                FINALISING_TRANSACTION
        )
    }

    override val progressTracker = tracker()

    @Suspendable
    override fun call(): SignedTransaction {
        progressTracker.currentStep = RETRIEVE_TRADE_DATA
        val outputTradeRecordFirst = createOutputTradeRecord(outputRecordPair.first)
        val outputTradeRecordSecond = createOutputTradeRecord(outputRecordPair.second)

        progressTracker.currentStep = GENERATING_TRANSACTION
        val txBuilder = TransactionBuilder(notary = serviceHub.networkMapCache.notaryIdentities.single())

        txBuilder.addCommand(TradePairContract.Commands.Cancel(), ourIdentity.owningKey)
                .addInputState(inputStateAndRef)

        txBuilder.addCommand(TradeRecordContract.Commands.Unpair(), ourIdentity.owningKey)
                .addOutputState(outputTradeRecordFirst, TradeRecordContract.ID)
                .addOutputState(outputTradeRecordSecond, TradeRecordContract.ID)

        progressTracker.currentStep = VERIFYING_TRANSACTION
        txBuilder.verify(serviceHub)

        progressTracker.currentStep = SIGNING_TRANSACTION
        val signedTx = serviceHub.signInitialTransaction(txBuilder)

        progressTracker.currentStep = FINALISING_TRANSACTION
        return subFlow(FinalityFlow(signedTx, FINALISING_TRANSACTION.childProgressTracker()))
    }

    private fun createOutputTradeRecord(trade: Trade): TradeRecordState {
        // Find latest tradeDetails from the pair and re-create the previously consumed record with the latest details.
        val consumedRecord = queryLastConsumedTradeRecord(trade.linearId)
        return consumedRecord
                .withDetails(trade.details)
                .withStatus(TradeRecordStatus.CANCELLED)
    }

    private fun queryLastConsumedTradeRecord(linearId: UniqueIdentifier): TradeRecordState {
        try {
            val queryCriteria = QueryCriteria.LinearStateQueryCriteria(linearId = listOf(linearId), status = Vault.StateStatus.CONSUMED)
            val byConsumedTime = Sort.SortColumn(SortAttribute.Standard(Sort.VaultStateAttribute.CONSUMED_TIME), Sort.Direction.DESC)
            val paging = PageSpecification(pageNumber = 1, pageSize = 1)

            return serviceHub.vaultService.queryBy<TradeRecordState>(queryCriteria, paging, Sort(listOf(byConsumedTime)))
                    .states.single().state.data
        } catch (err: Exception) {
            throw IllegalArgumentException("Error querying consumed trade record $linearId", err)
        }
    }
}
