package com.drumg.finsbury.flow

import co.paralleluniverse.fibers.Suspendable
import com.drumg.finsbury.contract.TradePairContract
import com.drumg.finsbury.contract.TradeRecordContract
import com.drumg.finsbury.state.TradePairState
import com.drumg.finsbury.state.TradeRecordState
import net.corda.core.contracts.StateAndRef
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker

@InitiatingFlow
@StartableByRPC
class CreateTradePairFlow(private val tradePairState: TradePairState) : FlowLogic<SignedTransaction>() {

    @Suppress("ClassName")
    companion object {
        object RETRIEVE_TRADE_RECORDS : ProgressTracker.Step("Retrieving trade record pair using linearIds")
        object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on trade pair.")
        object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
        object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
        object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(
                RETRIEVE_TRADE_RECORDS,
                GENERATING_TRANSACTION,
                VERIFYING_TRANSACTION,
                SIGNING_TRANSACTION,
                FINALISING_TRANSACTION
        )
    }

    override val progressTracker = tracker()

    @Suspendable
    override fun call(): SignedTransaction {
        progressTracker.currentStep = RETRIEVE_TRADE_RECORDS
        val (firstTrade, secondTrade) = tradePairState.pair.toList().map { trade -> queryTradeRecord(trade.linearId) }

        progressTracker.currentStep = GENERATING_TRANSACTION
        val txBuilder = TransactionBuilder(notary = serviceHub.networkMapCache.notaryIdentities.single())

        txBuilder.addCommand(TradeRecordContract.Commands.Pair(), ourIdentity.owningKey)
                .addInputState(firstTrade)
                .addInputState(secondTrade)

        txBuilder.addCommand(TradePairContract.Commands.Create(), ourIdentity.owningKey)
                .addOutputState(tradePairState, TradePairContract.ID)

        progressTracker.currentStep = VERIFYING_TRANSACTION
        txBuilder.verify(serviceHub)

        progressTracker.currentStep = SIGNING_TRANSACTION
        val signedTx = serviceHub.signInitialTransaction(txBuilder)

        progressTracker.currentStep = FINALISING_TRANSACTION
        return subFlow(FinalityFlow(signedTx, FINALISING_TRANSACTION.childProgressTracker()))
    }

    private fun queryTradeRecord(linearId: UniqueIdentifier): StateAndRef<TradeRecordState> {
        val queryCriteria = QueryCriteria.LinearStateQueryCriteria(linearId = listOf(linearId))
        return serviceHub.vaultService.queryBy<TradeRecordState>(queryCriteria).states.single()
    }
}
