package com.drumg.finsbury.flow

import co.paralleluniverse.fibers.Suspendable
import com.drumg.finsbury.contract.TradeRecordContract
import com.drumg.finsbury.state.TradeRecordState
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step

/**
 * This is the flow which handles proposal of new trade records on the ledger.
 */
@InitiatingFlow
@StartableByRPC
class ProposeTradeRecordFlow(val state: TradeRecordState) : FlowLogic<SignedTransaction>() {

    @Suppress("ClassName")
    companion object {
        object GENERATING_TRANSACTION : Step("Generating transaction based on proposed TradeRecord.")
        object VERIFYING_TRANSACTION : Step("Verifying contract constraints.")
        object SIGNING_TRANSACTION : Step("Signing transaction with our private key.")
        object FINALISING_TRANSACTION : Step("Obtaining notary signature and recording transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(
                GENERATING_TRANSACTION,
                VERIFYING_TRANSACTION,
                SIGNING_TRANSACTION,
                FINALISING_TRANSACTION
        )
    }

    override val progressTracker = tracker()

    @Suspendable
    override fun call(): SignedTransaction {
        progressTracker.currentStep = GENERATING_TRANSACTION
        val txBuilder = TransactionBuilder(notary = serviceHub.networkMapCache.notaryIdentities.single())
                .addOutputState(state, TradeRecordContract.ID)
                .addCommand(TradeRecordContract.Commands.Propose(), ourIdentity.owningKey)

        progressTracker.currentStep = VERIFYING_TRANSACTION
        txBuilder.verify(serviceHub)

        progressTracker.currentStep = SIGNING_TRANSACTION
        val signedTx = serviceHub.signInitialTransaction(txBuilder)

        progressTracker.currentStep = FINALISING_TRANSACTION
        return subFlow(FinalityFlow(signedTx, state.observers.toSet(), FINALISING_TRANSACTION.childProgressTracker()))
    }
}
