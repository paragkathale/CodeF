package com.drumg.finsbury.flow

import co.paralleluniverse.fibers.Suspendable
import com.drumg.finsbury.contract.NotificationContract
import com.drumg.finsbury.state.NotificationState
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder

@InitiatingFlow
@StartableByRPC
class RaiseNotificationFlow(val state: NotificationState) : FlowLogic<SignedTransaction>() {
    @Suspendable
    override fun call(): SignedTransaction {
        val txBuilder = TransactionBuilder(notary = serviceHub.networkMapCache.notaryIdentities.single())
                .addOutputState(state, NotificationContract.ID)
                .addCommand(NotificationContract.Commands.Raise(), ourIdentity.owningKey)

        txBuilder.verify(serviceHub)

        val signedTx = serviceHub.signInitialTransaction(txBuilder)

        return subFlow(FinalityFlow(signedTx))
    }
}

