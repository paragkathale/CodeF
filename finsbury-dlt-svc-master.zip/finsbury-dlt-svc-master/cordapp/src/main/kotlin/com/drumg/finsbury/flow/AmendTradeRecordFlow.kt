package com.drumg.finsbury.flow

import co.paralleluniverse.fibers.Suspendable
import com.drumg.finsbury.contract.TradeRecordContract
import com.drumg.finsbury.state.TradeRecordState
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step

/**
 * This is the flow which handles amendment of an existing trade records on the ledger.
 */
@InitiatingFlow
@StartableByRPC
class AmendTradeRecordFlow(private val amendedState: TradeRecordState) : FlowLogic<SignedTransaction>() {

    @Suppress("ClassName")
    companion object {
        object RETRIEVE_TRADE_RECORD : Step("Retrieving trade record using linearId")
        object GENERATING_TRANSACTION : Step("Generating transaction based on input TradeRecord.")
        object VERIFYING_TRANSACTION : Step("Verifying contract constraints.")
        object SIGNING_TRANSACTION : Step("Signing transaction with our private key.")
        object FINALISING_TRANSACTION : Step("Obtaining notary signature and recording transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(
                RETRIEVE_TRADE_RECORD,
                GENERATING_TRANSACTION,
                VERIFYING_TRANSACTION,
                SIGNING_TRANSACTION,
                FINALISING_TRANSACTION
        )
    }

    override val progressTracker = tracker()

    @Suspendable
    override fun call(): SignedTransaction {
        // TODO: at some point we might want to validate that input and output are created by the same party
        // i.e. prevent parties from modifying others' records.
        progressTracker.currentStep = RETRIEVE_TRADE_RECORD
        val queryCriteria = QueryCriteria.LinearStateQueryCriteria(linearId = listOf(amendedState.linearId))
        val trStateAndRef = serviceHub.vaultService.queryBy<TradeRecordState>(queryCriteria).states.single()
        val inputState = trStateAndRef.state.data

        progressTracker.currentStep = GENERATING_TRANSACTION
        val txBuilder = TransactionBuilder(notary = serviceHub.networkMapCache.notaryIdentities.single())
                .addInputState(trStateAndRef)
                .addOutputState(amendedState, TradeRecordContract.ID)
                .addCommand(TradeRecordContract.Commands.Amend(), ourIdentity.owningKey)

        progressTracker.currentStep = VERIFYING_TRANSACTION
        txBuilder.verify(serviceHub)

        progressTracker.currentStep = SIGNING_TRANSACTION
        val signedTx = serviceHub.signInitialTransaction(txBuilder)

        progressTracker.currentStep = FINALISING_TRANSACTION
        return subFlow(FinalityFlow(signedTx, inputState.observers.toSet(), FINALISING_TRANSACTION.childProgressTracker()))
    }
}
