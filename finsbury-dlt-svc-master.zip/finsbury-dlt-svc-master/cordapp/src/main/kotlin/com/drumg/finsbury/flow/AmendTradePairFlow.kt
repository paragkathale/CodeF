package com.drumg.finsbury.flow

import co.paralleluniverse.fibers.Suspendable
import com.drumg.finsbury.contract.TradePairContract
import com.drumg.finsbury.state.TradePairState
import net.corda.core.flows.FinalityFlow
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step

/**
 * This is the flow which handles amendment of an existing trade pairs on the ledger.
 */
@InitiatingFlow
@StartableByRPC
class AmendTradePairFlow(private val amendedState: TradePairState) : FlowLogic<SignedTransaction>() {

    @Suppress("ClassName")
    companion object {
        object RETRIEVE_TRADE_PAIR : Step("Retrieving trade pair using linearId")
        object GENERATING_TRANSACTION : Step("Generating transaction based on input TradePair.")
        object VERIFYING_TRANSACTION : Step("Verifying contract constraints.")
        object SIGNING_TRANSACTION : Step("Signing transaction with our private key.")
        object FINALISING_TRANSACTION : Step("Obtaining notary signature and recording transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(
                RETRIEVE_TRADE_PAIR,
                GENERATING_TRANSACTION,
                VERIFYING_TRANSACTION,
                SIGNING_TRANSACTION,
                FINALISING_TRANSACTION
        )
    }

    override val progressTracker = tracker()

    @Suspendable
    override fun call(): SignedTransaction {
        progressTracker.currentStep = RETRIEVE_TRADE_PAIR
        val queryCriteria = QueryCriteria.LinearStateQueryCriteria(linearId = listOf(amendedState.linearId))
        val trStateAndRef = serviceHub.vaultService.queryBy<TradePairState>(queryCriteria).states.single()

        progressTracker.currentStep = GENERATING_TRANSACTION
        val txBuilder = TransactionBuilder(notary = serviceHub.networkMapCache.notaryIdentities.single())
                .addInputState(trStateAndRef)
                .addOutputState(amendedState, TradePairContract.ID)
                .addCommand(TradePairContract.Commands.Amend(), ourIdentity.owningKey)

        progressTracker.currentStep = VERIFYING_TRANSACTION
        txBuilder.verify(serviceHub)

        progressTracker.currentStep = SIGNING_TRANSACTION
        val signedTx = serviceHub.signInitialTransaction(txBuilder)

        progressTracker.currentStep = FINALISING_TRANSACTION
        return subFlow(FinalityFlow(signedTx, emptySet(), FINALISING_TRANSACTION.childProgressTracker()))
    }
}
