#!/bin/bash

#Grab it from the Azure Vault
DEPLOY_TOKEN=$(az keyvault secret show --vault-name "drumg-dev-tf-vault00" --name "get-deploy-script-finsbury" --query value -o tsv)

if [[ -z "${DEPLOY_TOKEN}" ]]; then
  echo "DEPLOY_TOKEN must be set. Exiting."
  exit 1;
fi

mkdir -p scripts

curl -H "Authorization: token $DEPLOY_TOKEN" https://api.github.com/repos/DrumG/finsbury-dlt-svc/contents/scripts/deploy-cordapp.sh | jq --raw-output .content | base64 --decode > scripts/deploy-cordapp.sh
chmod +x scripts/deploy-cordapp.sh
