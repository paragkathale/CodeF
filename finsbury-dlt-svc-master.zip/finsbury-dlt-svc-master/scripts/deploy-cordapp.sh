#!/usr/bin/env bash

sudo service corda restart
