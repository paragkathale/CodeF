#!/bin/bash

APP_NAME=finsbury-dlt-svc
JAR_FILE=${APP_NAME}-*.jar
CONFIG_FILE=application-env.properties

SERVICE_DIR_PREFIX=/opt/drumg
SERVICE_DIR=${SERVICE_DIR_PREFIX}/${APP_NAME}
APP_DIR=${SERVICE_DIR}/app

cd $APP_DIR || die "Service is not present in expected location ${APP_DIR}"

[ ! -e logs ] && ln -s /opt/drumg/logs .

APP_OPTS=
if [ -f $CONFIG_FILE ]; then
    echo "using app config file $CONFIG_FILE"
    APP_OPTS=--spring.profiles.active=env
fi

java -jar $JAR_FILE $APP_OPTS 2>&1 >> /dev/null 
