package com.drumg.finsbury.utils

import org.bouncycastle.util.encoders.Hex
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

fun sha256(source: String): String {
    val md = MessageDigest.getInstance("SHA-256")
    val hashBytes = md.digest(source.toByteArray(StandardCharsets.UTF_8))
    return Hex.encode(hashBytes).toString(StandardCharsets.UTF_8)
}