package com.drumg.finsbury.contract

import com.drumg.finsbury.state.TradeRecordState
import com.drumg.finsbury.state.TradeRecordStatus
import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction

class TradeRecordContract : Contract {
    companion object {
        const val ID = "com.drumg.finsbury.contract.TradeRecordContract"
    }

    override fun verify(tx: LedgerTransaction) {
        val command = tx.commands.requireSingleCommand<Commands>()

        when (command.value) {
            is Commands.Propose -> {
                requireThat {
                    "No inputs should be consumed when proposing a trade record." using (tx.inputs.isEmpty())
                    "Only one output state should be created when proposing a trade record." using (tx.outputStates.size == 1)
                    val tradeRecord = tx.outputStates.single() as TradeRecordState
                    "The fund manager and broker cannot have the same identity." using (tradeRecord.fund.manager != tradeRecord.broker)
                }
            }
            is Commands.Amend -> {
                requireThat {
                    "Exactly one input should be consumed when amending a trade record." using (tx.inputs.size == 1)
                    val inputState = tx.inputStates.single() as TradeRecordState
                    val outputState = tx.outputStates.single() as TradeRecordState
                    "Output state must have the same linearId as the input state" using (inputState.linearId == outputState.linearId)
                }
            }
            is Commands.Pair -> {
                tx.commands.requireSingleCommand<TradePairContract.Commands.Create>()
            }
            is Commands.Unpair -> {
                tx.commands.requireSingleCommand<TradePairContract.Commands.Cancel>()
            }
            else -> {
                throw IllegalArgumentException("Unsupported command type.")
            }
        }

    }

    interface Commands : CommandData {
        class Propose : TypeOnlyCommandData(), Commands
        class Amend : TypeOnlyCommandData(), Commands
        class Pair : TypeOnlyCommandData(), Commands
        class Unpair : TypeOnlyCommandData(), Commands
    }
}
