package com.drumg.finsbury.state

import net.corda.core.serialization.CordaSerializable

@CordaSerializable
enum class TradeRecordStatus {
    NEW,
    CANCELLED
}
