package com.drumg.finsbury.contract

import com.drumg.finsbury.state.TradePairState
import com.drumg.finsbury.state.TradePairStatus
import com.drumg.finsbury.state.TradeRecordState
import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction

class TradePairContract : Contract {

    companion object {
        const val ID = "com.drumg.finsbury.contract.TradePairContract"
    }

    override fun verify(tx: LedgerTransaction) {
        val command = tx.commands.requireSingleCommand<Commands>()

        when (command.value) {
            is Commands.Create -> {
                requireThat {
                    val inputTradeRecords = tx.inputsOfType(TradeRecordState::class.java)
                    "Two trades must be consumed when creating a trade pair." using (inputTradeRecords.size == 2)
                    "Only one output state should be created when creating a trade pair." using (tx.outputStates.size == 1)
                    val outputTradePair = tx.outputStates.single() as TradePairState
                    "Created transaction must have a PAIRED status." using (outputTradePair.status == TradePairStatus.PAIRED)
                }
            }
            is Commands.Amend -> {
                requireThat {
                    "Exactly one input should be consumed when amending a trade pair." using (tx.inputs.size == 1)
                    "Exactly one output should be created when amending a trade pair." using (tx.outputStates.size == 1)
                    val inputState = tx.inputsOfType<TradePairState>().single()
                    val outputState = tx.outputsOfType<TradePairState>().single()
                    "Output state must have the same linearId as the input state" using (inputState.linearId == outputState.linearId)
                }
            }
            is Commands.Cancel -> {
                requireThat {
                    "Only one input state should be consumed when cancelling a trade pair." using (tx.inputStates.size == 1)
                    "Two trades must be created when cancelling a trade pair." using (tx.outputStates.size == 2)
                    val inputPairLinearIds = tx.inputsOfType<TradePairState>().single().pair.toList().map { it.linearId }.toSet()
                    val outputRecordLinearIds = tx.outputsOfType<TradeRecordState>().map { it.linearId }.toSet()
                    "Two trades must be created with the same trade linearIds from the pair object." using (inputPairLinearIds == outputRecordLinearIds)
                }
            }
            else -> {
                throw IllegalArgumentException("Unsupported command type.")
            }
        }
    }

    interface Commands : CommandData {
        class Create : TypeOnlyCommandData(), Commands
        class Amend : TypeOnlyCommandData(), Commands
        class Cancel : TypeOnlyCommandData(), Commands
    }
}
