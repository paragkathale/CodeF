package com.drumg.finsbury.state

import com.drumg.finsbury.utils.sha256
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table

data class TradeRecordState(val fund: Fund,
                            val provider: String,
                            val role: String,
                            val transactionId: String,
                            val investmentId: String,
                            val tradeDetails: String,
                            val source: String,
                            val broker: Party,
                            val observers: List<Party> = emptyList(),
                            val status: TradeRecordStatus = TradeRecordStatus.NEW,
                            override val linearId: UniqueIdentifier = UniqueIdentifier()) : QueryableState, LinearState {

    fun withStatus(newStatus: TradeRecordStatus): TradeRecordState {
        return copy(status = newStatus)
    }

    fun withDetails(newTradeDetails: String): TradeRecordState {
        return copy(tradeDetails = newTradeDetails)
    }

    override val participants: List<Party> get() = listOfNotNull(fund.manager, fund.administrator, broker)

    override fun generateMappedObject(schema: MappedSchema): PersistentState {
        return when (schema) {
            is TradeRecordSchemaV1 -> TradeRecordSchemaV1.PersistentTradeRecord(sourceHash = sha256(source),
                                                                                provider = provider,
                                                                                role = role,
                                                                                transactionId = transactionId)
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(TradeRecordSchemaV1)
}

object TradeRecordSchema
object TradeRecordSchemaV1 : MappedSchema(
        schemaFamily = TradeRecordSchema.javaClass,
        version = 1,
        mappedTypes = listOf(PersistentTradeRecord::class.java)) {

    @Entity
    @Table(name = "tradeRecords")
    class PersistentTradeRecord(
            @Column(name = "sourceHash", nullable = false)
            var sourceHash: String,

            @Column(name = "transactionId", nullable = false)
            var transactionId: String,

            @Column(name = "provider", nullable = false)
            var provider: String,

            @Column(name = "role", nullable = false)
            var role: String
    ) : PersistentState() {
        constructor(): this("", "", "", "")
    }
}

