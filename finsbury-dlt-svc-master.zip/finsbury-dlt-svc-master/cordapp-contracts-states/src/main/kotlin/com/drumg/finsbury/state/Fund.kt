package com.drumg.finsbury.state

import net.corda.core.identity.Party
import net.corda.core.serialization.CordaSerializable

@CordaSerializable
data class Fund(val accountNumber: String,
                val manager: Party,
                val administrator: Party?)
