package com.drumg.finsbury.state

import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import net.corda.core.serialization.CordaSerializable
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table

data class NotificationState(val type: NotificationTypes,
                             val data: String): QueryableState {
    override val participants: List<Party> = emptyList()

    override fun generateMappedObject(schema: MappedSchema): PersistentState {
        return when (schema) {
            is NotificationSchemaV1 -> NotificationSchemaV1.PersistentNotification(type = type.toString())
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(NotificationSchemaV1)
}

@CordaSerializable
enum class NotificationTypes {
    BATCH_TX_UPLOAD_COMPLETE
}

object NotificationSchema
object NotificationSchemaV1 : MappedSchema(
        schemaFamily = NotificationSchema.javaClass,
        version = 1,
        mappedTypes = listOf(PersistentNotification::class.java)) {

    @Entity
    @Table(name = "notifications")
    class PersistentNotification(
            @Column(name = "type", nullable = false)
            var type: String
    ) : PersistentState() {
        constructor(): this("")
    }
}