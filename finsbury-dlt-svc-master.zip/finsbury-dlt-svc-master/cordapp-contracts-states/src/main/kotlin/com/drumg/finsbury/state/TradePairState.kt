package com.drumg.finsbury.state

import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import net.corda.core.serialization.CordaSerializable
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table

data class TradePairState(val fund: Fund,
                          val broker: Party,
                          val transactionId: String,
                          val pair: Pair<Trade, Trade>,
                          val status: TradePairStatus,
                          override val linearId: UniqueIdentifier = UniqueIdentifier()) : QueryableState, LinearState {
    fun withStatus(newStatus: TradePairStatus): TradePairState {
        return copy(status = newStatus)
    }

    override val participants: List<Party> get() = listOfNotNull(fund.manager, fund.administrator, broker)

    override fun generateMappedObject(schema: MappedSchema): PersistentState = when (schema) {
        is TradePairSchemaV1 -> TradePairSchemaV1.PersistentTradeRecord(transactionId = transactionId)
        else -> throw IllegalArgumentException("Unrecognised schema $schema")
    }

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(TradePairSchemaV1)

}

@CordaSerializable
data class Trade(val details: String,
                 val provider: String,
                 val linearId: UniqueIdentifier)

object TradePairSchema
object TradePairSchemaV1 : MappedSchema(
        schemaFamily = TradePairSchema.javaClass,
        version = 1,
        mappedTypes = listOf(PersistentTradeRecord::class.java)) {

    @Entity
    @Table(name = "tradepairs")
    class PersistentTradeRecord(
            @Column(name = "transactionId", nullable = false)
            var transactionId: String
    ) : PersistentState() {
        constructor(): this("")
    }
}

