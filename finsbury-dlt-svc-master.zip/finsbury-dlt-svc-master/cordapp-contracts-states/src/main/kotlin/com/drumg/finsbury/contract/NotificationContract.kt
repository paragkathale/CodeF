package com.drumg.finsbury.contract

import net.corda.core.contracts.*
import net.corda.core.transactions.LedgerTransaction

class NotificationContract : Contract {
    companion object {
        const val ID = "com.drumg.finsbury.contract.NotificationContract"
    }

    override fun verify(tx: LedgerTransaction) {
        tx.commands.requireSingleCommand<Commands.Raise>()

        requireThat {
            "No input should be consumed when raising a notification" using (tx.inputs.isEmpty())
            "Only one output state should be created when raising a notification" using (tx.outputStates.size == 1)
        }
    }

    interface Commands : CommandData {
        class Raise : TypeOnlyCommandData(), Commands
    }
}
