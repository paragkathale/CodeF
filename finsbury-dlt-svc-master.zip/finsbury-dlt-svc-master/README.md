<p align="center">
  <img src="https://user-images.githubusercontent.com/8850110/55236247-72848380-5227-11e9-9f56-724960bb6fd7.png" alt="DrumG" width="400" />
</p>
 
# Finsbury DLT Service [![CircleCI](https://circleci.com/gh/DrumG/finsbury-dlt-svc.svg?style=shield&circle-token=24d77e1b388ad89d20e77fbeb18074717edf7f6c)](https://circleci.com/gh/DrumG/finsbury-dlt-svc)

This repo contains the source for Finsbury CorDapp and the API to interact with the CorDapp.

This page contains instructions to set up local development environment and API reference. For more information about
design, learning materials, troubleshooting, FAQs, please visit our [wiki page](https://drumg1.atlassian.net/wiki/spaces/ENG/pages/135528516/DLT+Corda).

Table of Contents
=================

  * [Overview](#overview)
  * [Pre-Requisites](#pre-requisites)
  * [Development Usage](#development-usage)
  * [API Reference](#api-reference)
     * [Me](#me)
     * [Peers](#peers)
     * [Trade Records](#trade-records)
     * [Trade Pairs](#trade-pairs)
     * [Notifications](#notifications)

# Overview

![DLT Service Overview](https://user-images.githubusercontent.com/8850110/55471572-f365c580-5601-11e9-924f-a033c9a01e7c.png)

`clients/src/main/kotlin/com/drumg/finsbury/webserver/` defines a simple Spring webserver that connects to a node via RPC and
allows you to interact with the node over HTTP.

The API endpoints are defined here:

    clients/src/main/kotlin/com/drumg/finsbury/webserver/controller/*Controller.kt

The DLT Service endpoints are served on:

    http://localhost:10050/<endpoint-path>


# Pre-Requisites

See [Getting set up for CorDapp development](https://docs.corda.net/getting-set-up.html).


# Development Usage

## Running the nodes

### Via IntelliJ

Run the `Run Finsbury CorDapp` run configuration. By default, it connects to the node with RPC address `localhost:10006`
with the username `user1` and the password `test`, and serves the webserver on port `localhost:10050`.

### Via the command line

*This is the preferred way to run Corda locally* since it starts each node in a separate shell which allows you to
interact with each nodes separately.

Building the CorDapp:

    ./gradlew deployNodes

Run the CorDapp:

    build/nodes/runnodes

For more details, see https://docs.corda.net/tutorial-cordapp.html#running-the-example-cordapp.

## Interacting with the Corda nodes using DLT Service

### Via IntelliJ

*This is the preferred way to run DLT Service locally* since the run configuration in IntelliJ can be run in debug mode
and allows debugging and setting up code break points.

Run the `Run Finsbury DLT Service` run configuration. By default, it connects to the node with RPC address `localhost:10006`
with the username `user1` and the password `test`, and serves the webserver on port `localhost:10050`.

### Via the command line

Run the `runTemplateServer` Gradle task. By default, it connects to the node with RPC address `localhost:10006` with
the username `user1` and the password `test`, and serves the webserver on port `localhost:10050`.


# API Reference

## Me

### GET /me

Returns the node's name and role.

#### Example Response Body
```json
{
    "me": {
        "name": "Corda_IM",
        "role": "InvestmentManager"
    }
}
```

## Peers

### GET /peers

Returns all parties registered with the `NetworkMapService`.

#### Example Response Body
```json
{
    "peers": [
        {
            "name": "Corda_CU",
            "role": "Custodian"
        },
        {
            "name": "Corda_FA",
            "role": "FundAdmin"
        }
    ]
}
```

## Trade Records

### POST /tradeRecords

Submits one or more trade records to other participants on the DLT.

#### Example Request Body
```json
{
    "tradeRecords": [
        {
            "fund": {
                "accountNumber": "P 39009",
                "manager": "Corda_IM",
                "administrator": "Corda_FA"
            },
            "provider": "Corda_IM",
            "role": "InvestmentManager",
            "investmentId": "US0236081024",
            "transactionId": "2145936887",
            "tradeDetails": "{\"type\":\"BUY\",\"tradeDate\":\"20181106\",\"settleDate\":\"20181108\",\"tradeCurrency\":\"USD\",\"settleCurrency\":\"USD\",\"fxRate\":\"1.0\",\"quantity\":\"27544\",\"price\":\"64.86340964\",\"commissions\":\"35.8072\",\"fees\":[{\"type\":\"SEC\",\"value\":\"0.0\"},{\"type\":\"other\",\"value\":\"0.0\"}],\"netTradeAmount\":\"1786633.56\",\"grossTradeAmount\":\"1786597.76\",\"clearingBroker\":{\"identifiers\":[{\"type\":\"code\",\"value\":\"GS\"},{\"type\":\"custom\",\"name\":\"ExecutingBrokerLongName\",\"value\":\"Goldman Sachs\"}]},\"executingBroker\":{\"identifiers\":[{\"type\":\"code\",\"value\":\"JPM\"}]}}",
            "source": "{\"provider\":\"Corda_IM\",\"received\":\"2018-12-31T17:35:00Z\",\"transport\":\"SFTP\",\"protocol\":\"CSV\",\"storage\":{\"provider\":\"Azure\",\"url\":\"https://aqr.drumg.blob.core.windows.net/finsbury/20181231-DEFGLUX-JPM.csv\",\"hash\":\"0x268936593782349AB3\"}}",
            "broker": "Corda_CU",
            "status": "NEW"
        }
    ]
}
```

### PUT /tradeRecords

Amends one or more trade records on the DLT using the supplied `dgId`s.

#### Example Request Body
```json
{
    "tradeRecords": [
        {
            "fund": {
                "accountNumber": "P 39009",
                "manager": "Corda_IM",
                "administrator": "Corda_FA"
            },
            "provider": "Corda_IM",
            "role": "InvestmentManager",
            "investmentId": "US0236081024",
            "transactionId": "2145936887",
            "tradeDetails": "{\"type\":\"BUY\",\"tradeDate\":\"20181106\",\"settleDate\":\"20181108\",\"tradeCurrency\":\"USD\",\"settleCurrency\":\"USD\",\"fxRate\":\"1.0\",\"quantity\":\"27544\",\"price\":\"64.86340964\",\"commissions\":\"35.8072\",\"fees\":[{\"type\":\"SEC\",\"value\":\"0.0\"},{\"type\":\"other\",\"value\":\"0.0\"}],\"netTradeAmount\":\"1786633.56\",\"grossTradeAmount\":\"1786597.76\",\"clearingBroker\":{\"identifiers\":[{\"type\":\"code\",\"value\":\"GS\"},{\"type\":\"custom\",\"name\":\"ExecutingBrokerLongName\",\"value\":\"Goldman Sachs\"}]},\"executingBroker\":{\"identifiers\":[{\"type\":\"code\",\"value\":\"JPM\"}]}}",
            "source": "{\"provider\":\"Corda_IM\",\"received\":\"2018-12-31T17:35:00Z\",\"transport\":\"SFTP\",\"protocol\":\"CSV\",\"storage\":{\"provider\":\"Azure\",\"url\":\"https://aqr.drumg.blob.core.windows.net/finsbury/20181231-DEFGLUX-JPM.csv\",\"hash\":\"0x268936593782349AB3\"}}",
            "broker": "Corda_CU",
            "status": "CANCELLED",
            "dgId": "853e99dd-c380-4e91-8ccd-680bb64ed0db"
        }
    ]
}
```

### GET /tradeRecords
Returns a list of trade records matching the query criteria provided.

Query parameters:

| Parameter       | Description |
|-----------------|-------------|
| `transactionId` | Filters trades by a given transaction ID. 
| `provider`      | Filters trades by a given provider. Example value: `Corda_IM`. 
| `role`          | Filters trades by a given role. Possible values: `Custodian`, `InvestmentManager`.
| `sourceHash`    | Filters trades by the SHA-256 hash of the stringified source object corresponding to a single file upload.
| `includeHistory`| Include historical data in response. Requires at least one other query parameter to be specified. Default value: `false`.

This endpoint supports pagination using the `page` and `pageSize` query parameters. The default page size is 10000 and if the page is omitted the endpoint returns the 1st page.
The maximum supported page size is 10000.

#### Example Response body
```json
{
    "tradeRecords": [
        {
            "fund": {
                "accountNumber": "P 39009",
                "manager": "Corda_IM",
                "administrator": "Corda_FA"
            },
            "provider": "Corda_IM",
            "role": "InvestmentManager",
            "investmentId": "US0236081024",
            "transactionId": "2145936887",
            "tradeDetails": "{\"type\":\"BUY\",\"tradeDate\":\"20181106\",\"settleDate\":\"20181108\",\"tradeCurrency\":\"USD\",\"settleCurrency\":\"USD\",\"fxRate\":\"1.0\",\"quantity\":\"27544\",\"price\":\"64.86340964\",\"commissions\":\"35.8072\",\"fees\":[{\"type\":\"SEC\",\"value\":\"0.0\"},{\"type\":\"other\",\"value\":\"0.0\"}],\"netTradeAmount\":\"1786633.56\",\"grossTradeAmount\":\"1786597.76\",\"clearingBroker\":{\"identifiers\":[{\"type\":\"code\",\"value\":\"GS\"},{\"type\":\"custom\",\"name\":\"ExecutingBrokerLongName\",\"value\":\"Goldman Sachs\"}]},\"executingBroker\":{\"identifiers\":[{\"type\":\"code\",\"value\":\"JPM\"}]}}",
            "source": "{\"provider\":\"Corda_IM\",\"received\":\"2018-12-31T17:35:00Z\",\"transport\":\"SFTP\",\"protocol\":\"CSV\",\"storage\":{\"provider\":\"Azure\",\"url\":\"https://aqr.drumg.blob.core.windows.net/finsbury/20181231-DEFGLUX-JPM.csv\",\"hash\":\"0x268936593782349AB3\"}}",
            "broker": "Corda_CU",
            "status": "NEW",
            "stateRef": "74306BD03A7F3C1EEA692A0E18A7347793110942CB4A3A488817EFEC3CD941CF[0]",
            "dgCreatedTimestamp": "2019-03-21T10:35:07.913Z",
            "dgConsumedTimestamp": "2019-03-22T10:35:07.913Z",
            "dgId": "b3075167-071d-4c7f-b9ee-5b56430912c7"
        }
    ]
}
```

## Trade Pairs

### POST /tradePairs

Creates one or more trade pairs and share with other participants on the DLT.

#### Example Request Body
```json
{
    "tradePairs": [
        {
            "fund": {
                "accountNumber": "P 30093",
                "manager": "Corda_IM",
                "administrator": "Corda_FA"
            },
            "pair": {
                "first": {
                    "details": "{\"fund\":{\"manager\":\"Corda_IM\",\"identifiers\":{\"adminAccount\":\"Fund C\",\"clearingAccountNumber\":\"ABC\",\"locationAccount\":\"USAALK1\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"TransID\":\"511279368\",\"fundCode\":\"USAALK1\"}},\"investment\":{\"identifiers\":{\"CUSIP\":\"GOOG\",\"Corda_IMID\":\"USAALK1\",\"securityName\":\"Alphabet\"}},\"details\":{\"tradeDate\":\"2019-2-16 12:00 AM\",\"settleDate\":\"2019-2-20 12:00 AM\",\"quantity\":\"37700\",\"price\":\"8.88\",\"commissions\":\"377\",\"fees\":{},\"netTradeAmount\":\"285389\",\"clearingBroker\":{\"code\":\"Corda_CU\"},\"executingBroker\":{\"code\":\"DB\"}},\"status\":{\"lastUpdate\":\"2018-11-19 16:38:09.427\",\"shortCode\":\"ACCT\"}}",
                    "provider": "Corda_IM",
                    "dgId": "9a85d660-cacc-45b5-8e64-f7073a63dccc"
                },
                "second": {
                    "details": "{\"fund\":{\"manager\":\"Corda_IM\",\"identifiers\":{\"adminAccount\":\"Fund C\",\"clearingAccountNumber\":\"ABC\",\"locationAccount\":\"USAALK1\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"TransID\":\"511279368\",\"fundCode\":\"USAALK1\"}},\"investment\":{\"identifiers\":{\"CUSIP\":\"GOOG\",\"Corda_IMID\":\"USAALK1\",\"securityName\":\"Alphabet\"}},\"details\":{\"tradeDate\":\"2019-2-16 12:00 AM\",\"settleDate\":\"2019-2-20 12:00 AM\",\"quantity\":\"37700\",\"price\":\"8.88\",\"commissions\":\"377\",\"fees\":{},\"netTradeAmount\":\"285389\",\"clearingBroker\":{\"code\":\"Corda_CU\"},\"executingBroker\":{\"code\":\"DB\"}},\"status\":{\"lastUpdate\":\"2018-11-19 16:38:09.427\",\"shortCode\":\"ACCT\"}}",
                    "provider": "Corda_CU",
                    "dgId": "b5432adf-5801-45eb-aff3-2c0135f8379b"
                }
            },
            "transactionId": "511279368",
            "broker": "Corda_CUS",
            "status": "PAIRED"
        }
    ]
}
```

### PUT /tradePairs

Amends or cancels one or more trade pairs on the DLT using the given `dgId`s.
If status is `PAIRED` the endpoint will amend the existing trade pair, if status is `CANCELLED` the endpoint will cancel the trade pair and break it up into two trade records. 

#### Example Request Body
```json
{
    "tradePairs": [
        {
            "fund": {
                "accountNumber": "P 30093",
                "manager": "Corda_IM",
                "administrator": "Corda_FA"
            },
            "pair": {
                "first": {
                    "details": "{\"fund\":{\"manager\":\"Corda_IM\",\"identifiers\":{\"adminAccount\":\"Fund C\",\"clearingAccountNumber\":\"ABC\",\"locationAccount\":\"USAALK1\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"TransID\":\"511279368\",\"fundCode\":\"USAALK1\"}},\"investment\":{\"identifiers\":{\"CUSIP\":\"GOOG\",\"Corda_IMID\":\"USAALK1\",\"securityName\":\"Alphabet\"}},\"details\":{\"tradeDate\":\"2019-2-16 12:00 AM\",\"settleDate\":\"2019-2-20 12:00 AM\",\"quantity\":\"37700\",\"price\":\"8.88\",\"commissions\":\"377\",\"fees\":{},\"netTradeAmount\":\"285389\",\"clearingBroker\":{\"code\":\"Corda_CU\"},\"executingBroker\":{\"code\":\"DB\"}},\"status\":{\"lastUpdate\":\"2018-11-19 16:38:09.427\",\"shortCode\":\"ACCT\"}}",
                    "provider": "Corda_IM",
                    "dgId": "9a85d660-cacc-45b5-8e64-f7073a63dccc"
                },
                "second": {
                    "details": "{\"fund\":{\"manager\":\"Corda_IM\",\"identifiers\":{\"adminAccount\":\"Fund C\",\"clearingAccountNumber\":\"ABC\",\"locationAccount\":\"USAALK1\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"TransID\":\"511279368\",\"fundCode\":\"USAALK1\"}},\"investment\":{\"identifiers\":{\"CUSIP\":\"GOOG\",\"Corda_IMID\":\"USAALK1\",\"securityName\":\"Alphabet\"}},\"details\":{\"tradeDate\":\"2019-2-16 12:00 AM\",\"settleDate\":\"2019-2-20 12:00 AM\",\"quantity\":\"37700\",\"price\":\"8.88\",\"commissions\":\"377\",\"fees\":{},\"netTradeAmount\":\"285389\",\"clearingBroker\":{\"code\":\"Corda_CU\"},\"executingBroker\":{\"code\":\"DB\"}},\"status\":{\"lastUpdate\":\"2018-11-19 16:38:09.427\",\"shortCode\":\"ACCT\"}}",
                    "provider": "Corda_CU",
                    "dgId": "b5432adf-5801-45eb-aff3-2c0135f8379b"
                }
            },
            "broker": "Corda_CUS",
            "transactionId": "511279368",
            "status": "PAIRED",
            "dgId": "b3075167-071d-4c7f-b9ee-5b56430912c7"
        }
    ]
}
```

### GET /tradePairs
Returns a list of trade pairs matching the query criteria provided.

Query parameters:

| Parameter       | Description |
|-----------------|-------------|
| `transactionId` | Filters pairs by a given transaction ID. 
| `includeHistory`| Include historical data in response. Requires at least one other query parameter to be specified. Default value: `false`.

This endpoint supports pagination using the `page` and `pageSize` query parameters. The default page size is 10000 and if the page is omitted the endpoint returns the 1st page.
The maximum supported page size is 10000.

#### Example Response body
```json
{
    "tradePairs": [
        {
            "fund": {
                "accountNumber": "P 30093",
                "manager": "Corda_IM",
                "administrator": "Corda_FA"
            },
            "pair": {
                "first": {
                    "details": "{\"fund\":{\"manager\":\"Corda_IM\",\"identifiers\":{\"adminAccount\":\"Fund C\",\"clearingAccountNumber\":\"ABC\",\"locationAccount\":\"USAALK1\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"TransID\":\"511279368\",\"fundCode\":\"USAALK1\"}},\"investment\":{\"identifiers\":{\"CUSIP\":\"GOOG\",\"Corda_IMID\":\"USAALK1\",\"securityName\":\"Alphabet\"}},\"details\":{\"tradeDate\":\"2019-2-16 12:00 AM\",\"settleDate\":\"2019-2-20 12:00 AM\",\"quantity\":\"37700\",\"price\":\"8.88\",\"commissions\":\"377\",\"fees\":{},\"netTradeAmount\":\"285389\",\"clearingBroker\":{\"code\":\"Corda_CU\"},\"executingBroker\":{\"code\":\"DB\"}},\"status\":{\"lastUpdate\":\"2018-11-19 16:38:09.427\",\"shortCode\":\"ACCT\"}}",
                    "provider": "Corda_IM",
                    "dgId": "cea662ff-1a45-4d7d-bf0a-4dc2959382cb"
                },
                "second": {
                    "details": "{\"fund\":{\"manager\":\"Corda_IM\",\"identifiers\":{\"adminAccount\":\"Fund C\",\"clearingAccountNumber\":\"ABC\",\"locationAccount\":\"USAALK1\"}},\"transaction\":{\"type\":\"N\",\"identifiers\":{\"TransID\":\"511279368\",\"fundCode\":\"USAALK1\"}},\"investment\":{\"identifiers\":{\"CUSIP\":\"GOOG\",\"Corda_IMID\":\"USAALK1\",\"securityName\":\"Alphabet\"}},\"details\":{\"tradeDate\":\"2019-2-16 12:00 AM\",\"settleDate\":\"2019-2-20 12:00 AM\",\"quantity\":\"37700\",\"price\":\"8.88\",\"commissions\":\"377\",\"fees\":{},\"netTradeAmount\":\"285389\",\"clearingBroker\":{\"code\":\"Corda_CU\"},\"executingBroker\":{\"code\":\"DB\"}},\"status\":{\"lastUpdate\":\"2018-11-19 16:38:09.427\",\"shortCode\":\"ACCT\"}}",
                    "provider": "Corda_CU",
                    "dgId": "05cac519-71de-403e-b143-bec6154d2e1e"
                }
            },
            "broker": "Corda_CUS",
            "transactionId": "511279368",
            "status": "PAIRED",
            "stateRef": "74306BD03A7F3C1EEA692A0E18A7347793110942CB4A3A488817EFEC3CD941CF[0]",
            "dgCreatedTimestamp": "2019-03-21T10:35:07.913Z",
            "dgConsumedTimestamp": null,
            "dgId": "8c691d60-b150-4a98-ad86-930fe332e32a"
        }
    ]
}
```

## Notifications

### POST /notifications/batch-tx-upload-complete

Notifies other participants on the DLT that a file has been successfully persisted.

#### Example Request Body
```json
{
    "source": "{\"provider\":\"Corda_IM\",\"received\":\"2018-12-31T17:35:00Z\",\"transport\":\"SFTP\",\"protocol\":\"CSV\",\"storage\":{\"provider\":\"Azure\",\"url\":\"https://aqr.drumg.blob.core.windows.net/finsbury/20181231-DEFGLUX-JPM.csv\",\"hash\":\"0x268936593782349AB3\"}}",
    "recipients": ["Corda_IM", "Corda_CU"]
}
```
