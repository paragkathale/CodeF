package com.drumg.pubsub.message

import com.drumg.utils.pubsub.message.BaseMessage

class TestMessage (body: String): BaseMessage ("1.0.0", body) {}