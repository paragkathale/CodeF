package com.drumg.pubsub.controller

import com.drumg.pubsub.publish.BusDispatcher
import io.vertx.core.json.Json
import io.vertx.core.json.JsonObject

import org.slf4j.LoggerFactory
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/publish")
class PubSubTestController(private val dispatcher: BusDispatcher) {

    companion object {
        private val logger = LoggerFactory.getLogger(PubSubTestController::class.java)
    }

    class TestStartStatus(val testId: String = "")

    @GetMapping(produces = arrayOf(MediaType.APPLICATION_JSON_VALUE))
    @ResponseBody
    private fun callPublisher(
            @RequestParam(required = true) testId: String,
            @RequestParam(required = true) messageCount: Int

    ): ResponseEntity<TestStartStatus> {

        logger.info("Test initiated with testId:" + testId + " and messageCount: " + messageCount)

        dispatcher.publishToServiceBus(testId, messageCount)

        return ResponseEntity.ok(TestStartStatus(testId))
    }
}