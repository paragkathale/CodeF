package com.drumg.pubsub.publish

import com.drumg.pubsub.message.TestMessage
import com.drumg.utils.pubsub.factory.MessageQueueFactory
import com.drumg.utils.pubsub.factory.impl.AmqpMessageQueueFactory
import com.drumg.utils.pubsub.link.Publisher

import io.vertx.core.json.JsonObject
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import java.util.*

import javax.annotation.PostConstruct

@Component
class BusDispatcher (@Value("\${drumg.pubsub.connectstring}") private val connectionString: String,
                     @Value ("\${topic}") private val topic: String) {
    private lateinit var factory: MessageQueueFactory
    private lateinit var publisher: Publisher

    companion object {
        private val logger = LoggerFactory.getLogger(BusDispatcher::class.java)
    }

    @PostConstruct
    fun init() {
        factory = AmqpMessageQueueFactory(connectionString)
        publisher = factory.createPublisher(topic)
    }

    public fun publishToServiceBus(testId: String, messageCount: Int) {

        for (msgNumber in 1..messageCount) {
            val message: JsonObject = createMessage(testId, msgNumber)

            logger.info("Passing message to Publisher: " + message.toString())

            publisher.send(TestMessage(body = message.toString()))
        }

    }

    private fun createMessage(id: String, index: Int): JsonObject {
       return JsonObject(mapOf(
                "testId" to id,
                "sequenceNum" to index.toString(),
                "source" to "dg-pubsub-java-test-svc",
                "time" to Date().toString()
        ))
    }

}