
<p align="center">
  <img src="https://www.drumg.com/wp-content/themes/drumg/dist/img/logo.png" alt="DrumG" width="500">
</p>

# dg-pubsub-java-test-svc

PubSub java test repo to test reliablity and duribility of the Azure Service Bus

# Pre-Requisites

This service contains best-practices and defaults that any DrumG Node service should have.  Refer to 
[Service Standards](https://drumg1.atlassian.net/wiki/spaces/ENG/pages/111280183/Service+Standards) for
the comprehensive list of standards, both in code implementation and in documentation.

This service implements:
- README documentation
- CHANGELOG documentation
- Proper files naming convention
- Proper directory structure
- Must-have npm script targets and default commands
- Must-have systemd service file and script
- Default healthcheck end-point
- Default process shutdown handling
- CircleCI configuration
- Use of common DrumG library package, e.g., logger
- Typescript linting
- SonarCloud integration
- Test coverage reporting

# Service Information

| Attribute | Info |
| --------- | ---- |
| Owner | DrumG Engineering Team (Must be a named individual for other services) |
| Co-Owner | DrumG Engineering Team (Must be a named individual for other services) |
| Service Port | 18900 |
| Network Zone | App network (choice of DMZ, User zone, App zone and DLT zone) |

# API Reference

## GET /healthcheck

Returns status 200 "OK" if the service is responsive.

### Example Response body
```json
{
    "status": "ok",
    "msg": "I am alive" 
}
```

# Development Usage

## Install

Obtain an API token from https://packagecloud.io for access to DrumG's private package repo.  Then run:

    export PKGCLOUD_NPM_TOKEN=4022889d5687e109d5e1b6f69a2efd019d2d81b515acf62d
    ./gradew startServer

### Commands

- `./gradew build` to build
