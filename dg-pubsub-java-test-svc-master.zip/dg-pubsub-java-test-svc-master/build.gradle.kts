import org.gradle.kotlin.dsl.*

plugins {
    val kotlinVersion = "1.3.21"
    id("org.springframework.boot") version "2.1.2.RELEASE"
    id("org.jetbrains.kotlin.jvm") version kotlinVersion
    id("org.jetbrains.kotlin.plugin.spring") version kotlinVersion
    id("org.jetbrains.kotlin.plugin.jpa") version kotlinVersion
    id("io.spring.dependency-management") version "1.0.6.RELEASE"
    // id("io.vertx.vertx-plugin") version "0.4.0"
    jacoco
}

apply (plugin = "kotlin")
apply (plugin = "org.sonarqube")

buildscript {
    repositories {
        mavenLocal()
        mavenCentral()
    }

    dependencies {
        classpath ("org.sonarsource.scanner.gradle:sonarqube-gradle-plugin:2.7")
    }

}

version = "1.0.0-SNAPSHOT"

tasks.withType<Test> {
    useJUnitPlatform()
}

repositories {
    mavenCentral()
    maven (url = "https://packagecloud.io/priv/4022889d5687e109d5e1b6f69a2efd019d2d81b515acf62d/drumg/core-java/maven2" )
}

dependencies {
    compile("org.springframework.boot:spring-boot-starter-web") {
        exclude (module = "spring-boot-starter-logging")
    }
    compile("org.jetbrains.kotlin:kotlin-stdlib-jdk8")
    compile("org.jetbrains.kotlin:kotlin-reflect")
    compile("io.vertx:vertx-web-client:3.4.2")
    compile("com.drumg.utils:pubsub:3.0.1")

    testCompile("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
}

sourceSets {
    main{
        getByName("main").java.srcDirs("src/main/kotlin")
    }
}

jacoco {
    // Using Snapshot version. No release yet for bug: https://github.com/jacoco/jacoco/issues/763
    toolVersion = "0.8.3"
}

tasks.jacocoTestReport {
    reports {
        xml.isEnabled = true
        csv.isEnabled = false
    }
}

tasks.register("startServer", JavaExec::class) {
    main = "com.drumg.pubsub.AppServer"
    classpath = sourceSets["main"].runtimeClasspath
    args = listOf("--server.port=18904")
}
