#!/usr/bin/env bash
set -x

#To be parameterised
APP_NAME=dg-pubsub-java-test-svc
SERVICE_DIR_PREFIX=/opt
SERVICE_DIR=${SERVICE_DIR_PREFIX}/
ARCHIVE_DIR=${SERVICE_DIR}/versions
DEPLOY_SCRIPT=${SERVICE_DIR}/scripts/deploy.sh

AZ_CI_STORAGE_ACCOUNT=devfin00deploy01

VERSION_FILE=version.info
INSTALLED_VERSION_FILE=${SERVICE_DIR}/${VERSION_FILE}

#Make work directory
mkdir -p /tmp/${APP_NAME}-working
cd /tmp/${APP_NAME}-working && rm -f *jar

#{APP_NAME}-semaphore

function installAzureCLI() {
    az_path=$(which az || true)

    if [[ ! -x "${az_path}" ]]; then
        sudo apt-get install apt-transport-https lsb-release software-properties-common dirmngr -y

        AZ_REPO=$(lsb_release -cs)
        echo "deb [arch=amd64] https://packages.microsoft.com/repos/azure-cli/ $AZ_REPO main" | \
            sudo tee /etc/apt/sources.list.d/azure-cli.list

        sudo apt-key --keyring /etc/apt/trusted.gpg.d/Microsoft.gpg adv \
                --keyserver packages.microsoft.com \
                --recv-keys BC528686B50D79E339D3721CEB3E94ADBE1229CF

        sudo apt-get update
        sudo apt-get install azure-cli
    fi
}

function downloadBlob() {
	az storage blob download \
		--container-name ${APP_NAME} \
		--file $1 \
		--name $1 \
		--account-name ${AZ_CI_STORAGE_ACCOUNT} \
		--auth-mode login
}

installAzureCLI
az login --identity

downloadBlob ${VERSION_FILE}
result=$?

if [ $result -eq 0 ]; then
#--version file is present--
  echo -e "Version retrieved.\n"
  retrieved_version=$(cat "${VERSION_FILE}")
  current_version=$(cat "${INSTALLED_VERSION_FILE}")
  echo "Retrieved version: $retrieved_version"
  echo "Current version:   $current_version"
  #Pull down the latest file and place it in the correct place in filesystem archive
  if ! [[ "$retrieved_version" == "$current_version" ]]; then
#An update has occurred 
    mv "${INSTALLED_VERSION_FILE}" "${INSTALLED_VERSION_FILE}.previous" 
    echo "$retrieved_version" > "${INSTALLED_VERSION_FILE}"
  #Call deploy
  source ${DEPLOY_SCRIPT}
  fi
  #Otherwise no new version - no action
else
#Nothing to do
  echo -e "No version info present. Is the CircleCI build CD aware?\n"
fi
