# Finsbury Docker Local

Build all finsbury images locally and run them using `docker-compose` completely offline. 

The script runs a full Finsbury cell + an additional Corda node for local testing:
- :white_check_mark: SFTP server
- :white_check_mark: ActiveMQ for messaging (2 instances for DMZ & APP)
- :white_check_mark: Azurite (Azure Storage Simulator)
- :white_check_mark: Two Corda nodes
- :white_check_mark: All Finsbury services

## Directory structure

    .
    ├── cells                   # Cell-sepcific application config & environment variable files
    ├── docker                  # Docker files for building images
    ├── scripts                 # Automation scripts for building and starting services
    ├── test                    # Scripts for local testing and resource setup
    ├── Makefile
    └── README.md

## Prerequisites

- Install Git, Node >= 8 & Docker >= 18.09.0
- Latest [JDK 8](https://docs.corda.net/getting-set-up.html). To switch between multiple versions (e.g. 11 vs 8) use the following instructions (http://www.jenv.be/)
- Export PKGCLOUD_NPM_TOKEN

## Build Docker images locally

Run this script at the first time and every time you want to build from latest `master` branch. To build from a different branch, cd to the repository `repo/service_name` and checkout the branch with `git checkout branch_name` before running `build-all.sh`.

```
make build-all
```

## Run services

### To start all services

```
make start-all
```

After starting the services, run the `setup` task to create test resources e.g. blob containers etc

```
make resource-setup
```

### To stop all services

```
make stop-all
```

### To start / stop / restart a service

`cd` to the cell directory (e.g. `cd cells/im` and run the following:

```
docker-compose stop fileio
docker-compose start fileio
docker-compose restart fileio
```

For services that are not yet dockerized, use `fkill` to stop services by port number:

```
# stop finsbury-dlt-svc
fkill :10050
```

## Check running services

```
docker ps
```

## To see logs

```
# view logs in IM cell
make logs-im

# view logs in CU cell
make logs-cu
```

For services that are not yet dockerized, use `tail` or other program to read the log files under `tmp` directory:

```
# view finsbury-dlt-svc logs
tail -f tmp/finsbury-dlt-svc.log
```

## Accessing the Services

### Testing the application

Run IM file upload with the following command:

```
make upload-test
```

### ActiveMQ Console

Log in with user `admin` password `admin`:
- DMZ instance: http://localhost:8161
- APP instance: http://localhost:18161

### Azurite (Azure Storage Emulator)

1. Download and run [Azure Storage Explorer](https://azure.microsoft.com/en-us/features/storage-explorer/)
2. Connect to Storage Account with connection string:

```
DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://host.docker.internal:10000/devstoreaccount1;QueueEndpoint=http://host.docker.internal:10001/devstoreaccount1;TableEndpoint=http://host.docker.internal:10002/devstoreaccount1
```

### SFTP server

Login with `sftp -i ./keys/id_rsa_key -P 2222 foo@localhost`
