#!/usr/bin/env bash
mkdir -p repos
cd repos

services=(finsbury-dlt-svc)

for service in ${services[@]}
 	do
 		if [ -d $service ]; then
            echo "Repo $service exists, pulling"
            cd $service && git pull
        else 
            echo "Cloning $service"
            git clone git@github.com:DrumG/$service.git
            cd $service 
        fi

        echo "Building $service"
        ./gradlew :clients:build
        docker build --build-arg PKGCLOUD_NPM_TOKEN --build-arg JAR_FILE=./clients/build/libs/finsbury-dlt-svc-0.1.jar -f ../../docker/java.Dockerfile . -t drumg/$service

        cd ..
 	done

echo "Successfully built images!"
