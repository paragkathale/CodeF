echo Stopping dlt-svc
fkill :10050
fkill :10150
