#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

cells=(im cu)

chmod 400 $DIR/../cells/common/keys/*

for cell in ${cells[@]}
do
    docker-compose -f $DIR/../cells/$cell/docker-compose.yml up -d
    echo Started docker services in $cell cell.
done

# start corda
$DIR/start-corda.sh

# start dlt-svc
echo Starting dlt-svc
$DIR/start-dlt-svc.sh

echo All services started.
echo Run "docker-compose logs -f" to view logs.
