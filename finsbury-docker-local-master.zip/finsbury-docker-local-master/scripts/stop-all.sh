#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

cells=(im cu)

for cell in ${cells[@]}
do
    echo Stopping docker services in $cell cell
    docker-compose -f $DIR/../cells/$cell/docker-compose.yml down
done

fkill_path=$(which fkill || true)

if [[ ! -x "${fkill_path}" ]]; then
    npm i -g fkill-cli
fi

#stop dlt-svc
$DIR/stop-dlt-svc.sh

# stop corda
$DIR/stop-corda.sh

echo All services stopped successfully.
