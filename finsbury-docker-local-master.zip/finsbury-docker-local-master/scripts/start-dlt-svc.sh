#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
JAR_FILE=$DIR/../repos/finsbury-dlt-svc/clients/build/libs/finsbury-dlt-svc-0.1.jar

cells=(im cu)

for cell in ${cells[@]}
 	do
        CELL_DIR=$DIR/../cells/$cell
        CONF_FILE=$CELL_DIR/config/dlt-localhost.properties
        TMP_DIR=$CELL_DIR/tmp

        mkdir -p $TMP_DIR
        cd $TMP_DIR
        cp $CONF_FILE $TMP_DIR/application.properties
        java -jar ${JAR_FILE} 2>&1 >> finsbury-dlt-svc.log &
        
        echo "Started DLT Service in ${cell} cell."
        cd -
 	done
