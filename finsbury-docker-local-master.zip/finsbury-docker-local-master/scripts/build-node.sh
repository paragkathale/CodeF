#!/usr/bin/env bash
mkdir -p repos
cd repos

services=(finsbury-fileio-svc finsbury-trade-svc finsbury-dictionary-svc finsbury-match-svc finsbury-delivery-svc)

for service in ${services[@]}
 	do
 		if [ -d $service ]; then
            echo "Repo $service exists, pulling"
            cd $service && git pull
        else 
            echo "Cloning $service"
            git clone git@github.com:DrumG/$service.git
            cd $service 
        fi

        echo "Building $service"
        docker build --build-arg PKGCLOUD_NPM_TOKEN -f ../../docker/node.Dockerfile . -t drumg/$service

        cd ..
 	done

echo "Successfully built images!"
