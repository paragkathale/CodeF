#!/usr/bin/env bash
mkdir -p repos
cd repos

service=finsbury-dlt-svc

if [ -d $service ]; then
    echo "Repo $service exists, pulling"
    cd $service && git pull
else 
    echo "Cloning $service"
    git clone git@github.com:DrumG/$service.git
    cd $service 
fi

echo "Building $service cordapps"
./gradlew deployNodes
docker build -f ../../docker/corda.Dockerfile . -t drumg/finsbury-cordapps

echo "Successfully built images!"
