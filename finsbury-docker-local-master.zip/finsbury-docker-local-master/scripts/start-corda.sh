#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

function startCordaNode() {
    nodeName=$1

    cd $DIR/../repos/finsbury-dlt-svc/build/nodes/$nodeName
    java -jar corda.jar 2>&1 >> $DIR/../tmp/$nodeName.log &
    cd -
    echo Started corda node $nodeName.
}

mkdir -p $DIR/../tmp
startCordaNode "Corda_IM"
startCordaNode "Corda_CU"

echo Wait until corda starts in 60 sec
sleep 30
echo Wait until corda starts in 30 sec
sleep 30
