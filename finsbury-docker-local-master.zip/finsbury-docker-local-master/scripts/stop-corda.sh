echo Stopping corda
fkill :10006
fkill :10013
