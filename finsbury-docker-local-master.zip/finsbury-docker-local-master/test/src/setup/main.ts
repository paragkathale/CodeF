import {createBlobContainer, createTable} from "./blob-storage-setup";
import * as config from "./config.json"

createBlobContainer('upload', config.im.storage.connectionString)
createBlobContainer('output', config.im.storage.connectionString)
createBlobContainer('upload', config.cu.storage.connectionString)
createBlobContainer('output', config.cu.storage.connectionString)

createTable('ParticipationMap', config.im.storage.connectionString)
createTable('ParticipationMap', config.cu.storage.connectionString)
