import { AzureContainerUtils, AzureTableUtils } from '@drumg/cloud-services';
import {logger} from '@drumg/long-island-tea';

const createBlobContainer = async (containerName: string, connectionString: string) => {
    const utils = new AzureContainerUtils(containerName, connectionString);
    await utils.ensureContainer()
    logger.info(`Container ${containerName} has been created or already exists.`)
}

const createTable = async (tableName: string, connectionString: string) => {
    const utils = new AzureTableUtils(tableName, connectionString);
    await utils.ensureTable()
    logger.info(`Table ${tableName} has been created or already exists.`)
}

export { createBlobContainer, createTable }
