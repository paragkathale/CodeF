import {Publisher, MessageQueueFactory, BaseMessage} from '@drumg/cloud-services';
import {logger} from '@drumg/long-island-tea';

class FileMessage extends BaseMessage {
    public static create(body: string) {
        return new FileMessage(body);
    }
    private constructor(body: string) {
        // FIXME Message encoding will be handled automatically in the next version of cloud-services.
        // @ts-ignore
        super('1.0.0', {
            typecode: 0x75,
            content: Buffer.from(body)
        });
    }
}

export class FileMessagePublisher {
    private readonly topic: string;
    private readonly queueSuffix: string;
    private readonly messageQueueFactory: MessageQueueFactory;
    private publisherPromise!: Promise<Publisher>;

    constructor(queueSuffix: string, topic: string) {
        this.queueSuffix = queueSuffix;
        this.topic = topic;
        this.messageQueueFactory = new MessageQueueFactory(this.queueSuffix);
    }

    public async startPublisher() {
        if (!this.publisherPromise) {
            logger.info(`Starting the publisher for ${this.topic}`);
            this.publisherPromise = this.messageQueueFactory.createPublisher(this.topic);
        }
    }

    public async stopPublisher() {
        const publisher = await this.publisherPromise;
        logger.info(`Stop the publisher`);
        await publisher.close();
    }

    public async sendFileMessage(file: string) {
        const publisher = await this.publisherPromise;
        const message = JSON.stringify({file});
        logger.info(`Posting a service bus message ${message}`);
        publisher.send(FileMessage.create(message));
    }
}
