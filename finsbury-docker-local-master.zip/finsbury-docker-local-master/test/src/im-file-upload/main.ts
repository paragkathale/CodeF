import { FileUploader } from './file-uploader';
import { storage, messaging } from './config.json'
import { logger } from '@drumg/long-island-tea';
import { FileMessagePublisher } from './file-message-publisher';

const FILE_NAME = 'im_test_file.xlsx'
const LOCAL_FILE_PATH = `files/${FILE_NAME}`

process.env.AZ_SB_CONNECTION_STRING_DMZ = messaging.connectionString

async function sendFile() {
    const fileUploader = new FileUploader(storage.containerName, storage.connectionString)
    await fileUploader.upload(LOCAL_FILE_PATH, FILE_NAME)
    logger.info(`File ${FILE_NAME} successfully uploaded to Blob container ${storage.containerName}.`)
}

async function sendMessage() {
    const publisher = new FileMessagePublisher('DMZ', messaging.topic)
    try {
        await publisher.startPublisher()
        await publisher.sendFileMessage(FILE_NAME)
        logger.info(`Successfully published message to topic ${messaging.topic}`)
    } catch (err) {
        logger.error(`Error sending message: ${err}`)
    }
    await publisher.stopPublisher()
}

async function main() {
    await sendFile()
    await sendMessage()
    logger.info(`File upload complete`)
    process.exit(0)
}

main()
