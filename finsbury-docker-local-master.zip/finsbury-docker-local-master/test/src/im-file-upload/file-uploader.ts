import { AzureContainerUtils } from '@drumg/cloud-services';
import {logger} from '@drumg/long-island-tea';

export class FileUploader {
    private readonly container: string;
    private readonly connectionString?: string;

    constructor(container: string, connectionString: string) {
        this.connectionString = connectionString;
        this.container = container;
    }

    public async upload(filePath: string, metadata?: any) {
        logger.info(`Uploading ${filePath} to ${this.container}`);
        const utils = new AzureContainerUtils(this.container, this.connectionString);
        await utils.uploadLocalFileAsBlob(filePath, metadata);
        logger.info(`Upload finished`);
    }
}
