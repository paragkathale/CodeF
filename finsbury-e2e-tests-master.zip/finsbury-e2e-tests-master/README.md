# Finsbury End-to-end Tests

## Running the tests locally

1. Download `finsubry-e2e-test` `.env` file from Keeper and place it under the project directory. The file contains environment variables for testing against finsbury `dev` environment. Modify the variables if you wish to run the tests against other environments.

2. Run the following commands:
```
npm install
npm test
```
