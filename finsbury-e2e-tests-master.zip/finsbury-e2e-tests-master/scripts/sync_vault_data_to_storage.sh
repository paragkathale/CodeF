#!/usr/bin/env bash
# FIN-37, FIN-73 temporary solution for verifying backend data
CONTAINER_NAME='dlt-output'
AZ_CI_STORAGE_ACCOUNT='devfin00dmz00'
BASE_URL=http://localhost:10050

function uploadBlob() {
    localFilePath=$1
    blobName=$2

    az storage blob upload \
        --container-name ${CONTAINER_NAME} \
        --file $localFilePath \
        --name $blobName \
        --account-name ${AZ_CI_STORAGE_ACCOUNT} \
        --auth-mode login
}

function queryAndUploadBlob() {
    FILE_NAME=$1
    TARGET_URL=$2

    FILE_DIR=output
    FILE_PATH=${FILE_DIR}/${FILE_NAME}

    # retrieve data and save to json file
    cd "$(dirname "$0")"
    mkdir -p $FILE_DIR
    curl ${TARGET_URL} | jq . > ${FILE_PATH}

    # send to azure blob storage in DMZ for test verification
    az login --identity
    uploadBlob "${FILE_PATH}" "${FILE_NAME}"
}


FILE_NAME="dlt_trade_records.json"
FULL_URL="$BASE_URL/tradeRecords"
queryAndUploadBlob "$FILE_NAME" "$FULL_URL"

FILE_NAME="dlt_trade_pairs.json"
FULL_URL="$BASE_URL/tradePairs"
queryAndUploadBlob "$FILE_NAME" "$FULL_URL"
