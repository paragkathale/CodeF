export const templateMapping: {[type: string]: string} = {
    IM: 'im-trade-template.json',
    CU: 'cu-trade-template.json',
    PB: 'pb-trade-template.json'
};

export enum TemplateType {
    IM = 'IM',
    CU = 'CU',
    PB = 'PB'
}
