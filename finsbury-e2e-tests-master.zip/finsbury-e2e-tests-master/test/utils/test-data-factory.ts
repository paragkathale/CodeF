/**
 * Creates an AQR trade record.
 * @param overrides map of fields to override default.
 */
import { CUTrade, IMTrade, PBTrade } from '../interfaces';
import { templateMapping, TemplateType } from '../test-data-templates/template-mapping';

export const createTradeJson = <T extends IMTrade | PBTrade | CUTrade>(templateType: TemplateType, overrides?: T): T => {
    return {
        ...createDefaultJson(templateType),
        ...overrides
    };
};

const createDefaultJson = (templateType: TemplateType) => {
    const templateFileName = templateMapping[templateType];

    if (!templateFileName) {
        throw new Error(`Unsupported template type ${templateType}. Has templateId mapping been added to template-mapping.ts?`);
    }

    return require(`../test-data-templates/${templateFileName}`);
};

export const createTradeJsonAqr = (overrides?: IMTrade): IMTrade => createTradeJson(TemplateType.IM, overrides);

export const createMultipleTradeJsonAqr = (overrides: IMTrade[]): IMTrade[] => {
    const trades: IMTrade[] = [];

    overrides.forEach((override) => {
        trades.push(createTradeJsonAqr(override));
    });

    return trades;
};

export const createCustTradeAqr = (imUploadData: IMTrade[], unMatchedTrade: IMTrade): IMTrade[] => {
    const lastIndex = imUploadData.length - 1;
    const cuUploadData: IMTrade[] = imUploadData.slice(0, lastIndex);
    cuUploadData[lastIndex] = createTradeJsonAqr(unMatchedTrade);

    return cuUploadData;
};
