import { logger } from '@drumg/long-island-tea';
import axios, { AxiosInstance } from 'axios';
import { TradeEvent, TradePairsDTO, TradeRecordsDTO } from '../interfaces';

export class APIServiceClient {
    private readonly httpClient: AxiosInstance;

    constructor(baseURL: string, bearer: string, timeout: number = 30000) {
        const headers = { Authorization: `Bearer ${bearer!!}` };
        this.httpClient = axios.create({
            baseURL, timeout, headers
        });
    }

    public async getTradeRecords(): Promise<TradeRecordsDTO> {
        logger.debug(`Retrieving trade records from DLT service`);
        const response = await this.httpClient.get('/tradeRecords');
        return response.data;
    }

    public async getTradePairs(): Promise<TradePairsDTO> {
        logger.debug(`Retrieving trade pairs from DLT service`);
        const response = await this.httpClient.get('/tradePairs');
        return response.data;
    }

    public async getTradeEventsByTxId(transactionId: string): Promise<TradeEvent[]> {
        logger.debug(`Retrieving trade pairs from API service`);
        const response = await this.httpClient.get(`/tradeEvents?transactionId=${transactionId}`);
        return response.data;
    }
}
