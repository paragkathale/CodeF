import { logger } from '@drumg/long-island-tea';
import { Client } from 'ssh2';
import uuid = require('uuid');
import { config } from '../config';
import SftpClient, { SftpConfig } from './sftp-client';
import { createTestFile } from './test-file-factory';

const isDirectoryEmpty = async (sftp: SftpClient, remoteDir: string, maxAttempts: number = 5) => {
    let deleted = false;
    let attempts = 1;

    while (attempts < maxAttempts) {
      try {
        const list = await sftp.readdir(remoteDir);
        if (list.length === 0) {
          deleted = true;
        }
      } catch (err) {
        logger.error(`Error listing remote directory ${remoteDir}, retrying.`);
      }

      attempts++;
    }

    return deleted;
};

const fileExistsInDirectory = async (sftp: SftpClient, parentPath: string, filename: string): Promise<boolean> => {
  let exists = false;

  try {
    const list = await sftp.readdir(`/${parentPath}`) as any[];
    exists = list.map((item) => item.filename).includes(filename);
  } catch (err) {
    logger.error(`Error listing remote directory ${parentPath}: ${err}`);
    throw err; // re-throw
  }

  return exists;
};

const DEFAULT_FILE_NAME = 'default-input-file';

const uploadTradeFile = async (sftpConfig: SftpConfig, tradeRows: any[], fileName: string = `${DEFAULT_FILE_NAME}-${uuid()}`) => {
  const sftpClient = new SftpClient(new Client());
  await sftpClient.connect(sftpConfig);

  const localFilePath = createTestFile(tradeRows, fileName);
  const remoteFilePath = `${config.common.sftp.uploadDir}/${fileName}`;
  await sftpClient.put(localFilePath, remoteFilePath);
  await sftpClient.close();
};

export const sftpTestUtils = {
    isDirectoryEmpty,
    fileExistsInDirectory,
    uploadTradeFile
};
