import { logger } from '@drumg/long-island-tea';

export function wait(ms: number) {
    logger.info(`Wait for ${ms} milliseconds...`);
    return new Promise((resolve) => setTimeout(resolve, ms));
}

const defaultRetryParams = {
    limit: 3,
    retryIntervalMs: 3000
};

export async function withRetry(retryParams: RetryParams | (() => any)): Promise<any> {
    let params;

    if (typeof retryParams === 'function') {
        params = { ...defaultRetryParams, actionFn: retryParams, actionName: retryParams.name };
    } else {
        params = { ...defaultRetryParams, ...retryParams };
    }

    const { limit, retryIntervalMs, actionFn, actionName } = params;
    let attempt = 0;

    const performRetrableAction = async (): Promise<any> => {
        attempt++;
        try {
            logger.debug(`Starting ${attempt}/${limit} attempts to ${actionName}.`);
            const returnValue = await actionFn();
            logger.info(`Action ${actionName} completed.`);

            return returnValue;
        } catch (err) {
            logger.error(`${attempt}/${limit} attempts to ${actionName} failed with error ${err.message}`, err);

            if (attempt < limit) {
                logger.info(`Retrying action ${actionName} in ${retryIntervalMs} milliseconds...`);
                await wait(retryIntervalMs);
                return performRetrableAction();
            } else {
                throw err;
            }
        }
    };

    return performRetrableAction();
}

interface RetryParams {
    limit?: number;
    retryIntervalMs?: number;
    actionFn: () => any;
    actionName?: string;
}
