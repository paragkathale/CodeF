import { logger } from '@drumg/long-island-tea';
import * as fs from 'fs';
import * as path from 'path';
import uuid = require('uuid');
import { utils, WorkBook, writeFile } from 'xlsx';

const tempDir = path.join(__dirname, '..', '..', 'temp');

/**
 * Create a test file in the temp directory using a provided dataset.
 * @param dataRows array of rows to generate excel file from.
 * @returns the path of the generated file.
 */
export const createTestFile = (dataRows: any[], fileName: string = uuid()): string => {
    const workSheet = utils.json_to_sheet(dataRows);
    const workBook = utils.book_new();
    utils.book_append_sheet(workBook, workSheet);
    const filePath = writeToTempDir(workBook, fileName);
    return filePath;
};

const writeToTempDir = (workBook: WorkBook, fileName: string): string => {
    if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir);
    }

    const filePath = path.join(tempDir, `${fileName}.xlsx`);
    writeFile(workBook, filePath);
    logger.info(`write file complete: ${filePath}`);
    return filePath;
};
