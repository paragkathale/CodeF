import { logger } from '@drumg/long-island-tea';
import { Client } from 'ssh2';
import { promisify } from 'util';

const base64ToString = (base64Str: string) => Buffer.from(base64Str, 'base64').toString('utf-8').trim();

export interface SftpConfig {
    host: string;
    port: number;
    username: string;
    privateKey: string;
}

export default class SftpClient {
    private sshClient: Client;
    private sftp: any;

    constructor(sshClient: Client) {
        this.sshClient = sshClient;
    }

    public readdir(remoteDir: string): Promise<object[]> {
        return promisify(this.sftp.readdir)
            .call(this.sftp, remoteDir);
    }

    public remove(remoteFilePath: string): Promise<void> {
        return promisify(this.sftp.unlink)
            .call(this.sftp, remoteFilePath)
            .catch(() => logger.info(`${remoteFilePath} does not exist. No files are removed.`));
    }

    public put(localFilePath: string, remoteFilePath: string): Promise<void> {
        return promisify(this.sftp.fastPut)
            .call(this.sftp, localFilePath, remoteFilePath);
    }

    public connect(config: SftpConfig): Promise<any> {
        const connectConfig = Object.assign({}, config);
        connectConfig.privateKey = base64ToString(connectConfig.privateKey);
        return new Promise((resolve, reject) => {
            this.sshClient
                .on('ready', () => {
                    this.sshClient.sftp((err: Error, sftp: any) => {
                        if (err) { return reject(err); }
                        this.sftp = sftp;
                        resolve();
                    });
                })
                .connect(connectConfig);
        });
    }

    public fastGet(remoteFilePath: string, localFilePath: string): Promise<any> {
        return promisify(this.sftp.fastGet)
            .call(this.sftp, remoteFilePath, localFilePath);
    }

    public close(): void {
        this.sshClient.end();
        logger.info('Closed sftp connection');
    }
}
