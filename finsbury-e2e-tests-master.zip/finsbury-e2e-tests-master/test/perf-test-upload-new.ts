import { logger } from '@drumg/long-island-tea';
import { expect } from 'chai';
import { Client } from 'ssh2';
import uuid = require('uuid');
import { config } from './config';
import { waitForSubmission } from './test-flow/common-steps';
import { createDLTServiceAccessor } from './test-flow/dlt-svc-accessor';
import SftpClient from './utils/sftp-client';
import { createTradeJsonAqr } from './utils/test-data-factory';
import { createTestFile } from './utils/test-file-factory';

const numInputRecords = parseInt(process.env.NUM_TRADES || '') || 50;

const sftp = new SftpClient(new Client());
const testId = Math.round((new Date()).getTime() / 1000);

const FILE_NAME_NEW_TRADE = `perf-test-${numInputRecords}-${testId}`;
const inputTrades: any[] = [];

describe(`Performance test for ${numInputRecords} records:`, () => {

  before(async () => {
    await sftp.connect(config.im.sftp);
    for (let i = 0; i < numInputRecords; ++i) {
      inputTrades.push(createTradeJsonAqr({ TransID: uuid() }));
    }
  });

  after(async () => {
    sftp.close();
  });

  it(`upload a file containing ${numInputRecords} records`, async () => {
    expect(inputTrades.length).to.equal(numInputRecords);
    const localFilePath = createTestFile(inputTrades, FILE_NAME_NEW_TRADE);
    const remoteFilePath = `${config.common.sftp.uploadDir}/${FILE_NAME_NEW_TRADE}`;
    await sftp.put(localFilePath, remoteFilePath);
  });

  waitForSubmission();

  it(`verify that the trade records are on the ledger`, async () => {
    const inputIds = inputTrades.map( (trade) => trade.TransID );
    const found = await createDLTServiceAccessor(config.im.dltsvc).findTradesByOrderIds(inputIds);
    expect(found.length).to.equal(inputTrades.length);
  });
});
