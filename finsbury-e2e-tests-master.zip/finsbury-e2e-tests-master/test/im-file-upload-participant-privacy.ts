import { expect } from 'chai';
import { Client } from 'ssh2';
import uuid = require('uuid');
import { config } from './config';
import { waitForSubmission } from './test-flow/common-steps';
import { createDLTServiceAccessor } from './test-flow/dlt-svc-accessor';
import SftpClient from './utils/sftp-client';
import { createTradeJsonAqr } from './utils/test-data-factory';
import { createTestFile } from './utils/test-file-factory';

const FILE_NAME_NEW_TRADE = `im-file-upload-privacy-${uuid()}`;
const sftp = new SftpClient(new Client());
const remoteUploadDir = config.common.sftp.uploadDir;

describe('As an IM, I want each participant to only see trades relevant to them so that privacy is maintained between network participants:', () => {
  const orderId1 = uuid();
  const orderId2 = uuid();
  const orderId3 = uuid();
  const trade1 = createTradeJsonAqr({ TransID: orderId1, AccountNumber: config.cu.reference.accountNumber });
  const trade2 = createTradeJsonAqr({ TransID: orderId2, AccountNumber: config.pb.reference.accountNumber });
  const trade3 = createTradeJsonAqr({ TransID: orderId3, AccountNumber: config.pb.reference.accountNumber });
  const inputTradeRecords = [trade1, trade2, trade3];

  after(async () => {
    sftp.close();
  });

  it('connect to the sftp server', async () => {
    await sftp.connect(config.im.sftp);
  });

  it(`upload a trade file containing multiple new trades under different fund accounts to the remote SFTP directory`, async () => {
    const localFilePath = createTestFile(inputTradeRecords, FILE_NAME_NEW_TRADE);
    const remoteFilePath = `${remoteUploadDir}/${FILE_NAME_NEW_TRADE}`;
    await sftp.put(localFilePath, remoteFilePath);
  });

  waitForSubmission();

  it(`verify that manager sees all trade records they published on its ledger`, async () => {
    const dltSvcAccessor = createDLTServiceAccessor(config.im.dltsvc);
    const found = await dltSvcAccessor.findTradesByOrderIds([orderId1, orderId2, orderId3]);
    const foundTxIds = found.map((record) => record.transactionId);
    expect(foundTxIds).to.have.to.members([orderId1, orderId2, orderId3]);
  }).timeout(config.common.dltsvc.requestTimeout);

  it(`verify that custodian ${config.cu.reference.name} only sees the one trade record relevant to them on its ledger`, async () => {
    const dltSvcAccessor = createDLTServiceAccessor(config.cu.dltsvc);
    const found = await dltSvcAccessor.findTradesByOrderIds([orderId1, orderId2, orderId3]);
    const foundTxIds = found.map((record) => record.transactionId);
    expect(foundTxIds).to.have.to.members([orderId1]);
  }).timeout(config.common.dltsvc.requestTimeout);

  it(`verify that custodian ${config.pb.reference.name} only sees the two trade records relevant to them on its ledger`, async () => {
    const dltSvcAccessor = createDLTServiceAccessor(config.pb.dltsvc);
    const found = await dltSvcAccessor.findTradesByOrderIds([orderId1, orderId2, orderId3]);
    const foundTxIds = found.map((record) => record.transactionId);
    expect(foundTxIds).to.have.to.members([orderId2, orderId3]);
  }).timeout(config.common.dltsvc.requestTimeout);

});
