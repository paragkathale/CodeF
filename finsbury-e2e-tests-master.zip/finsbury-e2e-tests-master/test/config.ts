import * as dotenv from 'dotenv';

dotenv.config();

// values loaded from CircleCI finsbury-e2e-test project Environment Variables
export const config = {
    common: {
        sftp: {
            uploadDir: 'uploads',
            outputDir: 'output'
        },
        dltsvc: {
            requestTimeout: 60000
        },
        submissionWaitMs: 12000
    },
    im: {
        sftp: {
            host: process.env.SFTP_HOST!,
            port: Number(process.env.SFTP_PORT) || 22,
            username: process.env.SFTP_USER!,
            privateKey: process.env.SSH_KEY_B64!
        },
        dltsvc: {
            baseURL: process.env.DLT_SVC_BASE_URL!,
            token: process.env.DLT_SVC_AUTH_TOKEN!
        }
    },
    cu: {
        reference: {
            name: 'Corda_CU',
            accountNumber: 'JPM'
        },
        sftp: {
            host: process.env.SFTP_HOST_CU!,
            port: Number(process.env.SFTP_PORT_CU) || 22,
            username: process.env.SFTP_USER_CU!,
            privateKey: process.env.SSH_KEY_B64_CU!
        },
        dltsvc: {
            baseURL: process.env.DLT_SVC_BASE_URL_CU!,
            token: process.env.DLT_SVC_AUTH_TOKEN_CU!
        }
    },
    pb: {
        reference: {
            name: 'Corda_PB',
            accountNumber: 'GSC'
        },
        sftp: {
            host: process.env.SFTP_HOST_PB!,
            port: Number(process.env.SFTP_PORT_PB) || 22,
            username: process.env.SFTP_USER_PB!,
            privateKey: process.env.SSH_KEY_B64_PB!
        },
        dltsvc: {
            baseURL: process.env.DLT_SVC_BASE_URL_PB!,
            token: process.env.DLT_SVC_AUTH_TOKEN_PB!
        }
    },
    fa: {
        sftp: {
            host: process.env.SFTP_HOST_FA!,
            port: Number(process.env.SFTP_PORT_FA) || 22,
            username: process.env.SFTP_USER_FA!,
            privateKey: process.env.SSH_KEY_B64_FA!
        },
        dltsvc: {
            baseURL: process.env.DLT_SVC_BASE_URL_FA!,
            token: process.env.DLT_SVC_AUTH_TOKEN_FA!
        }
    }};
