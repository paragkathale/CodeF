import { expect } from 'chai';
import uuid = require('uuid');
import { config } from './config';
import { IMTrade } from './interfaces';
import { waitForSubmission } from './test-flow/common-steps';
import { createDLTServiceAccessor } from './test-flow/dlt-svc-accessor';
import { sftpTestUtils } from './utils/sftp-test-utils';
import { createTradeJsonAqr } from './utils/test-data-factory';

describe('Investment manager cancels an already paired trade:', () => {
  const cuAcctNum = config.cu.reference.accountNumber;
  const orderId1 = uuid();
  const categoryUnaffirmed = 'Unaffirmed';
  const narrativeUnaffirmed = 'Counterpart\'s DK transaction';

  const trade1json: IMTrade = {
    TransID: orderId1,
    AccountNumber: cuAcctNum
  };

  const imFirstFile = '1_im_upload_new_trade';
  const cuFirstFile = '2_cu_upload_new_trade';
  const imSecondFile = '3_im_cancel_trade';

  // Given that trade orderId1 has been proposed by both IM & CU, and is now paired
  it(`IM uploads trade file ${imFirstFile} containing trade ${orderId1}`, async () => {
    const trade1 = createTradeJsonAqr(trade1json);
    const trade3 = createTradeJsonAqr({ TransID: uuid() });
    await sftpTestUtils.uploadTradeFile(config.im.sftp, [trade1, trade3], imFirstFile);
  });

  waitForSubmission();

  it(`CU uploads trade file ${cuFirstFile} containing trade ${orderId1}`, async () => {
    const trade1 = createTradeJsonAqr({
      ...trade1json,
      StatusCategory: categoryUnaffirmed,
      StatusNarrative: narrativeUnaffirmed
    });
    const trade2 = createTradeJsonAqr({
      TransID: uuid(),
      AccountNumber: cuAcctNum,
      StatusCategory: categoryUnaffirmed,
      StatusNarrative: narrativeUnaffirmed
    });
    await sftpTestUtils.uploadTradeFile(config.cu.sftp, [trade1, trade2], cuFirstFile);
  });

  waitForSubmission();

  it(`verify that the paired trade ${orderId1} exists on DLT`, async () => {
    const dltSvcAccessor = createDLTServiceAccessor(config.im.dltsvc);
    const tradePairs = await dltSvcAccessor.findTradePairsByOrderIds([orderId1]);
    expect(tradePairs.length).to.equal(1);
  }).timeout(config.common.dltsvc.requestTimeout);

  it(`IM uploads trade file ${imSecondFile} to cancel trade ${orderId1}`, async () => {
    const amendedTrade1 = createTradeJsonAqr({
      ...trade1json,
      TransType: 'C'
    });
    await sftpTestUtils.uploadTradeFile(config.im.sftp, [amendedTrade1], imSecondFile);
  });

  waitForSubmission();

  it(`verify that the paired trade ${orderId1} no longer exists`, async () => {
    const dltSvcAccessor = createDLTServiceAccessor(config.im.dltsvc);
    const tradePairs = await dltSvcAccessor.findTradePairsByOrderIds([orderId1]);
    expect(tradePairs.length).to.equal(0);
  }).timeout(config.common.dltsvc.requestTimeout);

  it(`verify that the unpaired trade records are recreated on the DLT with a CANCELLED status`, async () => {
    const dltSvcAccessor = createDLTServiceAccessor(config.im.dltsvc);
    const tradeRecords = await dltSvcAccessor.findTradesByOrderIds([orderId1]);
    expect(tradeRecords.length).to.equal(2);

    tradeRecords.forEach((record) => {
      expect(record.status).to.equal('CANCELLED');
    });
  }).timeout(config.common.dltsvc.requestTimeout);
});
