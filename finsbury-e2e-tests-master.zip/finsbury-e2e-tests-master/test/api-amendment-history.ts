import { expect } from 'chai';
import uuid = require('uuid');
import { config } from './config';
import { waitForSubmission } from './test-flow/common-steps';
import { APIServiceClient as APIServiceClient } from './utils/api-svc-client';
import { sftpTestUtils } from './utils/sftp-test-utils';
import { createTradeJsonAqr } from './utils/test-data-factory';

// As a FINs User, I want to access the amendment history of a transaction so that I can review how it has achieved its current state
describe('Access trade amendment history', () => {
    const expectedEvents = [
        { state: 'CANCELLED', source: 'Corda_IM', dataType: 'tradeRecord', transType: 'C' },
        { state: 'CANCELLED', source: 'Corda_CU', dataType: 'tradeRecord', transType: 'N' },
        { state: 'PAIRED',    source: 'Corda_CU', dataType: 'tradePair',   transType: 'N' },
        { state: 'PAIRED',    source: 'Corda_CU', dataType: 'tradePair',   transType: 'N' },
        { state: 'NEW',       source: 'Corda_CU', dataType: 'tradeRecord', transType: 'N' },
        { state: 'NEW',       source: 'Corda_IM', dataType: 'tradeRecord', transType: 'N' },
        { state: 'NEW',       source: 'Corda_IM', dataType: 'tradeRecord', transType: 'N' },
    ];

    const filePrefix = 'FIN-161';
    const imNewTrade = `${filePrefix}_1_im_upload_new_trade`;
    const imAmendTrade = `${filePrefix}_2_im_amend_trade`;
    const cuNewTrade = `${filePrefix}_3_cu_upload_new_trade`;
    const cuAmendTrade = `${filePrefix}_4_cu_amend_trade`;
    const imCancelTrade = `${filePrefix}_5_im_cancel_trade`;

    const orderId1 = uuid();
    const orderId1Short = orderId1.slice(0, 6);

    it(`IM uploads trade file ${imNewTrade} containing new trade ${orderId1Short}`, async () => {
        const trade = createTradeJsonAqr({ TransID: orderId1 });
        await sftpTestUtils.uploadTradeFile(config.im.sftp, [trade], imNewTrade);
    });

    waitForSubmission();

    it(`IM uploads trade file ${imAmendTrade} containing amended trade ${orderId1Short}`, async () => {
        const trade = createTradeJsonAqr({ TransID: orderId1, Price: '0.4' });
        await sftpTestUtils.uploadTradeFile(config.im.sftp, [trade], imAmendTrade);
    });

    waitForSubmission();

    it(`CU uploads trade file ${cuNewTrade} containing new trade ${orderId1Short}`, async () => {
        const trade = createTradeJsonAqr({ TransID: orderId1 });
        await sftpTestUtils.uploadTradeFile(config.cu.sftp, [trade], cuNewTrade);
    });

    waitForSubmission();

    it(`CU uploads trade file ${cuAmendTrade} containing trade amendment ${orderId1Short}`, async () => {
        const trade = createTradeJsonAqr({ TransID: orderId1, Price: '0.3' });
        await sftpTestUtils.uploadTradeFile(config.cu.sftp, [trade], cuAmendTrade);
    });

    waitForSubmission();

    it(`IM uploads trade file ${imCancelTrade} containing trade cancellation ${orderId1Short}`, async () => {
        const trade = createTradeJsonAqr({ TransID: orderId1, TransType: 'C' });
        await sftpTestUtils.uploadTradeFile(config.im.sftp, [trade], imCancelTrade);
    });

    waitForSubmission();

    it(`query /tradeEvents endpoint with transactionId=${orderId1Short} and verify that the amendment history contains ` +
        `the expected ${expectedEvents.length} trade events in chronological order: ${JSON.stringify(expectedEvents, null, 2)}`, async () => {
            const { baseURL, token } = config.im.dltsvc;
            const apiSvcClient = new APIServiceClient(baseURL, token);
            const tradeEvents = await apiSvcClient.getTradeEventsByTxId(orderId1);

            expect(tradeEvents.length).to.equal(expectedEvents.length);
            tradeEvents.forEach((event, index) => {
                const expectedEvent = expectedEvents[index];
                expect(event.dataType).to.equal(expectedEvent.dataType);
                expect(event.source).to.equal(expectedEvent.source);
                expect(event.state).to.equal(expectedEvent.state);
            });
        });
});
