import { expect } from 'chai';
import { Client } from 'ssh2';
import uuid = require('uuid');
import { config } from './config';
import { waitForSubmission } from './test-flow/common-steps';
import { createDLTServiceAccessor } from './test-flow/dlt-svc-accessor';
import { wait } from './utils/common';
import SftpClient from './utils/sftp-client';
import { createTradeJsonAqr } from './utils/test-data-factory';
import { createTestFile } from './utils/test-file-factory';

const sftp = new SftpClient(new Client());
const testId = uuid();

const FILE_NAME_NEW_TRADE = `im-trade-new-${testId}`;
const FILE_NAME_CANCEL_TRADE = `im-trade-cancel-${testId}`;

describe('Investment manager cancels a trade:', () => {
  const orderId = uuid();

  before(async () => {
    await sftp.connect(config.im.sftp);
  });

  after(async () => {
    sftp.close();
  });

  it(`upload a file containing a new record with OrderId=${orderId}`, async () => {
    const trade = createTradeJsonAqr({ TransID: orderId });
    const localFilePath = createTestFile([ trade ], FILE_NAME_NEW_TRADE);
    const remoteFilePath = `${config.common.sftp.uploadDir}/${FILE_NAME_NEW_TRADE}`;
    await sftp.put(localFilePath, remoteFilePath);
  });

  waitForSubmission();

  it(`upload another file cancelling the trade OrderId=${orderId}`, async () => {
    const trade = createTradeJsonAqr({ TransID: orderId, TransType: 'C' });
    const localFilePath = createTestFile([ trade ], FILE_NAME_CANCEL_TRADE);
    const remoteFilePath = `${config.common.sftp.uploadDir}/${FILE_NAME_CANCEL_TRADE}`;
    await sftp.put(localFilePath, remoteFilePath);
  });

  waitForSubmission();

  it(`verify that the trade record with OrderId=${orderId} has a CANCELLED status on the ledger`, async () => {
    const found = await createDLTServiceAccessor(config.im.dltsvc).findTradesByOrderIds([orderId]);
    expect(found.length).to.equal(1);
    expect(found[0]!.status).to.equal('CANCELLED');
  });
});
