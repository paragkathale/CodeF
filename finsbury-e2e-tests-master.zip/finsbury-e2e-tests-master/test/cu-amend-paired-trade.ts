import { expect } from 'chai';
import uuid = require('uuid');
import { config } from './config';
import { IMTrade } from './interfaces';
import { waitForSubmission } from './test-flow/common-steps';
import { createDLTServiceAccessor } from './test-flow/dlt-svc-accessor';
import { withRetry } from './utils/common';
import { sftpTestUtils } from './utils/sftp-test-utils';
import { createTradeJsonAqr } from './utils/test-data-factory';

describe('Custodian amends an already paired trade:', () => {
  const cuAcctNum = config.cu.reference.accountNumber;
  const orderId1 = uuid();
  const orderId2 = uuid();
  const categoryAffirmed = 'Affirmed';
  const categoryUnaffirmed = 'Unaffirmed';
  const narrativeAffirmed = 'Affirmed. Control Number = 55432149';
  const narrativeUnaffirmed = 'Counterpart\'s DK transaction';

  const trade1json: IMTrade = {
    TransID: orderId1,
    AccountNumber: cuAcctNum
  };

  // Given that trade orderId1 has been proposed by both IM & CU, and is now paired
  it(`IM uploads trade containing trade ${orderId1}`, async () => {
    const trade1 = createTradeJsonAqr(trade1json);
    const trade3 = createTradeJsonAqr({ TransID: uuid() });
    await sftpTestUtils.uploadTradeFile(config.im.sftp, [trade1, trade3]);
  });

  waitForSubmission();

  it(`CU uploads trade containing trade ${orderId1}`, async () => {
    const trade1 = createTradeJsonAqr({
      ...trade1json,
      StatusCategory: categoryUnaffirmed,
      StatusNarrative: narrativeUnaffirmed
    });
    const trade2 = createTradeJsonAqr({
      TransID: orderId2,
      AccountNumber: cuAcctNum,
      StatusCategory: categoryUnaffirmed,
      StatusNarrative: narrativeUnaffirmed
    });
    await sftpTestUtils.uploadTradeFile(config.cu.sftp, [trade1, trade2]);
  });

  waitForSubmission();

  it(`CU uploads a new file to amend trade ${orderId1}`, async () => {
    const amendedTrade1 = createTradeJsonAqr({
      ...trade1json,
      StatusCategory: categoryAffirmed,
      StatusNarrative: narrativeAffirmed
    });
    await sftpTestUtils.uploadTradeFile(config.cu.sftp, [amendedTrade1]);
  });

  waitForSubmission();

  it(`verify that the paired trade ${orderId1} contains the updated status ${narrativeAffirmed}`, async () => {
    const dltSvcAccessor = createDLTServiceAccessor(config.cu.dltsvc);
    await withRetry(async () => {
      const tradePairs = await dltSvcAccessor.findTradePairsByOrderIds([orderId1]);
      expect(tradePairs.length).to.equal(1);

      const cuRecord = findProviderRecordFromPair(tradePairs[0], config.cu.reference.name);
      expect(cuRecord.length).to.equal(1);

      const actualStatus = JSON.parse(cuRecord[0].details).status.latest;
      expect(actualStatus.custodianStatus.value).to.equal(categoryAffirmed);
      expect(actualStatus.custodianNarrative.value).to.equal(narrativeAffirmed);
    });
  }).timeout(config.common.dltsvc.requestTimeout);
});

function findProviderRecordFromPair(tradePair: any, provider: string) {
  return ['first', 'second']
    .map((prop) => tradePair.pair[prop])
    .filter((record) => record.provider === provider);
}
