import { config } from '../config';
import { wait } from '../utils/common';

export const waitForSubmission = () => {
    it(`wait for ${config.common.submissionWaitMs / 1000} seconds`, async () => {
        await wait(config.common.submissionWaitMs);
    });
};
