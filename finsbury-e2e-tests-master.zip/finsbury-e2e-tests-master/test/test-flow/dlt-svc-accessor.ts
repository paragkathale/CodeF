import { APIServiceClient } from '../utils/api-svc-client';

export class DLTServiceAccessor {
    private readonly apiSvcClient: APIServiceClient;

    constructor(apiSvcClient: APIServiceClient) {
        this.apiSvcClient = apiSvcClient;
    }

    public async findTradesByOrderIds(orderIdsToLookUp: string[]): Promise<any[]> {
        const { tradeRecords } = await this.apiSvcClient.getTradeRecords();
        const foundTrades: any[] = [];

        tradeRecords.forEach((tr) => {
            const orderIdIndex = orderIdsToLookUp.indexOf(tr.transactionId);
            if (orderIdIndex > -1) {
                foundTrades.push(tr);
            }
        });

        return foundTrades;
    }

    public async findTradePairsByOrderIds(orderIdsToLookUp: string[]): Promise<any[]> {
        const { tradePairs } = await this.apiSvcClient.getTradePairs();
        const foundTrades: any[] = [];

        tradePairs.forEach((tp) => {
            const tpDetailsFirst = JSON.parse(tp.pair.first.details);
            const orderIdIndex = orderIdsToLookUp.indexOf(tpDetailsFirst.transaction.identifiers.TransID);
            if (orderIdIndex > -1) {
                foundTrades.push(tp);
            }
        });

        return foundTrades;
    }
}

export const createDLTServiceAccessor = (config: DLTServiceConifg): DLTServiceAccessor => {
    return new DLTServiceAccessor(new APIServiceClient(config.baseURL, config.token, config.timeout));
};

export interface DLTServiceConifg {
    baseURL: string;
    token: string;
    timeout?: number;
}
