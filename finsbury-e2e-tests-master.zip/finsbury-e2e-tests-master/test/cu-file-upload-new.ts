import { logger } from '@drumg/long-island-tea';
import { expect } from 'chai';
import { Client } from 'ssh2';
import uuid = require('uuid');
import { config } from './config';
import {IMTrade} from './interfaces';
import { waitForSubmission } from './test-flow/common-steps';
import {createDLTServiceAccessor} from './test-flow/dlt-svc-accessor';
import SftpClient from './utils/sftp-client';
import { createTradeJsonAqr } from './utils/test-data-factory';
import { createTestFile } from './utils/test-file-factory';

const FILE_NAME_NEW_TRADE = `cu-file-upload-new-${uuid()}`;
const FILE_NAME_AMEND_TRADE = `cu-file-upload-amend-${uuid()}`;
const sftp = new SftpClient(new Client());
const dltSvcAccessor = createDLTServiceAccessor(config.cu.dltsvc);
const remoteUploadDir = config.common.sftp.uploadDir;

describe('Custodian propose trades:', () => {
  const cuAcctNum = config.cu.reference.accountNumber;
  const orderId1 = uuid();
  const orderId2 = uuid();
  const category1 = 'Affirmed';
  const category2 = 'Unaffirmed';
  const narrative1 = 'Affirmed. Control Number = 55432149';
  const narrative2 = 'Counterpart\'s DK transaction';

  const trade1json: IMTrade = {
    TransID: orderId1,
    AccountNumber: cuAcctNum,
    StatusCategory: category1,
    StatusNarrative: narrative1
  };

  const trade2json: IMTrade = {
    TransID: orderId2,
    AccountNumber: cuAcctNum,
    StatusCategory: category2,
    StatusNarrative: narrative2
  };

  const trade1 = createTradeJsonAqr(trade1json);
  const trade2 = createTradeJsonAqr(trade2json);
  const inputTradeRecords = [ trade1, trade2 ];

  before(() => {
    logger.info(`Running tests in CU cell`);
  });

  after(async () => {
    sftp.close();
  });

  it('connect to the sftp server', async () => {
    await sftp.connect(config.cu.sftp);
  });

  it(`upload a trade file containing ${inputTradeRecords.length} new trades to the remote SFTP directory`, async () => {
    const localFilePath = createTestFile(inputTradeRecords, FILE_NAME_NEW_TRADE);
    const remoteFilePath = `${remoteUploadDir}/${FILE_NAME_NEW_TRADE}`;
    await sftp.put(localFilePath, remoteFilePath);
  });

  waitForSubmission();

  it(`verify that the two trade records exist and have a NEW status on the ledger`, async () => {
    const found = await dltSvcAccessor.findTradesByOrderIds([orderId1, orderId2]);
    expect(found.length).to.equal(inputTradeRecords.length);
    found.forEach((record) => expect(record.status).to.equal('NEW'));
  }).timeout(config.common.dltsvc.requestTimeout);

  it(`verify the settlement status and narrative`, async () => {
    const trades = [trade1, trade2];
    const orders = [orderId1, orderId2];
    const found = await dltSvcAccessor.findTradesByOrderIds(orders);
    expect(found.length).to.equal(trades.length);

    for (let i = 0; i < found.length; i++) {
      const expected = trades[i];
      const actual = found[i];
      expect(expected.TransID).to.equal(actual.transactionId);
      expect(expected.AccountNumber).to.equal(actual.fund.accountNumber);
      expect('Corda_FA').to.equal(actual.fund.administrator);
      expect('Corda_IM').to.equal(actual.fund.manager);
      const actualStatus = JSON.parse(actual.tradeDetails).status.latest;
      expect(expected.StatusCategory).to.equal(actualStatus.custodianStatus.value);
      expect(expected.StatusNarrative).to.equal(actualStatus.custodianNarrative.value);
    }
  }).timeout(config.common.dltsvc.requestTimeout);

  it(`upload a trade file containing amended trade`, async () => {
    const tradeAmendedJson: IMTrade = {
      TransID: orderId1,
      AccountNumber: cuAcctNum,
      StatusCategory: category2,
      StatusNarrative: narrative2
    };

    const tradeAmended = createTradeJsonAqr(tradeAmendedJson);
    const localFilePath = createTestFile([tradeAmended], FILE_NAME_AMEND_TRADE);
    const remoteFilePath = `${remoteUploadDir}/${FILE_NAME_AMEND_TRADE}`;
    await sftp.put(localFilePath, remoteFilePath);
  });

  waitForSubmission();

  it(`verify that custodian ${config.cu.reference.name} gets an amend`, async () => {
    const found = await dltSvcAccessor.findTradesByOrderIds([orderId1]);
    const actualStatus = JSON.parse(found[0].tradeDetails).status.latest;
    expect(actualStatus.custodianStatus.value).to.equal(category2);
    expect(actualStatus.custodianNarrative.value).to.equal(narrative2);
  }).timeout(config.common.dltsvc.requestTimeout);
});
