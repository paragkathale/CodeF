import { logger } from '@drumg/long-island-tea';
import { expect } from 'chai';
import csvjson = require('csvtojson');
import { Client } from 'ssh2';
import tempfile = require('tempfile');
import uuid = require('uuid');
import { config } from './config';
import { waitForSubmission } from './test-flow/common-steps';
import { createDLTServiceAccessor } from './test-flow/dlt-svc-accessor';
import { withRetry } from './utils/common';
import SftpClient from './utils/sftp-client';
import { sftpTestUtils } from './utils/sftp-test-utils';
import { createTradeJsonAqr } from './utils/test-data-factory';
import { createTestFile } from './utils/test-file-factory';

const srcSftp = new SftpClient(new Client());

const parties = {
  cu: {
    name: 'Custodian',
    config: config.cu.sftp,
    sftp: new SftpClient(new Client()),
    beforeFiles: [] as string[],
    afterFiles: [] as string[]
  },
  fa: {
    name: 'Fund Admin',
    config: config.fa.sftp,
    sftp: new SftpClient(new Client()),
    beforeFiles: [] as string[],
    afterFiles: [] as string[]
  }
} as { [key: string]: any };

const testId = uuid();
const FILE_NAME_NEW_TRADE = `im-trade-new-${testId}`;
const REMOTE_OUTPUT_DIR = config.common.sftp.outputDir;
const IM_UPLOAD_DIR = config.common.sftp.uploadDir;

describe('IM uploads new trades and received by parties test:', async () => {
  const orderId1 = uuid();
  const orderId2 = uuid();
  const trade1 = createTradeJsonAqr({ TransID: orderId1 });
  const trade2 = createTradeJsonAqr({ TransID: orderId2 });
  const inputTradeRecords = [trade1, trade2];

  before(`IM uploads ${inputTradeRecords.length} trades`, async () => {
    // get initial csv files from other parties
    for (const key of Object.keys(parties)) {
      const party = parties[key];
      await party.sftp.connect(party.config);
      const files = (await party.sftp.readdir(REMOTE_OUTPUT_DIR) as any[])
        .map((ele) => ele.filename).filter((fname) => fname.endsWith('.csv'));
      party.beforeFiles.push(...files);
    }

    // create and submit test IM trade
    const localFilePath = createTestFile(inputTradeRecords, FILE_NAME_NEW_TRADE);
    const remoteFilePath = `${IM_UPLOAD_DIR}/${FILE_NAME_NEW_TRADE}`;
    await srcSftp.connect(config.im.sftp);
    await srcSftp.put(localFilePath, remoteFilePath);
  });

  after(async () => {
    srcSftp.close();
    Object.keys(parties).forEach((key) => { parties[key].sftp.close(); });
  });

  waitForSubmission();

  it(`trade data file is removed from IM sftp`, async () => {
    const fileExist = await sftpTestUtils.fileExistsInDirectory(srcSftp, IM_UPLOAD_DIR, FILE_NAME_NEW_TRADE);
    expect(fileExist).to.equal(false);
  });

  it(`IM DLT has added ${inputTradeRecords.length} trade records wiht NEW status`, async () => {
    const found = await createDLTServiceAccessor(config.im.dltsvc).findTradesByOrderIds([orderId1, orderId2]);
    expect(found.length).to.equal(inputTradeRecords.length);
    found.forEach((record) => expect(record.status).to.equal('NEW'));
  });

  it(`${Object.keys(parties).length} parties receive IM trades in sftp`, async () => {
    const checks = Object.values(parties).map(async (party: any) => {
      const outputFile = await withRetry(async () => {
          logger.info(`Checking ${party.name} sftp file count`);
          // validate a new csv is created
          const files = (await party.sftp.readdir(REMOTE_OUTPUT_DIR) as any[])
            .map((ele) => ele.filename).filter((fname) => fname.endsWith('.csv'));
          party.afterFiles.push(...files);
          expect(party.afterFiles.length, `${party.name} sftp has new output file`).to.greaterThan(party.beforeFiles.length);

          // validate new file contains IM trade
          const newCsvs = (party.afterFiles as string[]).filter((file) => !party.beforeFiles.includes(file));
          logger.info(`Checking ${party.name} csv file(s) ${newCsvs.join(', ')}`);
          let found = [];
          let foundFile = '';
          for (const file of newCsvs) {
            const tmpName = tempfile('.csv');
            await party.sftp.fastGet(`${REMOTE_OUTPUT_DIR}/${file}`, tmpName);
            const jsonArr = await csvjson().fromFile(tmpName);
            found = jsonArr.filter((json) => json.TransID === orderId1 || json.TransID === orderId2);
            if (found.length === inputTradeRecords.length) {
              foundFile = file;
              break;
            }
          }
          expect(found.length, `${party.name} new output file has IM trades`).to.equal(inputTradeRecords.length);

          return foundFile;
        }
      );

      // clean-up test output csv
      if (outputFile.length > 0) {
        logger.info(`cleaning up ${party.name} sftp output file ${outputFile}`);
        await party.sftp.remove(`${REMOTE_OUTPUT_DIR}/${outputFile}`);
        const fileExist = await sftpTestUtils.fileExistsInDirectory(party.sftp, REMOTE_OUTPUT_DIR, outputFile);
        expect(fileExist, `${party.name} output file ${outputFile} is deleted`).to.equal(false);
      }
    });

    await Promise.all(checks);
  }).timeout(30000);
});
