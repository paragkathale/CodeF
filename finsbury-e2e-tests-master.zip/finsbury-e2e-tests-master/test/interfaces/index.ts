export * from './trade';

export interface TradeRecordsDTO {
    tradeRecords: any[];
}

export interface TradePairsDTO {
    tradePairs: any[];
}

export interface TradeEvent {
    state: string;
    source: string;
    dgId: string;
    dataType: string;
    data: any;
}
