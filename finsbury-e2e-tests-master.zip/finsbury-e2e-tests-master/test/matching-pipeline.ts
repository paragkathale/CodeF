import { expect } from 'chai';
import uuid = require('uuid');
import { config } from './config';
import { IMTrade } from './interfaces';
import { waitForSubmission } from './test-flow/common-steps';
import { createDLTServiceAccessor } from './test-flow/dlt-svc-accessor';
import { sftpTestUtils } from './utils/sftp-test-utils';
import { createCustTradeAqr, createMultipleTradeJsonAqr } from './utils/test-data-factory';

describe('Matching Engine Test', () => {

    const inputIMTradeRecords: IMTrade[] = createMultipleTradeJsonAqr([{ TransID: uuid() }, { TransID: uuid() }, { TransID: uuid() }]);
    const inputCUTradeRecords: IMTrade[] = createCustTradeAqr(inputIMTradeRecords, { TransID: uuid() });

    it(`IM uploads file containing trade 3 new trades`, async () => {
        await sftpTestUtils.uploadTradeFile(config.im.sftp, inputIMTradeRecords);
    });

    waitForSubmission();

    it(`CU uploads file containing trade 2 matching and 1 unmatched trades`, async () => {
        await sftpTestUtils.uploadTradeFile(config.cu.sftp, inputCUTradeRecords);
    });

    waitForSubmission();

    describe('IM Verify Paired Trades', () => {
        const dltSvcAccessor = createDLTServiceAccessor(config.im.dltsvc);

        it(`IM verify that 2 trades pairs are created on the ledger with PAIRED status`, async () => {
            const orderIds: string[] = inputIMTradeRecords.map((record: IMTrade) => record.TransID || '');
            const pairs = await dltSvcAccessor.findTradePairsByOrderIds(orderIds);

            expect(pairs.length).to.equal(inputIMTradeRecords.length - 1);
            pairs.forEach((pair: any) => expect(pair.status).to.equal('PAIRED'));
        }).timeout(config.common.dltsvc.requestTimeout);

        it('IM verify that the paired trades no longer exist on the trade records list ', async () => {
            const orderIds = inputCUTradeRecords.map((record: IMTrade) => record.TransID);
            const found = await dltSvcAccessor.findTradesByOrderIds(orderIds);

            expect(found.length).to.equal(1);
        }).timeout(config.common.dltsvc.requestTimeout);
    });

    describe('CU Verify Paired Trades', () => {
        const dltSvcAccessor = createDLTServiceAccessor(config.cu.dltsvc);

        it(`CU verify that 2 trades pairs are created on the ledger with PAIRED status`, async () => {
            const orderIds: string[] = inputIMTradeRecords.map((record: IMTrade) => record.TransID);
            const found = await dltSvcAccessor.findTradePairsByOrderIds(orderIds);

            expect(found.length).to.equal(inputCUTradeRecords.length - 1);
            found.forEach((pair: any) => expect(pair.status).to.equal('PAIRED'));
        }).timeout(config.common.dltsvc.requestTimeout);

        it('CU verify that the paired trades no longer exists in trade records list', async () => {
            const orderIds = inputCUTradeRecords.map((record: IMTrade) => record.TransID);
            const found = await dltSvcAccessor.findTradesByOrderIds(orderIds);

            expect(found.length).to.equal(1);
            found.forEach((record) => expect(record.status).to.equal('NEW'));
        }).timeout(config.common.dltsvc.requestTimeout);
    });

    /* Disabled Matching for PB */
    /* const PBAccountNumber = config.pb.reference.accountNumber
    const inputIMTradeRecordsPB: IMTrade[] = createMultipleTradeJsonAqr([
        { TransID: uuid(), AccountNumber: PBAccountNumber },
        { TransID: uuid(), AccountNumber: PBAccountNumber },
        { TransID: uuid(), AccountNumber: PBAccountNumber }])

    const inputPBTradeRecords: IMTrade[] = createCustTradeAqr(inputIMTradeRecordsPB,
        { TransID: uuid(), AccountNumber: PBAccountNumber })

    it(`IM uploads file containing trade 3 new trades (PB)`, async () => {
        await sftpTestUtils.uploadTradeFile(config.im.sftp, inputIMTradeRecordsPB)
    })

    waitForSubmission()

    it(`PB uploads file containing trade 2 matching and 1 unmatched trades`, async () => {
        await sftpTestUtils.uploadTradeFile(config.pb.sftp, inputPBTradeRecords)
    })

    waitForSubmission()

    describe('IM Verify Paired Trades (PB)', () => {
        const dltSvcAccessor = createDLTServiceAccessor(config.im.dltsvc)

        it(`IM verify that 2 trades pairs are created on the ledger with PAIRED status`, async () => {
            const orderIds: string[] = inputIMTradeRecordsPB.map((record: IMTrade) => record.TransID || '')
            const pairs = await dltSvcAccessor.findTradePairsByOrderIds(orderIds)
            expect(pairs.length).to.equal(inputIMTradeRecordsPB.length - 1)
            pairs.forEach((pair: any) => expect(pair.status).to.equal('PAIRED'))
        }).timeout(config.common.dltsvc.requestTimeout)

        it('IM verify that the paired trades no longer exist on the trade records list ', async () => {
            const orderIds = inputPBTradeRecords.map((record: IMTrade) => record.TransID)
            const found = await dltSvcAccessor.findTradesByOrderIds(orderIds)

            expect(found.length).to.equal(1)
        }).timeout(config.common.dltsvc.requestTimeout)
    })

    describe('PB Verify Paired Trades', () => {
        const dltSvcAccessor = createDLTServiceAccessor(config.pb.dltsvc)

        it(`PB verify that 2 trades pairs are created on the ledger with PAIRED status`, async () => {
            const orderIds: string[] = inputIMTradeRecordsPB.map((record: IMTrade) => record.TransID)
            const found = await dltSvcAccessor.findTradePairsByOrderIds(orderIds)

            expect(found.length).to.equal(inputPBTradeRecords.length - 1)
            found.forEach((pair: any) => expect(pair.status).to.equal('PAIRED'))
        }).timeout(config.common.dltsvc.requestTimeout)

        it('PB verify that the paired trades no longer exists in trade records list', async () => {
            const orderIds = inputPBTradeRecords.map((record: IMTrade) => record.TransID)
            const found = await dltSvcAccessor.findTradesByOrderIds(orderIds)

            expect(found.length).to.equal(1)
            found.forEach((record) => expect(record.status).to.equal('NEW'))
        }).timeout(config.common.dltsvc.requestTimeout)
    }) */
});
