import { logger } from '@drumg/long-island-tea';
import { expect } from 'chai';
import { Client } from 'ssh2';
import uuid = require('uuid');
import { config } from './config';
import { TemplateType } from './test-data-templates/template-mapping';
import { waitForSubmission } from './test-flow/common-steps';
import { createDLTServiceAccessor } from './test-flow/dlt-svc-accessor';
import SftpClient from './utils/sftp-client';
import { sftpTestUtils } from './utils/sftp-test-utils';
import { createTradeJson } from './utils/test-data-factory';
import { createTestFile } from './utils/test-file-factory';

const FILE_NAME_NEW_TRADE = `pb-file-upload-new-${uuid()}`;
const sftp = new SftpClient(new Client());
const remoteUploadDir = config.common.sftp.uploadDir;

describe('Prime Broker propose trades:', () => {
  const PBAcctNum = config.pb.reference.accountNumber;
  const orderId1 = uuid();
  const orderId2 = uuid();
  const trade1 = createTradeJson(TemplateType.PB, { TransID: orderId1, AccountNumber: PBAcctNum });
  const trade2 = createTradeJson(TemplateType.PB, { TransID: orderId2, AccountNumber: PBAcctNum });
  const inputTradeRecords = [ trade1, trade2 ];

  before(() => {
    logger.info(`Running tests in PB cell`);
  });

  after(async () => {
    sftp.close();
  });

  it('connect to the sftp server', async () => {
    await sftp.connect(config.pb.sftp);
  });

  it(`upload a trade file containing ${inputTradeRecords.length} new trades to the remote SFTP directory`, async () => {
    const localFilePath = createTestFile(inputTradeRecords, FILE_NAME_NEW_TRADE);
    const remoteFilePath = `${remoteUploadDir}/${FILE_NAME_NEW_TRADE}`;
    await sftp.put(localFilePath, remoteFilePath);
  });

  waitForSubmission();

  it(`verify that trade data file is removed from remote directory once it has been push to the internal network`, async () => {
    const isDirEmpty = await sftpTestUtils.isDirectoryEmpty(sftp, remoteUploadDir);
    expect(isDirEmpty).to.equal(true);
  });

  it(`verify that the two trade records exist and have a NEW status on the ledger`, async () => {
    const found = await createDLTServiceAccessor(config.pb.dltsvc).findTradesByOrderIds([orderId1, orderId2]);
    expect(found.length).to.equal(inputTradeRecords.length);
    found.forEach((record) => expect(record.status).to.equal('NEW'));
  }).timeout(config.common.dltsvc.requestTimeout);

});
