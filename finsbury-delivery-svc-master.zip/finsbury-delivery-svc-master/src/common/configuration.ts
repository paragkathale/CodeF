export class Configuration {
    private static _instance: Configuration;

    static get instance(): Configuration {
        if (!Configuration._instance) {
            Configuration._instance = new Configuration();
        }

        return Configuration._instance;
    }

    get dmzStorageConnectionString(): string {
        return process.env.AZURE_DMZ_STORAGE_CONNECTION_STRING!;
    }

    get fileUploadContainerName(): string {
        return 'output';
    }

    get sftpHostname(): string {
        return process.env.SFTP_HOST!;
    }

    get sftpUser(): string {
        return process.env.SFTP_USER || 'sftpuser';
    }

    get sftpPrivateKeyPath(): string {
        return process.env.SFTP_PRIVKEY_PATH!;
    }

    get localDataDir(): string {
        return '/tmp';
    }

    get remoteDataDir(): string {
        return './output';
    }
}

export let config = Configuration.instance;
