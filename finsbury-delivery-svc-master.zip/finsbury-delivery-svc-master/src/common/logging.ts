import { logger } from '@drumg/long-island-tea';
import { Logger } from 'winston';

export class LoggerFactory {
    /**
     * Creates child logger of '@drumg/long-island-tea' with support for module names.
     * @param {object|string} moduleRef Class or class name.
     */
    public static createLogger(moduleRef?: object | string): Logger {
        if (moduleRef) {
            const moduleName = typeof moduleRef === 'string' ? moduleRef : moduleRef.constructor.name;
            return logger.child({ module: moduleName });
        }

        return logger;
    }
}

export { Logger } from 'winston';
