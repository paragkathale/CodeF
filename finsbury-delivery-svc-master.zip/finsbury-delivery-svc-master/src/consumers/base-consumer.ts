import {
    Consumer,
    Message,
    MessageQueueFactory,
    RerouteToDeadLetterQueueError,
    UnhandledMessageError
} from '@drumg/cloud-services';
import { jsonStringify } from '@drumg/long-island-tea';
import { Logger, LoggerFactory } from '../common/logging';

export abstract class BaseConsumer {
    private static createFactory(): MessageQueueFactory {
        return new MessageQueueFactory();
    }

    protected readonly logger: Logger;
    private readonly messageQueueFactory: MessageQueueFactory;
    private consumer?: Consumer;

    constructor(messageQueueFactory: MessageQueueFactory = BaseConsumer.createFactory()) {
        this.logger = LoggerFactory.createLogger(this);
        this.messageQueueFactory = messageQueueFactory;
    }

    public start(): void {
        this.startInternal();
    }

    public async stop() {
        if (this.consumer) {
            await this.consumer.close();
        }
        await this.messageQueueFactory.close();
    }

    protected abstract async consume(message: Message<string>): Promise<any>;
    protected abstract getTopic(): string;
    protected abstract getSubscriptionName(): string;

    private async consumeWrapper(message: Message<any>) {
        if (!message.body) {
            throw new RerouteToDeadLetterQueueError('no message body');
        }

        try {
            this.logger.debug('got message: ' +
                `schema=${message.header.schema}, ` +
                `version=${message.header.version}, ` +
                `body=${jsonStringify(message.body)}`);

            await this.consume(message);
        } catch (err) {
            this.logger.error(`error processing message: '${err}'`);
            throw new UnhandledMessageError(err);
        }
    }

    private async startInternal() {
        this.logger.info(`subscribing to topic "${this.getTopic()}" using subscription "${this.getSubscriptionName()}"`);

        this.consumer = await this.messageQueueFactory.createConsumer(
            this.getTopic(),
            this.getSubscriptionName(),
            this.consumeWrapper.bind(this)
        );
    }
}
