import { Message } from '@drumg/cloud-services';
import { FileCourier } from '../services/file-courier';
import { BaseConsumer } from './base-consumer';
import { serviceName } from '../finsbury-delivery-svc';

export class FilePostConsumer extends BaseConsumer {
    private static readonly TOPIC = 'file-transfer-out';

    private readonly fileCourier: FileCourier;

    constructor() {
        super();
        this.fileCourier = new FileCourier();
    }

    protected async consume(message: Message): Promise<any> {
        this.logger.info(`Got message: schema=${message.header.schema}, version=${message.header.version}, body=${message.body}`);

        const json = JSON.parse(message.body);

        await this.fileCourier.deliverFile(json.file);
    }

    protected getTopic(): string {
        return FilePostConsumer.TOPIC;
    }

    protected getSubscriptionName(): string {
        return `${serviceName}_${FilePostConsumer.TOPIC}`;
    }
}
