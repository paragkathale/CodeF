import program = require('commander');
import * as dotenv from 'dotenv';
import http = require('http');
import path = require('path');
import process = require('process');
import app from './app';
import { LoggerFactory } from './common/logging';
import { FilePostConsumer } from './consumers/file-post-consumer';

const logger = LoggerFactory.createLogger();
const defaultPort = 18901;
const serviceName = path.basename(__filename).split('.').slice(0, -1).join();
process.title = serviceName;

let server: http.Server;
let filePostConsumer: FilePostConsumer;

process.on('SIGTERM', () => {
    logger.info(`${serviceName} gracefully shut down`);
    if (server) { server.close(); }
    if (filePostConsumer) { filePostConsumer.stop(); }
    process.exit();
});

async function main() {
    program
        .option('-e, --env-file [path]', 'Environment file to use')
        .option('-p, --port <n>', 'Port which this service listens to', parseInt)
        .parse(process.argv);

    const envFile = program.envFile || '.env';
    dotenv.load({path: envFile});
    logger.level = process.env.LOG_LEVEL || logger.level;

    logger.info(`${serviceName} loaded env file ${envFile} successfully`);

    filePostConsumer = new FilePostConsumer();
    filePostConsumer.start();

    const svcPort: number = parseInt(process.env.PORT || defaultPort.toString());
    server = app.listen(svcPort, () => logger.info(`${serviceName} listening on port ${svcPort}`));
}

main().then();

export { defaultPort, server, filePostConsumer, serviceName };
