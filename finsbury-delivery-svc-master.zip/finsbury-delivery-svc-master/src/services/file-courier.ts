import { AzureContainerUtils } from '@drumg/cloud-services';
import SFTPClient = require('ssh2-sftp-client');
import { Logger, LoggerFactory } from '../common/logging';
import { config } from '../common/configuration';

export class FileCourier {
    private containerExists: boolean;
    private readonly logger: Logger;
    private readonly containerName: string;
    private readonly containerUtils: AzureContainerUtils;

    constructor() {
        this.logger = LoggerFactory.createLogger(this);
        this.containerName = config.fileUploadContainerName;
        this.containerUtils = new AzureContainerUtils(this.containerName, config.dmzStorageConnectionString);

        this.containerExists = false;
    }

    public async deliverFile(blobName: string) {
        await this.checkContainer();
        if (!this.containerExists) {
            throw new Error(`container "${this.containerName}" does not exist`);
        }

        const blobExists = await this.containerUtils.blobExists(blobName);
        if (!blobExists) {
            throw new Error(`blob "${blobName}" in container "${this.containerName}" does not exist`);
        }

        const localPath = `${config.localDataDir}/${blobName}`;
        const remotePath = `${config.remoteDataDir}/${blobName}`;

        try {
            this.logger.info(`Downloading file "${blobName}" from "${this.containerName}"`);
            await this.containerUtils.downloadBlobAsLocalFile(blobName, localPath);

            this.logger.info(`Uploading file from "${localPath}" through SFTP to "${remotePath}"`);

            const sftp = await this.connectToSFTP();
            await sftp.put(localPath, remotePath);
            await sftp.end();

            this.logger.info(`Uploaded file "${blobName}"`);
        } catch (err) {
            this.logger.error('Failed to transfer file from blob storage to remote location', err);
        }
    }

    private async connectToSFTP(): Promise<SFTPClient> {
        const client = new SFTPClient();

        const privateKey = require('fs').readFileSync(config.sftpPrivateKeyPath);
        await client.connect({
            host: config.sftpHostname,
            username: config.sftpUser,
            readyTimeout: 10 * 1000,
            privateKey
        });

        return client;
    }

    private async checkContainer() {
        if (!this.containerExists) {
            try {
                await this.containerUtils.ensureContainer();
                this.containerExists = true;
            } catch {
                this.logger.error(`container "${this.containerName}" does not exist`);
            }
        }
    }
}
