import assert = require('assert');
import { expect } from 'chai';
import http = require('http');
import { AddressInfo } from 'net';
import request = require('request');
import app from '../../src/app';

describe('GET /healthcheck', () => {
    let server: http.Server;
    let url: string;

    before(() => {
        server = app.listen(0); // use any available port
        assert(server != undefined, 'server is undefined');

        const addr = server.address() as AddressInfo;
        assert(addr != undefined, 'server.address() is undefined');

        url = `http://localhost:${addr.port}/healthcheck`;
    });

    after(() => {
        server.close();
    });

    it('returns status 200', () => {
        request(url, (_error, response, _body) => {
            expect(response.statusCode).to.equal(200);
        });
    });

    it('returns expected json', (done) => {
        request(url, (_error, _response, body) => {
            expect(JSON.parse(body)).to.deep.equal({ status: 'ok', msg: 'I am alive'});
            done();
        });
    });
});
