import assert = require('assert');
import { expect } from 'chai';
import { AddressInfo } from 'net';
const packageJson = require('../../../package.json');
import request = require('request');
import { defaultPort, server, filePostConsumer, serviceName } from '../../src/finsbury-delivery-svc';

describe('Service startup', () => {
    let addr: AddressInfo;

    before(() => {
        assert(server != undefined, 'server is undefined');

        addr = server.address() as AddressInfo;
        assert(addr != undefined, 'server.address() is undefined');
    });

    after(() => {
        // Temporary hack to fix race condition with pubsub threads.
        setTimeout(() => {
            filePostConsumer.stop();
            server.close();
        }, 3000);
    });

    it(`listens on default port ${defaultPort}`, () => {
        expect(addr.port).to.equal(defaultPort);
    });

    it(`process title is ${serviceName}`, () => {
        expect(process.title).to.equal(serviceName);
    });

    const invalidRoute = 'InvalidRouteForUnitTesting';
    it(`returns 404 on GET /${invalidRoute}`, (done) => {
        const url = `http://localhost:${addr.port}/${invalidRoute}`;
        request(url, (_error, response, _body) => {
            expect(response.statusCode).to.equal(404);
            done();
        });
    });
});

describe('Service configuration', () => {
    const privateLicense = 'UNLICENSED'; // see https://docs.npmjs.com/files/package.json#license
    it(`uses the private license ${privateLicense}`, () => {
        expect(packageJson.license).to.equal(privateLicense);
    });
});
