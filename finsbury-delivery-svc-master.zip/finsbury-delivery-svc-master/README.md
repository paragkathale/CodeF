<p align="center">
  <img src="https://user-images.githubusercontent.com/8850110/55236247-72848380-5227-11e9-9f56-724960bb6fd7.png" alt="DrumG" width="400" />
</p>

<h1>Finsbury Delivery service&nbsp;&nbsp;<a href="https://circleci.com/gh/DrumG/finsbury-delivery-svc/tree/master" target="_blank"><img src="https://circleci.com/gh/DrumG/finsbury-delivery-svc/tree/master.svg?style=shield&circle-token=5b4977442d12d24b84bd7c1686af3f4b39b56267"/></a></h1>

This repo contains the source for Project Finsbury's file delivery service.

The file delivery service's primary job is to grab a file from Azure Blob Storage (which was persisted there by the input file digestion service) and drop it in a pre-set folder locally.

# Service Information

| Attribute | Info |
| --------- | ---- |
| Owner | Csongor Bokay ([@bcsongor](https://github.com/bcsongor)) |
| Co-Owner | |
| Service Port | 18901 |
| Network Zone | DMZ |

## Service Bus Usage

| Topic | Subscription |
| ----- | ------------ |
| **file-transfer-out** | finsbury-delivery-svc_file-transfer-out |

## Azure Storage Usage

| Container |
| --------- |
| output |

# API Reference

## GET /healthcheck

Returns status 200 "OK" if the service is responsive.

### Example Response body
```json
{
    "status": "ok",
    "msg": "I am alive"
}
```

# Development Usage

## Install

Obtain an API token from https://packagecloud.io for access to DrumG's private package repo.  Then run:

    export PKGCLOUD_NPM_TOKEN=<token-value>
    npm install

### Commands

- `npm run build` to download pre-requisites like NPM packages, compile contracts and services files.
- `npm run start` to start service
- `npm run stop` to stop service
- `npm run clean` to clean runtime files and built package
- `npm run test` to execute unit tests
- `npm run check-license` to check dependency licenses
