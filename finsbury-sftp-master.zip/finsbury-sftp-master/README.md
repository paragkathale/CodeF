# finsbury-sftp
Finsbury SFTP scripts and things
