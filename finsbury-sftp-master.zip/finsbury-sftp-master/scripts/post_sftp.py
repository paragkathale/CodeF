#!/usr/bin/env python3

""" Name: post_sftp.py
 Author: Michael A. Palamara
 Company: DrumG
 Project: Finsbury
 Date: 2019-01-07
 Description:  This script will execute after a party uploads a file and upload
  the file to azure blob storage.  It will be pass an argument which will be
  the file name.  This script will be execute by incron.

 :MARKER:
   Need to do pylinting for python 3.
"""

from datetime import datetime

import json
import os
import sys
import azure.servicebus
import azure.storage.blob

UPLOAD_DIRECTORY = 'upload'
ERROR_DIRECTORY = 'error'
END_OF_FILE_MARKER = 'EOF'

# Method: display_then_exit
# Args: return_code as int, message as string, error_message as string.
def display_then_exit(return_code=0, message=None, error_message=None):
    '''Displays message and error_message optionally.  Exits with return code.'''
    if message is not None:
        print(message)

    if error_message is not None:
        print(error_message)

    sys.exit(return_code)

# Method: does_file_exist( file )
# Args: file as string
def does_file_exist(file=None):
    """Checks to see if file exists.  Exits if it doesn't."""
    if file is None:
        message = "does_file_exist(): file arugment not passed to method"
        display_then_exit(1, message)

    if not os.path.isfile(file):
        message = "File {} doesn't exist.".format(file)
        return_code = 1
        display_then_exit(return_code, message)

# Method: does_file_have_eof( file )
# Args: file as string
def does_file_have_eof(file=None):
    """Checks see if file has EOF maker on the last line.  Returns True or False."""
    if file is None:
        message = "does_file_have_EOF(): file arguement not passed."
        return_code = 1
        display_then_exit(return_code, message)

    last = ''

    try:
        with open(file) as file_handle:
            for line in file_handle:
                last = line
    except Exception as file_e:
        message = "does_file_have_EOF(): File error reading {}".format(file)
        return_code = 1
        display_then_exit(return_code, message, file_e)

    last = last.rstrip("\n")

    if last == END_OF_FILE_MARKER:
        return True

    print("file {} does not contain string \"{}\" at end of file.".format(file, END_OF_FILE_MARKER))
    return False

# Method: transfer_file( file, upload_directory )
# Args: file as string, upload_directory as string
def transfer_file(file=None, upload_directory=None, upload_file_name=None):
    """Transfers file to blob storage.  Creates directory in blob if not there.
    Returns True or False"""
    if file is None or upload_directory is None or upload_file_name is None:
        message = "transfer_file(): file or upload_directory argument not passed"
        return_code = 1
        display_then_exit(return_code, message)

    try:
        # Connect to storage blob.
        blob_service = azure.storage.blob.BlockBlobService(account_name=AZURE_STORAGE_BLOB_ACCOUNT,
                                                           account_key=AZURE_STORAGE_BLOB_KEY)

        # Get list of containers.
        containers = blob_service.list_containers()

        # Search for conainter.
        is_container_there_switch = False
        for container_struct in containers.items:
            if container_struct.name == upload_directory:
                is_container_there_switch = True

        # Make container if not there.
        if is_container_there_switch is False:
            make_container(blob_service, upload_directory)

        # Upload file.
        file_full_path = os.path.abspath(file)
        blob_service.create_blob_from_path(upload_directory, upload_file_name, file_full_path)

        return True

    except Exception as azure_e:
        message = "transfer_file(): Error Azure blob storage error."
        return_code = 1
        display_then_exit(return_code, message, azure_e)

    return False

# Method: make_container( container )
# Args: container as string
def make_container(blob_service=None, container=None):
    """Makes directory in blob storage."""
    if blob_service is None or container is None:
        print("make_container(): blob_service and/or container argument not passed.")
        exit(1)

    try:
        blob_service.create_container(container)
        print("Made container {}.".format(container))
    except Exception as azure_e:
        message = "make_container(): Error making container."
        return_code = 1
        display_then_exit(return_code, message, azure_e)

# Method: remove_file( file )
# Args: file as string
def remove_file(file=None):
    """Removes file uploaded."""
    if file is None:
        message = "remove_file(): file argument not passed"
        return_code = 1
        display_then_exit(return_code, message)

    try:
        file_full_path = os.path.abspath(file)
        os.remove(file_full_path)
    except Exception as remove_e:
        message = "Error removing file {}.".format(file)
        return_code = 1
        display_then_exit(return_code, message, remove_e)

# Method: print_env_vars()
# Args: None
def print_env_vars():
    ''' Prints environement variables '''
    print("\tEOF_CHECK")
    print("\tEOF_MARKER")
    print("\tNO_DELETE")
    print("\tAZURE_STORAGE_BLOB_ACCOUNT")
    print("\tAZURE_STORAGE_BLOB_KEY")
    print("\tAZURE_SERVICE_BUS_NAMESPACE")
    print("\tAZURE_SERVICE_BUS_ACCOUNT")
    print("\tAZURE_SERVICE_BUS_KEY")

# Method: send_message_to_topic(file)
# Args: file as string
def send_message_to_topic(file=None):
    '''Sends message to service bus namespace'''

    try:
        bus_service = azure.servicebus.ServiceBusService(
            service_namespace=AZURE_SERVICE_BUS_NAMESPACE,
            shared_access_key_name=AZURE_SERVICE_BUS_ACCOUNT,
            shared_access_key_value=AZURE_SERVICE_BUS_KEY
        )

        message_data = {'file': file}
        message_json = json.dumps(message_data)

        service_bus_message = azure.servicebus.Message(message_json)
        service_bus_message.custom_properties = {'version': '1.0.0'}

        bus_service.send_topic_message('upload', service_bus_message)

        return True

    except Exception as message_bus_e:
        message = "send_message_queue(): There was an error when communicating the message bus."
        return_code = 1
        display_then_exit(return_code, message, message_bus_e)
    return False

# main()

# Check for file argument
if len(sys.argv) < 2:
    print("Useage: {} some_file_to_upload.txt".format(sys.argv[0]))
    print("Environment Variables:")
    print_env_vars()
    exit(1)

# Get file name from argument
FILE_TO_TRANSFER = sys.argv[1]
UPLOAD_FILE_NAME = datetime.now().isoformat() + '_' + FILE_TO_TRANSFER
# Find environement variables
try:
    AZURE_STORAGE_BLOB_ACCOUNT = os.environ['AZURE_STORAGE_BLOB_ACCOUNT']
    AZURE_STORAGE_BLOB_KEY = os.environ['AZURE_STORAGE_BLOB_KEY']
    AZURE_SERVICE_BUS_NAMESPACE = os.environ['AZURE_SERVICE_BUS_NAMESPACE']
    AZURE_SERVICE_BUS_ACCOUNT = os.environ['AZURE_SERVICE_BUS_ACCOUNT']
    AZURE_SERVICE_BUS_KEY = os.environ['AZURE_SERVICE_BUS_KEY']
except Exception as env_e:
    print("One of the following environment variables has not been set:")
    print_env_vars()
    print(env_e)
    exit(1)

# Find EOF_CHECK
EOF_CHECK = False
try:
    if "EOF_CHECK" in os.environ:
        if os.environ['EOF_CHECK'] == "1":
            EOF_CHECK = True
        else:
            EOF_CHECK = False
except Exception as env_e:
    message = "Error checking EOF_CHECK in environment variables."
    return_code = 1
    display_then_exit(return_code, message, return_code)

# Find EOF_MARKER
try:
    if "EOF_MARKER" in os.environ:
        END_OF_FILE_MARKER = os.environ['EOF_MARKER']
except Exception as env_e:
    message = "Error checking EOF_MARKER in environment variables."
    return_code = 1
    display_then_exit(return_code, message, return_code)

# Find NO_DELETE
NO_DELETE = False
try:
    if "NO_DELETE" in os.environ:
        if os.environ['NO_DELETE'] == "1":
            NO_DELETE = True
        else:
            NO_DELETE = False
except Exception as env_e:
    message = "Error checking NO_DELETE in environment variable."
    return_code = 1
    display_then_exit(return_code, message, return_code)

does_file_exist(FILE_TO_TRANSFER)

HAS_EOF = False
if EOF_CHECK is True:
    HAS_EOF = does_file_have_eof(FILE_TO_TRANSFER)

# Transfer file
if HAS_EOF is True or EOF_CHECK is False:
    TRANSFER_RESULT = transfer_file(FILE_TO_TRANSFER, UPLOAD_DIRECTORY, UPLOAD_FILE_NAME)
else:
    TRANSFER_RESULT = transfer_file(FILE_TO_TRANSFER, ERROR_DIRECTORY, UPLOAD_FILE_NAME)

# Remove file
if TRANSFER_RESULT is True:
    SEND_MESSAGE_TO_QUEUE = send_message_to_topic(UPLOAD_FILE_NAME)

if SEND_MESSAGE_TO_QUEUE is True and NO_DELETE is False:
    remove_file(FILE_TO_TRANSFER)


# End of program
