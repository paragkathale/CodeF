#!/bin/bash

source /opt/drumg/post-sftp/current/config/.env-dev-fin00-d-sftp00

cd /var/sftp/uploads

/opt/drumg/post-sftp/current/bin/post_sftp.py $@
