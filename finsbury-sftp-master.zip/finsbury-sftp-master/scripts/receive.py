#!/usr/bin/env python3

import azure.servicebus

bus_service = azure.servicebus.ServiceBusService(
    service_namespace='dev-fin00-sbn00',
    shared_access_key_name='',
    shared_access_key_value=''
)

while True:
    print("Waiting for message...")
    msg = bus_service.receive_subscription_message('upload', 'sftp', peek_lock=False )

    if msg.body is not None:
        print(msg.body.decode('utf-8'))
