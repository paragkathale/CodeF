# finsbury-terraform

*Getting started*

Get yourself added with a Keys, Secrets, and Certificates Access Policy to the drumg-dev-tf-vault00
--See Mike or Russ for this access

Change into the tf sub-directory and :

. .profile && make init
