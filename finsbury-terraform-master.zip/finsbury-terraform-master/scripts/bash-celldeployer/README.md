Can be adapted for the naive 0.1-PoBV deployment of cells with the criteria that they are:

- under the same dev. subscription,
- with unique vnet address spacing,
- will be set up with full 6-way, 3-vnet peering

Provides red, (amber/green), and yellow vnets, and 2 vms (bastion, corda) in their respective subnets.
