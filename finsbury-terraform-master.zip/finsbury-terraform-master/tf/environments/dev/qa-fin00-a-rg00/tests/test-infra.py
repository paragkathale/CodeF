#!/usr/bin/env python3

# Name: test-infra.py
# Author: Michael A. Palamara
# Company: DrumG
# Date: 2019-04-02
# Lincese: All Right Reserved
# Description:
#   This script reads terraform state json files and tests Azure resource to make sure
# they meet DrumG resource standards.  This is a simple script.  In the future we
# should use a testing framework.

# https://drumg1.atlassian.net/wiki/spaces/ENG/pages/113508457/System+Conventions
# ${env}-${network}[0-9]+-${cell}-${type}[0-9]+-${usage}

import json
import sys
import yaml

from pprint import pprint

config_file_path = sys.path[0] + "/test-infra.yml"
with open(config_file_path) as config_file:
    config = yaml.load(config_file)

env = config['env']
network = config['network']
cell = config['cell']
host_types = config['host_types']
storage_types = config['storage_types']
namespace_types = config['namespace_types']

if len(sys.argv) < 2:
    exit("Usage: {} terraform-state-pull.json".format(sys.argv[0]))

with open(sys.argv[1]) as state_file:
    state_data = json.load(state_file)

resources = state_data['modules'][0]['resources']

# Check Virtual Machines
print("Virtual Machine:")
for resource in resources:
    if "azurerm_virtual_machine" in resource:
        hostname = resources[resource]['primary']['attributes']['name']
        os_type = resources[resource]['primary']['attributes']['storage_os_disk.0.os_type']

        if os_type == "Linux":
            test_env, test_network, test_cell, test_hostname_postfix = hostname.split('-')

            if test_env == env and \
               test_network == network and \
               test_cell == cell and \
               test_hostname_postfix in host_types:
                hostname_status = '[OK]'
            else:
                hostname_status = '[FAIL]'

            print("Linux: {} {}".format(hostname, hostname_status))
        elif os_type == "Windows":
            test_hostname = "{}{}{}win00".format(env,network,cell)
            if test_hostname == hostname:
                hostname_status = "[OK]"
            else:
                hostname_status = "[FAIL]"
            print("Windows: {} {}".format(hostname, hostname_status))
print()


# Check Storage Accounts
storage_accounts = []

for resource in resources:
    if "azurerm_storage_account" in resource:
        storage_accounts.append(resources[resource]['primary']['attributes']['name'])

test_storage_accounts = []

for storage_type in storage_types:
    test_storage_account = "{}{}{}{}".format(env, network, cell, storage_type)
    test_storage_accounts.append(test_storage_account)

print("Storage Accounts:")
for storage_account in storage_accounts:
    if storage_account in test_storage_accounts:
        storage_status = "[OK]"
    else:
        storage_status = "[FAIL]"

    print("{} {}".format(storage_account, storage_status))
print()


# Check Namespaces
namespaces = []
for resource in resources:
    if "azurerm_servicebus_namespace" in resource:
        namespaces.append(resources[resource]['primary']['attributes']['name'])

test_namespaces = []

for namespace_type in namespace_types:
    test_namespace = "{}-{}-{}-{}".format(env, network, cell, namespace_type)
    test_namespaces.append(test_namespace)

print("Namespaces:")
for namespace in namespaces:
    if namespace in test_namespaces:
        namespace_status = "[OK]"
    else:
        namespace_status = "[FAIL]"

    print("{} {}".format(namespace, namespace_status))