#!/usr/bin/env bash
set -x

exec > /tmp/bootstrap.log 2>&1

echo "bootscript initiated" >> /tmp/bootstrap.log

mkdir -p /opt/infra/bin

function installAzureCLI() {
        sudo apt-get install apt-transport-https lsb-release software-properties-common dirmngr -y

        echo "deb [arch=amd64] https://packages.microsoft.com/repos/azure-cli/ xenial main" | \
            sudo tee /etc/apt/sources.list.d/azure-cli.list

        sudo apt-key --keyring /etc/apt/trusted.gpg.d/Microsoft.gpg adv \
                --keyserver packages.microsoft.com \
                --recv-keys BC528686B50D79E339D3721CEB3E94ADBE1229CF

        sudo apt-get update
        sudo apt-get install azure-cli
}

function downloadBlob() {
        az storage blob download \
                --container-name finsbury-ansible \
                --file bootstrap.sh \
                --name bootstrap.sh \
                --account-name devfin00deploy01 \
                --auth-mode login
}

installAzureCLI

# Login to Azure Service Principal account
az login --service-principal --username "http://dg-ci" --password "pw" --tenant "f22be4ce-854f-4849-987b-1d83996edb61"
az account set --subscription "2b55c7d7-de7b-4eb7-adc4-1c6415e50e22"

cd /opt/infra
downloadBlob

#Set execution bits
chmod 755 bootstrap.sh

#DO IT
./bootstrap.sh
echo "bootscript done" >> /tmp/bootstrap.log

exit 0
