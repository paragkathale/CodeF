#!/usr/bin/env bash
#
# vim: ft=sh
# UNDER DEVELOPMENT - RJB

set -e
[[ $TRACE ]] && set -x

readonly ansible_dir="/opt/infra/ansible"
#readonly instance=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
#readonly region=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | jq -r .region)
readonly tag_file="/tmp/azure_tags.json"
curl -H Metadata:true "http://169.254.169.254/metadata/instance?api-version=2018-04-02" > $tag_file

## Send output to syslog
exec >& >(exec logger -i -s -t "$(basename $0)") 2>&1

# Get a single tag
get_tag(){
  jq -r ".[] | select(.Key==\"$1\") | .Value" $tag_file
}

function downloadBlob() {
        az storage blob download \
                --container-name finsbury-ansible \
                --file ansible.tgz \
                --name ansible.tgz \
                --account-name devfin00deploy01 \
                --auth-mode login
}

environment=$(get_tag environment)
class=$(get_tag class)
cell=$(get_tag cell)
project=$(get_tag project)
role=$(get_tag role)

mkdir -p /etc/drumg
echo "${project}" > /etc/drumg/project
echo "${environment}" > /etc/drumg/environment
echo "${role}" > /etc/drumg/role
echo "${class}" > /etc/drumg/class
echo "${cell}" > /etc/drumg/cell

rm -rf ${ansible_dir}
mkdir -p ${ansible_dir}
cd ${ansible_dir}

#Fetch the ansible archive
downloadBlob

tar zxvf ansible.tgz

# Run ansible
${ansible_dir}/bin/al "$@"
