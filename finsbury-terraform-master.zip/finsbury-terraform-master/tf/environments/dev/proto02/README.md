# How To Execute Terraform for Finsbury

## Source the .profile to get a Storage Account key that Terraform uses
$ pwd
/Users/mike/src/finsbury-terraform/tf/environments/dev/proto02

$ . ../../../.profile

---
## Initialize Terraform
$ make init

---
## Display Terraform Plan
$ make plan

---
## Create Resources Using Terraform
$ make apply

---
## Create VPN Gateway
$ make apply-gateway

---
## Create VPN Connection to Backbone VPN
$ cat .secrets
export BACKBONE_IPSEC_SHARED_SECRET=some_secret

export BACKBONE_VPN_GATEWAY_ID=/subscriptions/some_reasource_id/resourceGroups/dev-proto02-backbone-rg00/providers/Microsoft.Network/virtualNetworkGateways/dev-proto02-backbone-vnet-backbone00-gateway

export YELLOW_IPSEC_SHARED_SECRET=some_other_secret

export YELLOW_VPN_GATEWAY_ID=/subscriptions/some_reasource_id/resourceGroups/dev-proto02-rg00/providers/Microsoft.Network/virtualNetworkGateways/dev-proto02-vnet-yellow00-gateway

$ . .secrets

$ make apply-with-connection

---
## Check List For Creating a New Cell

* Set subscription_id in provider.tf
* Set unique values in backend.tfvar.  There should be one key file per cell.  Eg.
  * resource_group_name  = "dev-terraform-rg00"
  * storage_account_name = "devterraformstor00"
  * container_name       = "dev-terraform-con00"
  * key                  = "dev-proto02.tfstate"
* Set cell parameters in variables.tf
  * prefix
  * storage_prefix
  * winhostname
  * env
  * location
  * vnet-red00-network-range
  * subnets under vnet-red00
  * vnet-ambergreen00-network-range
  * vnet-ambergreen00
  * vnet-yellow00-network-range
  * vnet-yellow00
  * vnet-black00-network-range
  * vnet-black00
  * ubuntu_storage_image_reference
  * windows_storage_image_reference
  * key_data