import azuresb = require("azure-sb")
import stompit = require('stompit')

var g_asbService: azuresb.ServiceBusService;
var g_subClient: any;
const g_useLocalSb = true;

function sendSbMsg(topic: string, msg: string)
{
    if (g_useLocalSb)
    {
        stompit.connect({ host: 'localhost', port: 61613 }, (err : any, client : any) => {
            if (!err) {
                const frame = client.send({ destination: '/topic/' + topic });                
                frame.write(msg);                
                frame.end();
                client.disconnect();
                console.log(`SENT=${msg}`)
            }
            else
            {
                console.log(err.toString())
            }        
        }); 
    }
    else { // sent to Azure Service Bus
        var message = {
            body: '',
            customProperties: {
                messagenumber: 0
            }
        }
        
        message.body='This is Message';
        g_asbService.sendTopicMessage(topic, message, function(error) {
            if (error) {
            console.log(error);
            }
        });
    }   
}

function subscribeSb(topic: string, cbOnReceiveMsg: (err: any, msg: any) => void)
{
    if (g_useLocalSb)
    {
        stompit.connect({ host: 'localhost', port: 61613 }, (err: any, client: any) => {  
            g_subClient = client;
            client.subscribe({ destination: '/topic/' + topic }, cbOnReceiveMsg);   
        });        
    }
    else {
        g_asbService.createSubscription(topic,'AllMessages',function(error){
            if(!error){
                // subscription created
                g_asbService.receiveSubscriptionMessage(topic, 'AllMessages', function(error, receivedMessage){
                    if(!error){
                        // Message received and deleted
                        console.log(`RECEIVED from asb [${topic}]=${receivedMessage}`);
                    }
                });            
            }
        });
    }
}


class AzuresbTest
{
    public static run () : void
    {      
        console.log("RUN " + AzuresbTest.name) 

        let topic = "SampleTopic"

        if (g_useLocalSb)
        {
        }
        else 
        {
            let connStr = process.env.AZURE_SERVICEBUS_CONNECTION_STRING || 'Endpoint=sb://dgfinplay.servicebus.windows.net/;SharedAccessKeyName=TestFullPolicy;SharedAccessKey=GA46t/4AfENgXWSVnMmEfTyZHUpQKluS9zR3QHk2Chw=';
            if (!connStr) throw new Error('Must provide connection string');
            g_asbService = azuresb.createServiceBusService(connStr);
            g_asbService.createTopicIfNotExists(topic,function(error){
                if(!error){
                    // Topic was created or exists
                    console.log('topic created or exists.');
                }
            });
        }
        
        subscribeSb(topic, (err: any, msg: any) => {
            msg.readString('UTF-8', (err: any, body: any) => {
            console.log(`RECEIVED from [${topic}]= ${body}`)
            if (g_subClient) { g_subClient.disconnect() }
            });     
        });

        sendSbMsg(topic, "This is my message")
    }  
}

export function run(): void { AzuresbTest.run() }
