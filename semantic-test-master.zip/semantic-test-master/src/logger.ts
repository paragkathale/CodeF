import * as winston from 'winston'
import { format } from 'winston';

function createLogger(fileName:string, logToConsole:boolean=true){
    let level = process.env.LOG_LEVEL || 'info'

    let transports:any[] = [
        new winston.transports.File({filename: fileName})
    ];

    if(logToConsole){
        transports = transports.concat(new winston.transports.Console({
            format: winston.format.combine(winston.format.colorize(), winston.format.simple())
        }));
    }

    let logger = winston.createLogger({
        level: level,
        format: format.combine(
            format.timestamp(),
            format.json()
        ),
        transports: transports
    });

    return logger;
}

let logger:winston.Logger = createLogger(process.env.JSON_LOG_FILE || 'logfile.json', process.env.NODE_ENV !== 'production')

export {logger};
