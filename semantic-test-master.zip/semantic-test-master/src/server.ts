import jsonata = require("jsonata")
import { logger } from './logger';
import * as AzuresbTest from './azuresb-test'

import * as aqrData from './aqr-data.json'
import * as aqrMap from './aqr-map.json'
import * as hedgeservData from './hedgeserv-data.json'
import * as hedgeservMap from './hedgeserv-map.json'


function normalizeExp(rawMap : any) : string
{
  return `{
  "fund": {
    "manager":${rawMap['fund.manager']},
    "identifiers": {
      "AccountNumber":${rawMap['AccountNumber']},
      "ClearingAccountNumber": ${rawMap['ClearingAccountNumber']},
      "LocationAccount": ${rawMap['LocationAccount']}
    }
  },
  "transaction": {
    "type": ${rawMap['transaction.type']},
    "identifiers": {
      "LotID": ${rawMap['transaction.identifiers.LotID']},
      "TransID": ${rawMap['transaction.identifiers.TransID']}
    }
  },
  "investment": {
    "type": ${rawMap['investment.type']},
    "identifiers": {
      "ISIN": ${rawMap['investment.identifiers.ISIN']},
      "SEDOL": ${rawMap['investment.identifiers.SEDOL']},
      "CUSIP": ${rawMap['investment.identifiers.CUSIP']},
      "BBTICKER": ${rawMap['investment.identifiers.BBTICKER']},
      "RIC": ${rawMap['investment.identifiers.RIC']},
      "AQRID": ${rawMap['investment.identifiers.AQRID']},
      "SecurityName": ${rawMap['investment.identifiers.SecurityName']}
    }
  },
  "details": {
    "type": ${rawMap['details.type']},
    "tradeDate": ${rawMap['details.tradeDate']},
    "settleDate": ${rawMap['details.settleDate']},
    "tradeCurrency": ${rawMap['details.tradeCurrency']},
    "settleCurrency": ${rawMap['details.settleCurrency']},
    "fxRate": ${rawMap['details.fxRate']},
    "quantity": ${rawMap['details.quantity']},
    "price": ${rawMap['details.price']},
    "commissions": ${rawMap['details.commissions']},
    "fees": { 
      "SEC": ${rawMap['details.fees.SEC']}, 
      "other": ${rawMap['details.fees.Other']} 
    },
    "netTradeAmount": ${rawMap['details.netTradeAmount']},
    "grossTradeAmount": ${rawMap['details.grossTradeAmount']},
    "clearingBroker": {
      "code": ${rawMap['details.clearingBroker.code']},
      "longName": ${rawMap['details.clearingBroker.longName']}
    },
    "executingBroker": {
      "code": ${rawMap['details.executingBroker.code']},
      "longName": ${rawMap['details.executingBroker.longName']}
    }
  }
}`;
}

function denormalizeExp(rawMap : any) : string
{
  var denormExp = "{"
  var first = true;
  Object.keys(rawMap).forEach(k => {
    if (first) { 
      first = false;
    } else {
      denormExp += ","
    }
    denormExp += '"' + rawMap[k] + '" : ' + k
  });

  denormExp += "}"
  return denormExp
}

class Startup {
  public static main(): number {

    logger.info("hello world")

    console.log("============ AQR Normalize ============")

    let aqrExp = normalizeExp(aqrMap)
    let aqrJExp = jsonata(aqrExp);
    let aqrNormalized = aqrJExp.evaluate(aqrData); 

    console.log(JSON.stringify(aqrNormalized, null, 2))

    console.log("=========== AQR Denormalize ===========")

    let aqrDenormExp = denormalizeExp(aqrMap)
    let aqrDenormJExp = jsonata(aqrDenormExp)
    let aqrDenormalized = aqrDenormJExp.evaluate(aqrNormalized)

    console.log(JSON.stringify(aqrDenormalized, null, 2))

    console.log("============ HedgeServ Normalize ============")

    let hedgeservExp = normalizeExp(hedgeservMap)
    let hedgeservJExp = jsonata(hedgeservExp);
    let hedgeservNormalized = hedgeservJExp.evaluate(hedgeservData); 

    console.log(JSON.stringify(hedgeservNormalized, null, 2))

    console.log("============ Local Service Bus Test ============")
    //AzuresbTest.run()
    return 0;
  }
}

Startup.main();

